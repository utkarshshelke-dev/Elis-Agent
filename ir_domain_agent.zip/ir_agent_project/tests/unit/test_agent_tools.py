"""
Module: tests/unit/test_agent_tools.py
Description: Unit tests for the three ADK tool functions in agent.py.
             All DB and IQC HTTP calls are mocked.
Author: IR Team
"""
from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch

import pytest

import agent as agent_module
from data.schemas import IRSession, ChatTurn


USER_ID    = "550e8400-e29b-41d4-a716-446655440000"
SESSION_ID = "660e8400-e29b-41d4-a716-446655440001"


def _make_session(**kwargs) -> IRSession:
    defaults = dict(
        user_id=    USER_ID,
        session_id= SESSION_ID,
        status=     "open",
        turn_number= 0,
    )
    defaults.update(kwargs)
    return IRSession(**defaults)


def _tool_ctx():
    return MagicMock()


# ── get_or_create_session ─────────────────────────────────────────────────────

class TestGetOrCreateSession:
    def test_creates_new_session_for_unknown_user(self):
        """Returns 'created' JSON when no session exists for the user."""
        with patch.object(agent_module._repo, "load_active",   return_value=None), \
             patch.object(agent_module._repo, "load_history",  return_value=None), \
             patch.object(agent_module._repo, "upsert_active", return_value=None):
            result = agent_module.get_or_create_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"] == "created"
        assert data["reason"] == "new_user"

    def test_resumes_active_qualifying_session(self):
        """Returns 'resumed' JSON for an active qualifying session."""
        session = _make_session(
            status="qualifying",
            turn_number=3,
            chat_history=[
                ChatTurn(turn=3, user_message="x", iqc_response="What stage?", timestamp="t")
            ],
        )
        with patch.object(agent_module._repo, "load_active", return_value=session):
            result = agent_module.get_or_create_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"]            == "resumed"
        assert data["turns"]             == 3
        assert data["last_iqc_question"] == "What stage?"

    def test_returns_already_qualified(self):
        """Returns 'already_qualified' reason for a qualified session."""
        session = _make_session(status="qualified", turn_number=8)
        with patch.object(agent_module._repo, "load_active", return_value=session):
            result = agent_module.get_or_create_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"] == "resumed"
        assert data["reason"] == "already_qualified"

    def test_expires_old_session_and_creates_fresh(self):
        """Archives an expired session then creates a new one."""
        expired = _make_session(
            status="qualifying",
            started_at=time.time() - 7200,  # 2 hours ago
        )
        with patch.object(agent_module._repo, "load_active",    return_value=expired), \
             patch.object(agent_module._repo, "archive_and_delete", return_value=None), \
             patch.object(agent_module._repo, "load_history",   return_value=None), \
             patch.object(agent_module._repo, "upsert_active",  return_value=None):
            result = agent_module.get_or_create_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"] == "created"

    def test_restores_from_history(self):
        """Loads session from ir_session_history when active table is empty."""
        history = _make_session(
            status="qualifying",
            turn_number=2,
            iqc_session_id="old-iqc-sid",
        )
        with patch.object(agent_module._repo, "load_active",   return_value=None), \
             patch.object(agent_module._repo, "load_history",  return_value=history), \
             patch.object(agent_module._repo, "upsert_active", return_value=None):
            result = agent_module.get_or_create_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"]         == "resumed"
        assert data["iqc_session_id"] == "old-iqc-sid"


# ── route_to_iqc ──────────────────────────────────────────────────────────────

class TestRouteToIQC:
    def test_returns_success_with_response(self):
        """Returns 'success' JSON with IQC response text."""
        session = _make_session(turn_number=1, iqc_session_id="iqc-sid-abc")

        with patch.object(agent_module._repo,       "load_active",   return_value=session), \
             patch.object(agent_module._repo,       "upsert_active", return_value=None), \
             patch.object(agent_module.iqc_client,  "stream_query",  return_value=("What is your fund size?", "iqc-sid-abc")):
            result = agent_module.route_to_iqc(USER_ID, "I invest in SaaS", _tool_ctx())

        data = json.loads(result)
        assert data["result"]   == "success"
        assert data["response"] == "What is your fund size?"

    def test_creates_iqc_session_on_first_call(self):
        """Creates IQC session when iqc_session_id is empty."""
        session = _make_session(turn_number=0, iqc_session_id="")

        with patch.object(agent_module._repo,       "load_active",    return_value=session), \
             patch.object(agent_module._repo,       "upsert_active",  return_value=None), \
             patch.object(agent_module.iqc_client,  "create_session", return_value="new-iqc-sid"), \
             patch.object(agent_module.iqc_client,  "stream_query",   return_value=("Hello!", "new-iqc-sid")):
            result = agent_module.route_to_iqc(USER_ID, "Hi", _tool_ctx())

        data = json.loads(result)
        assert data["iqc_session_id"] == "new-iqc-sid"

    def test_prepends_user_id_on_turn_zero(self):
        """Prepends user_id: <uid> to the message on turn 0."""
        session    = _make_session(turn_number=0, iqc_session_id="sid")
        call_args  = {}

        def capture_stream_query(message, user_id, **kwargs):
            call_args["message"] = message
            return ("response", "sid")

        with patch.object(agent_module._repo,      "load_active",   return_value=session), \
             patch.object(agent_module._repo,      "upsert_active", return_value=None), \
             patch.object(agent_module.iqc_client, "stream_query",  side_effect=capture_stream_query):
            agent_module.route_to_iqc(USER_ID, "Yes I invest", _tool_ctx())

        assert USER_ID in call_args["message"]

    def test_returns_error_json_when_iqc_returns_empty(self):
        """Returns error JSON when IQC returns empty response."""
        session = _make_session(turn_number=1, iqc_session_id="sid")

        with patch.object(agent_module._repo,      "load_active",   return_value=session), \
             patch.object(agent_module._repo,      "upsert_active", return_value=None), \
             patch.object(agent_module.iqc_client, "stream_query",  return_value=("", "sid")):
            result = agent_module.route_to_iqc(USER_ID, "Hello", _tool_ctx())

        data = json.loads(result)
        assert data["result"]   == "error"
        assert data["qualified"] is False

    def test_strips_session_marker_before_storing(self):
        """Strips __SESSION__{...} marker from IQC response before persisting."""
        session   = _make_session(turn_number=1, iqc_session_id="sid")
        raw_resp  = "Your score is 50%! __SESSION__{\"session_id\":\"sid\"}"
        stored    = {}

        def capture_upsert(s):
            stored["last_response"] = s.last_iqc_question

        with patch.object(agent_module._repo,      "load_active",   return_value=session), \
             patch.object(agent_module._repo,      "upsert_active", side_effect=capture_upsert), \
             patch.object(agent_module.iqc_client, "stream_query",  return_value=(raw_resp, "sid")):
            agent_module.route_to_iqc(USER_ID, "Hello", _tool_ctx())

        assert "__SESSION__" not in stored.get("last_response", "")


# ── close_session ─────────────────────────────────────────────────────────────

class TestCloseSession:
    def test_archives_and_returns_turns_saved(self):
        """Returns 'closed' JSON with the correct turns_saved count."""
        session = _make_session(turn_number=4, status="qualifying")
        # Simulate 4 turns in chat_history
        for i in range(4):
            session.append_turn(f"msg{i}", f"resp{i}", "t")

        with patch.object(agent_module._repo, "load_active",       return_value=session), \
             patch.object(agent_module._repo, "archive_and_delete", return_value=None) as mock_arch:
            result = agent_module.close_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"]      == "closed"
        assert data["turns_saved"] == 4
        mock_arch.assert_called_once_with(session, end_reason="exit")

    def test_returns_no_session_when_not_found(self):
        """Returns 'no_session' JSON when user has no active session."""
        with patch.object(agent_module._repo, "load_active", return_value=None):
            result = agent_module.close_session(USER_ID, _tool_ctx())

        data = json.loads(result)
        assert data["result"] == "no_session"
