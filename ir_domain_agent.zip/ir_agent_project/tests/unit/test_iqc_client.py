"""
Module: tests/unit/test_iqc_client.py
Description: Unit tests for IQCClient — all HTTP calls and auth mocked.
Author: IR Team
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from services.iqc_client import IQCClient
from services.exceptions import AuthTokenError


USER_ID = "550e8400-e29b-41d4-a716-446655440000"


@pytest.fixture
def client():
    return IQCClient()


# ── get_token ─────────────────────────────────────────────────────────────────

class TestGetToken:
    def test_returns_token_string(self, client):
        """get_token returns the refreshed access token string."""
        mock_creds = MagicMock()
        mock_creds.token = "ya29.test-token"

        with patch("google.auth.default", return_value=(mock_creds, "project")), \
             patch("google.auth.transport.requests.Request"):
            token = client.get_token()

        assert token == "ya29.test-token"
        mock_creds.refresh.assert_called_once()

    def test_raises_auth_token_error_on_failure(self, client):
        """get_token raises AuthTokenError when google.auth.default fails."""
        with patch("google.auth.default", side_effect=Exception("no credentials")):
            with pytest.raises(AuthTokenError):
                client.get_token()


# ── create_session ────────────────────────────────────────────────────────────

class TestCreateSession:
    def test_returns_session_id_on_success(self, client):
        """create_session returns the IQC session ID from the API response."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"output": {"id": "iqc-session-abc123"}}
        mock_response.raise_for_status = MagicMock()

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_response):
            sid = client.create_session(USER_ID)

        assert sid == "iqc-session-abc123"

    def test_returns_empty_string_on_http_error(self, client):
        """create_session returns '' gracefully on HTTP error."""
        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", side_effect=Exception("timeout")):
            sid = client.create_session(USER_ID)

        assert sid == ""

    def test_returns_empty_string_when_id_missing(self, client):
        """create_session returns '' when response JSON has no 'id' field."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"output": {}}
        mock_response.raise_for_status = MagicMock()

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_response):
            sid = client.create_session(USER_ID)

        assert sid == ""


# ── stream_query ──────────────────────────────────────────────────────────────

class TestStreamQuery:
    def _make_mock_response(self, lines: list[str], status: int = 200):
        """Build a mock requests.Response with streaming text."""
        mock_resp = MagicMock()
        mock_resp.status_code = status
        mock_resp.raise_for_status = MagicMock()
        mock_resp.text = "\n".join(lines)
        return mock_resp

    def test_extracts_final_text(self, client):
        """stream_query parses the LLM text from a multi-line stream."""
        event_line = json.dumps({
            "content": {
                "parts": [{"text": "What sectors do you invest in?"}]
            }
        })
        mock_resp = self._make_mock_response([event_line])

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_resp):
            text, sid = client.stream_query("hello", USER_ID, "sess-123")

        assert text == "What sectors do you invest in?"
        assert sid  == "sess-123"  # unchanged

    def test_captures_session_id_from_tool_response(self, client):
        """stream_query captures IQC session_id from function_response parts."""
        event_line = json.dumps({
            "content": {
                "parts": [
                    {
                        "function_response": {
                            "response": json.dumps({"session_id": "new-iqc-sid-xyz"})
                        }
                    },
                    {"text": "What is your fund size?"},
                ]
            }
        })
        mock_resp = self._make_mock_response([event_line])

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_resp):
            text, sid = client.stream_query("hello", USER_ID)

        assert sid  == "new-iqc-sid-xyz"
        assert text == "What is your fund size?"

    def test_returns_empty_on_http_error(self, client):
        """stream_query returns ('', existing_sid) on request failure."""
        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", side_effect=Exception("connection error")):
            text, sid = client.stream_query("hello", USER_ID, "existing-sid")

        assert text == ""
        assert sid  == "existing-sid"

    def test_returns_empty_on_empty_response(self, client):
        """stream_query returns ('', sid) when IQC sends an empty body."""
        mock_resp = self._make_mock_response([""])

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_resp):
            text, sid = client.stream_query("hello", USER_ID)

        assert text == ""

    def test_strips_session_marker_from_text(self, client):
        """stream_query captures __SESSION__ marker from the response text."""
        marker     = '__SESSION__{"session_id": "marker-sid-999"}'
        event_line = json.dumps({
            "content": {"parts": [{"text": f"Profile looks good! {marker}"}]}
        })
        mock_resp = self._make_mock_response([event_line])

        with patch.object(client, "get_token", return_value="token"), \
             patch("requests.post", return_value=mock_resp):
            text, sid = client.stream_query("hello", USER_ID)

        assert sid == "marker-sid-999"


# ── build_context ─────────────────────────────────────────────────────────────

class TestBuildContext:
    def test_returns_empty_for_no_history(self):
        assert IQCClient.build_context([]) == ""

    def test_includes_user_and_iqc_lines(self):
        history = [
            {
                "turn": 1,
                "user_message": "I manage $50M",
                "iqc_response": "What sectors?",
                "timestamp": "t",
            }
        ]
        ctx = IQCClient.build_context(history)
        assert "I manage $50M" in ctx
        assert "What sectors?"  in ctx

    def test_handles_pydantic_turn_objects(self):
        """build_context works with ChatTurn model instances as well as dicts."""
        from data.schemas import ChatTurn
        turn = ChatTurn(
            turn=1,
            user_message="I invest $1M",
            iqc_response="Which stage?",
            timestamp="t",
        )
        ctx = IQCClient.build_context([turn])
        assert "I invest $1M"  in ctx
        assert "Which stage?" in ctx
