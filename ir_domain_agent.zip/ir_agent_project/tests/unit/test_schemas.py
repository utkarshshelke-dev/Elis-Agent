"""
Module: tests/unit/test_schemas.py
Description: Unit tests for IRSession and ChatTurn Pydantic models.
Author: IR Team
"""
from __future__ import annotations

import json
import time

import pytest

from data.schemas import ChatTurn, IRSession


USER_ID = "550e8400-e29b-41d4-a716-446655440000"


class TestChatTurn:
    def test_fields_stored_correctly(self):
        turn = ChatTurn(
            turn=1,
            user_message="I manage $50M",
            iqc_response="What sectors?",
            timestamp="2025-01-01T10:00:00Z",
        )
        assert turn.turn         == 1
        assert turn.user_message == "I manage $50M"
        assert turn.iqc_response == "What sectors?"


class TestIRSession:
    def test_defaults(self):
        """IRSession has correct defaults when only user_id is provided."""
        s = IRSession(user_id=USER_ID)
        assert s.status         == "open"
        assert s.turn_number    == 0
        assert s.iqc_session_id == ""
        assert s.chat_history   == []

    def test_is_expired_false_when_fresh(self):
        """is_expired returns False for a just-created session."""
        s = IRSession(user_id=USER_ID)
        assert s.is_expired(ttl_seconds=3600) is False

    def test_is_expired_true_when_old(self):
        """is_expired returns True when started_at is older than TTL."""
        s = IRSession(user_id=USER_ID, started_at=time.time() - 7200)
        assert s.is_expired(ttl_seconds=3600) is True

    def test_append_turn_increments_counter(self):
        """append_turn increments turn_number and adds to chat_history."""
        s = IRSession(user_id=USER_ID)
        s.append_turn("Hello", "Hi!", "2025-01-01T10:00:00Z")
        assert s.turn_number    == 1
        assert len(s.chat_history) == 1
        assert s.chat_history[0].user_message == "Hello"

    def test_last_iqc_question_empty_when_no_turns(self):
        """last_iqc_question returns '' when chat_history is empty."""
        s = IRSession(user_id=USER_ID)
        assert s.last_iqc_question == ""

    def test_last_iqc_question_returns_latest(self):
        """last_iqc_question returns the iqc_response from the most recent turn."""
        s = IRSession(user_id=USER_ID)
        s.append_turn("msg1", "q1", "t1")
        s.append_turn("msg2", "q2", "t2")
        assert s.last_iqc_question == "q2"

    def test_to_db_dict_structure(self):
        """to_db_dict returns a serialisable dict suitable for PostgreSQL."""
        s = IRSession(user_id=USER_ID)
        s.append_turn("Hello", "Hi!", "2025-01-01T10:00:00Z")
        db = s.to_db_dict()

        assert db["user_id"]     == USER_ID
        assert db["turn_number"] == 1
        assert isinstance(db["chat_history"], list)
        # Verify JSON-serialisable
        assert json.dumps(db)

    def test_to_db_dict_chat_history_as_plain_dicts(self):
        """to_db_dict converts ChatTurn objects to plain dicts for JSON serialisation."""
        s = IRSession(user_id=USER_ID)
        s.append_turn("x", "y", "t")
        db = s.to_db_dict()
        turn = db["chat_history"][0]
        assert isinstance(turn, dict)
        assert "user_message" in turn
        assert "iqc_response" in turn
