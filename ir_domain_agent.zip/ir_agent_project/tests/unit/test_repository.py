"""
Module: tests/unit/test_repository.py
Description: Unit tests for IRSessionRepository.
             All psycopg2 connections are mocked — no real DB needed.
Author: IR Team
"""
from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from data.repository import IRSessionRepository
from data.schemas    import IRSession, ChatTurn


# ── Helpers ───────────────────────────────────────────────────────────────────

SAMPLE_USER_ID    = "550e8400-e29b-41d4-a716-446655440000"
SAMPLE_SESSION_ID = "660e8400-e29b-41d4-a716-446655440001"


def _make_row(overrides: dict = {}) -> MagicMock:
    """Build a RealDictRow-like MagicMock for psycopg2 fetch results."""
    from datetime import datetime, timezone
    base = {
        "user_id":        SAMPLE_USER_ID,
        "session_id":     SAMPLE_SESSION_ID,
        "iqc_session_id": "iqc-sid-abc",
        "status":         "qualifying",
        "started_at":     datetime.now(timezone.utc),
        "turn_number":    2,
        "chat_history":   json.dumps([
            {
                "turn": 1,
                "user_message": "I manage a $50M fund",
                "iqc_response": "What sectors?",
                "timestamp": "2025-01-01T10:00:00Z",
            }
        ]),
    }
    base.update(overrides)
    row = MagicMock()
    row.__getitem__ = lambda self, k: base[k]
    row.get         = lambda k, default=None: base.get(k, default)
    return row


def _mock_psycopg2(row=None, fetchone_return=None):
    """Return a context-manager-compatible psycopg2 mock."""
    conn = MagicMock()
    cur  = MagicMock()
    cur.fetchone.return_value = fetchone_return if fetchone_return is not None else row
    conn.cursor.return_value  = cur
    return conn, cur


# ── load_active ───────────────────────────────────────────────────────────────

class TestLoadActive:
    def test_returns_session_when_found(self):
        """load_active returns IRSession when a row exists."""
        repo = IRSessionRepository()
        row  = _make_row()
        conn, _ = _mock_psycopg2(row=row)

        with patch.object(repo, "_conn", return_value=conn):
            session = repo.load_active(SAMPLE_USER_ID)

        assert session is not None
        assert session.user_id    == SAMPLE_USER_ID
        assert session.status     == "qualifying"
        assert session.turn_number == 2

    def test_returns_none_when_not_found(self):
        """load_active returns None when no row exists."""
        repo = IRSessionRepository()
        conn, _ = _mock_psycopg2(fetchone_return=None)

        with patch.object(repo, "_conn", return_value=conn):
            session = repo.load_active(SAMPLE_USER_ID)

        assert session is None

    def test_returns_none_on_db_error(self):
        """load_active returns None gracefully on DB error."""
        repo = IRSessionRepository()

        with patch.object(repo, "_conn", side_effect=Exception("DB down")):
            session = repo.load_active(SAMPLE_USER_ID)

        assert session is None

    def test_parses_chat_history(self):
        """load_active correctly parses JSON chat_history."""
        repo = IRSessionRepository()
        row  = _make_row()
        conn, _ = _mock_psycopg2(row=row)

        with patch.object(repo, "_conn", return_value=conn):
            session = repo.load_active(SAMPLE_USER_ID)

        assert len(session.chat_history) == 1
        assert session.chat_history[0].user_message == "I manage a $50M fund"


# ── load_history ──────────────────────────────────────────────────────────────

class TestLoadHistory:
    def test_returns_session_from_history(self):
        """load_history reconstructs an IRSession from ir_session_history."""
        from datetime import datetime, timezone
        repo = IRSessionRepository()
        row  = _make_row({
            "turns": json.dumps([
                {
                    "turn": 1,
                    "user_message": "I invest in SaaS",
                    "iqc_response": "What stage?",
                    "timestamp": "2025-01-01T10:00:00Z",
                }
            ]),
            "final_status": "qualifying",
            "started_at":   datetime.now(timezone.utc),
        })
        conn, _ = _mock_psycopg2(row=row)

        with patch.object(repo, "_conn", return_value=conn):
            session = repo.load_history(SAMPLE_USER_ID)

        assert session is not None
        assert session.turn_number == 1
        assert session.status in ("qualifying", "open")

    def test_returns_none_when_no_history(self):
        """load_history returns None when no history rows exist."""
        repo    = IRSessionRepository()
        conn, _ = _mock_psycopg2(fetchone_return=None)

        with patch.object(repo, "_conn", return_value=conn):
            session = repo.load_history(SAMPLE_USER_ID)

        assert session is None


# ── upsert_active ─────────────────────────────────────────────────────────────

class TestUpsertActive:
    def test_calls_delete_then_insert(self):
        """upsert_active issues DELETE then INSERT in the correct order."""
        repo    = IRSessionRepository()
        conn    = MagicMock()
        cur     = MagicMock()
        conn.cursor.return_value = cur

        session = IRSession(
            user_id=    SAMPLE_USER_ID,
            session_id= SAMPLE_SESSION_ID,
            status=     "qualifying",
            turn_number= 1,
        )

        with patch.object(repo, "_conn", return_value=conn):
            repo.upsert_active(session)

        # Check two execute calls were made (DELETE + INSERT)
        assert cur.execute.call_count == 2
        first_sql  = cur.execute.call_args_list[0][0][0].strip().upper()
        second_sql = cur.execute.call_args_list[1][0][0].strip().upper()
        assert first_sql.startswith("DELETE")
        assert second_sql.startswith("INSERT")
        conn.commit.assert_called_once()

    def test_raises_database_error_on_failure(self):
        """upsert_active raises DatabaseError when psycopg2 raises."""
        from services.exceptions import DatabaseError
        repo    = IRSessionRepository()
        session = IRSession(user_id=SAMPLE_USER_ID)

        with patch.object(repo, "_conn", side_effect=Exception("insert failed")):
            with pytest.raises(DatabaseError):
                repo.upsert_active(session)


# ── archive_and_delete ────────────────────────────────────────────────────────

class TestArchiveAndDelete:
    def test_calls_insert_then_delete(self):
        """archive_and_delete issues INSERT into history then DELETE from active."""
        repo    = IRSessionRepository()
        conn    = MagicMock()
        cur     = MagicMock()
        conn.cursor.return_value = cur

        session = IRSession(
            user_id=    SAMPLE_USER_ID,
            session_id= SAMPLE_SESSION_ID,
            status=     "closed",
            turn_number= 3,
        )

        with patch.object(repo, "_conn", return_value=conn):
            repo.archive_and_delete(session, end_reason="exit")

        assert cur.execute.call_count == 2
        first_sql  = cur.execute.call_args_list[0][0][0].strip().upper()
        second_sql = cur.execute.call_args_list[1][0][0].strip().upper()
        assert first_sql.startswith("INSERT")
        assert second_sql.startswith("DELETE")
        conn.commit.assert_called_once()


# ── _parse_chat_history ───────────────────────────────────────────────────────

class TestParseChatHistory:
    def test_parses_json_string(self):
        raw = json.dumps([{"turn": 1, "user_message": "hi", "iqc_response": "hello", "timestamp": "t"}])
        result = IRSessionRepository._parse_chat_history(raw)
        assert len(result) == 1
        assert result[0]["user_message"] == "hi"

    def test_returns_list_unchanged(self):
        raw    = [{"turn": 1, "user_message": "hi", "iqc_response": "hello", "timestamp": "t"}]
        result = IRSessionRepository._parse_chat_history(raw)
        assert result == raw

    def test_returns_empty_for_none(self):
        assert IRSessionRepository._parse_chat_history(None) == []

    def test_returns_empty_for_bad_json(self):
        assert IRSessionRepository._parse_chat_history("not-json") == []
