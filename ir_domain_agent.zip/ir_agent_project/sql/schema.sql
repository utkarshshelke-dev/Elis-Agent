-- =============================================================================
-- IR Domain Agent — PostgreSQL DDL
-- Run once against the target database to set up the required tables.
-- Both tables use REPLICA IDENTITY FULL for logical replication (CDC).
-- =============================================================================

-- ── ir_active_sessions ──────────────────────────────────────────────────────
-- One row per active investor conversation.
-- Deleted (moved to history) when session closes or expires.
-- PRIMARY KEY on user_id — one active session per user at a time.

CREATE TABLE IF NOT EXISTS public.ir_active_sessions (
    user_id         UUID         NOT NULL,
    session_id      UUID         NOT NULL DEFAULT gen_random_uuid(),
    iqc_session_id  TEXT         NOT NULL DEFAULT '',
    status          VARCHAR(20)  NOT NULL DEFAULT 'open',
    started_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    turn_number     INTEGER      NOT NULL DEFAULT 0,
    chat_history    JSONB        NOT NULL DEFAULT '[]'::jsonb,
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT ir_active_sessions_pkey PRIMARY KEY (user_id)
);

-- Enable logical replication (required for Pub/Sub CDC change data capture)
ALTER TABLE public.ir_active_sessions REPLICA IDENTITY FULL;

CREATE INDEX IF NOT EXISTS idx_ir_active_sessions_status
    ON public.ir_active_sessions (status);


-- ── ir_session_history ──────────────────────────────────────────────────────
-- Closed sessions archived here after close_session() or expiry.
-- Always INSERTs a fresh row (no ON CONFLICT) — ORDER BY inserted_at DESC
-- ensures load_history() always retrieves the most recent session.
-- The turns column stores the full chat_history JSONB array.

CREATE TABLE IF NOT EXISTS public.ir_session_history (
    id              BIGSERIAL    PRIMARY KEY,
    session_id      UUID         NOT NULL,
    user_id         UUID         NOT NULL,
    iqc_session_id  TEXT         NOT NULL DEFAULT '',
    started_at      TIMESTAMPTZ  NOT NULL,
    ended_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    end_reason      VARCHAR(20)  NOT NULL DEFAULT 'exit',
    turns           JSONB        NOT NULL DEFAULT '[]'::jsonb,
    final_status    VARCHAR(20)  NOT NULL DEFAULT 'closed',
    inserted_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Enable logical replication
ALTER TABLE public.ir_session_history REPLICA IDENTITY FULL;

-- Index for fast user history lookup (ORDER BY inserted_at DESC LIMIT 1)
CREATE INDEX IF NOT EXISTS idx_ir_session_history_user_inserted
    ON public.ir_session_history (user_id, inserted_at DESC);

CREATE INDEX IF NOT EXISTS idx_ir_session_history_session
    ON public.ir_session_history (session_id);
