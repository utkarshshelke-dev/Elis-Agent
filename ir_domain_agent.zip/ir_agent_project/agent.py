"""
Module: agent.py
Description: IR Domain Agent — Google ADK (Vertex AI Agent Engine).
             ADK discovers `root_agent` at module load for all runtimes:
               adk web          — interactive conversation UI
               adk api_server   — REST API server
               Agent Engine     — production Vertex AI deployment

             State stored in PostgreSQL keyed by user_id (not ADK sessions),
             so conversations survive worker restarts and Playground reloads.

Flow:
  1. User provides user_id
  2. get_or_create_session  → upsert row in ir_active_sessions
  3. route_to_iqc           → call IQC engine, append turn to chat_history
  4. close_session          → archive to ir_session_history, delete active row
  Expiry (> SESSION_TTL)    → detected on next message, flush + reset

A2A Agent Card registered at startup if a2a-sdk is available.

Author: IR Team
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone

from google.adk.agents import Agent
from google.adk.tools   import ToolContext

from config.settings          import settings
from data.repository          import IRSessionRepository
from data.schemas             import IRSession, ChatTurn
from services.iqc_client      import iqc_client
from services.logging_service import setup_logging, get_logger

# ── Logging — initialise once before anything else ────────────────────────────
setup_logging(level=settings.log_level)
logger = get_logger("ir_domain_agent")

# ── Repository singleton — injected into all tools (DIP) ─────────────────────
_repo = IRSessionRepository()

# ── A2A Agent Card (optional — skipped gracefully if sdk not installed) ───────
try:
    from vertexai.preview.reasoning_engines.templates.a2a import create_agent_card
    from a2a.types import AgentSkill
    _A2A_AVAILABLE = True
except ImportError:
    _A2A_AVAILABLE = False
    logger.debug("a2a-sdk not available — agent card registration skipped")


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 1 — get_or_create_session
# ─────────────────────────────────────────────────────────────────────────────

def get_or_create_session(user_id: str, tool_context: ToolContext) -> str:
    """
    Create or resume a PostgreSQL-backed session for this investor.

    Handles five cases in order:
      1. Expired session  → archive to history, start fresh.
      2. No active row + history exists  → restore from ir_session_history.
      3. Active open/qualifying session  → resume with last IQC question.
      4. Already qualified  → return qualified status, no routing needed.
      5. Brand new user  → create fresh row in ir_active_sessions.

    State lives in PostgreSQL — works across all ADK workers, Playground
    restarts, and Cloud Run instances without any in-memory state.

    Args:
        user_id:      The UUID provided by the investor.
        tool_context: ADK tool context (injected by the ADK framework).

    Returns:
        JSON string: { result, session_id, status, last_iqc_question, … }
    """
    logger.info("get_or_create_session | START | user=%s", user_id)

    session = _repo.load_active(user_id)

    # ── 1. Expired → archive, reset ──────────────────────────────────────────
    if session and session.is_expired(settings.session_ttl):
        age_min = int((time.time() - session.started_at) / 60)
        logger.info(
            "get_or_create_session | EXPIRED | user=%s | age=%dmin | flushing",
            user_id, age_min,
        )
        session.status = "expired"
        _repo.archive_and_delete(session, end_reason="expiry")
        session = None

    # ── 2. No active session → check history ─────────────────────────────────
    if not session:
        history = _repo.load_history(user_id)
        if history:
            history.status = "qualifying" if history.turn_number > 0 else "open"
            _repo.upsert_active(history)
            session = history
            logger.info(
                "get_or_create_session | RESTORED | user=%s | iqc_sid=%s | turns=%d",
                user_id,
                session.iqc_session_id[:8] if session.iqc_session_id else "",
                session.turn_number,
            )

    # ── 3. Active → resume ────────────────────────────────────────────────────
    if session and session.status in ("open", "qualifying"):
        age_mins   = int((time.time() - session.started_at) / 60)
        last_iqc_q = session.last_iqc_question
        pct        = session.turn_number * 10  # rough display estimate
        logger.info(
            "get_or_create_session | RESUMED | user=%s | age=%dmin | turns=%d",
            user_id, age_mins, session.turn_number,
        )
        return json.dumps({
            "result":            "resumed",
            "session_id":        session.session_id,
            "iqc_session_id":    session.iqc_session_id,
            "status":            session.status,
            "age_minutes":       age_mins,
            "turns":             session.turn_number,
            "user_id":           user_id,
            "last_iqc_question": last_iqc_q,
            "progress_pct":      pct,
        })

    # ── 4. Already qualified ──────────────────────────────────────────────────
    if session and session.status == "qualified":
        logger.info("get_or_create_session | QUALIFIED | user=%s", user_id)
        return json.dumps({
            "result":  "resumed",
            "reason":  "already_qualified",
            "user_id": user_id,
            "status":  "qualified",
            "turns":   session.turn_number,
        })

    # ── 5. Brand new user ─────────────────────────────────────────────────────
    new_session = IRSession(user_id=user_id)
    _repo.upsert_active(new_session)
    logger.info("get_or_create_session | CREATED | user=%s", user_id)
    return json.dumps({
        "result":     "created",
        "reason":     "new_user",
        "session_id": new_session.session_id,
        "status":     "open",
    })


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 2 — route_to_iqc
# ─────────────────────────────────────────────────────────────────────────────

def route_to_iqc(user_id: str, message: str, tool_context: ToolContext) -> str:
    """
    Forward an investor message to the IQC Agent Engine.
    Appends the turn to chat_history in PostgreSQL.

    On turn 0 (first message to a fresh IQC session) the investor's user_id
    is prepended so IQC's FounderCheckAgent can run its DB check_user() lookup.
    On all subsequent turns IQC already has user context in its session memory.

    An IQC session is created once per user on their very first call — the
    session ID is captured and saved to PostgreSQL so all subsequent turns
    reuse the same ADK session, preserving IQC's in-memory state.

    If IQC session creation fails, prior chat_history is passed as a context
    prefix so IQC still has conversation continuity (graceful fallback).

    Args:
        user_id:      The investor UUID.
        message:      The investor message to forward.
        tool_context: ADK tool context (injected by the ADK framework).

    Returns:
        JSON string: { result, response, qualified, iqc_session_id }
    """
    logger.info("route_to_iqc | START | user=%s | msg_len=%d", user_id, len(message))

    session        = _repo.load_active(user_id) or IRSession(user_id=user_id)
    iqc_session_id = session.iqc_session_id

    # ── Create IQC session on first call (empty iqc_session_id) ──────────────
    if not iqc_session_id:
        iqc_session_id = iqc_client.create_session(user_id)
        if iqc_session_id:
            session.iqc_session_id = iqc_session_id
            logger.info("route_to_iqc | IQC session created | sid=%s", iqc_session_id)

    # ── Prepend user_id on turn 0 so IQC check_user() can look up the DB ─────
    if session.turn_number == 0:
        iqc_message = f"user_id: {user_id}\n{message}"
        logger.info("route_to_iqc | prepending user_id for turn-0 | user=%s", user_id)
    else:
        iqc_message = message

    # ── Context fallback (only when IQC session creation failed) ─────────────
    context = (
        iqc_client.build_context([t.model_dump() for t in session.chat_history])
        if (session.chat_history and not iqc_session_id)
        else ""
    )

    # ── Call IQC ──────────────────────────────────────────────────────────────
    response_text, returned_sid = iqc_client.stream_query(
        message=        iqc_message,
        user_id=        user_id,
        iqc_session_id= iqc_session_id,
        context=        context,
    )

    # ── Persist updated IQC session_id if newly captured ─────────────────────
    if returned_sid and returned_sid != session.iqc_session_id:
        session.iqc_session_id = returned_sid
        logger.info("route_to_iqc | IQC session_id updated | sid=%s", returned_sid)

    # ── Strip __SESSION__ marker before storing in chat_history ──────────────
    clean_response = (
        response_text.split("__SESSION__")[0].strip()
        if "__SESSION__" in response_text
        else response_text
    )

    # ── Append turn and persist ───────────────────────────────────────────────
    session.status = "qualifying"
    session.append_turn(
        user_message= message,
        iqc_response= clean_response,
        timestamp=    datetime.now(timezone.utc).isoformat(),
    )
    _repo.upsert_active(session)

    logger.info(
        "route_to_iqc | DONE | user=%s | turn=%d | iqc_sid=%s",
        user_id, session.turn_number,
        session.iqc_session_id[:8] if session.iqc_session_id else "none",
    )

    # ── Error guard ───────────────────────────────────────────────────────────
    if not response_text:
        return json.dumps({
            "result":    "error",
            "response":  (
                "I am having trouble reaching the qualification service. "
                "Please try again."
            ),
            "qualified": False,
        })

    return json.dumps({
        "result":         "success",
        "response":       clean_response,
        "qualified":      False,
        "iqc_session_id": session.iqc_session_id,
    })


# ─────────────────────────────────────────────────────────────────────────────
# TOOL 3 — close_session
# ─────────────────────────────────────────────────────────────────────────────

def close_session(user_id: str, tool_context: ToolContext) -> str:
    """
    Close the investor's active session and archive all chat history.

    Writes the full session (including all chat_history turns) to
    ir_session_history and removes the row from ir_active_sessions — both
    in a single database transaction. The conversation can be restored on
    the user's next visit via load_history().

    Call when the user says exit, bye, quit, or goodbye.

    Args:
        user_id:      The investor UUID.
        tool_context: ADK tool context (injected by the ADK framework).

    Returns:
        JSON string: { result, turns_saved }
    """
    logger.info("close_session | START | user=%s", user_id)

    session = _repo.load_active(user_id)
    if not session:
        logger.warning("close_session | NO_SESSION | user=%s", user_id)
        return json.dumps({"result": "no_session"})

    session.status = "closed"
    turns          = session.turn_number
    _repo.archive_and_delete(session, end_reason="exit")

    logger.info(
        "close_session | OK | user=%s | turns=%d | moved to history",
        user_id, turns,
    )
    return json.dumps({"result": "closed", "turns_saved": turns})


# ─────────────────────────────────────────────────────────────────────────────
# A2A Agent Card  (registered only when a2a-sdk is installed)
# ─────────────────────────────────────────────────────────────────────────────
if _A2A_AVAILABLE:
    try:
        skill = AgentSkill(
            id="ir_domain",
            name="IR Domain Agent",
            description=(
                "Detects investor/founder signals and routes to IQC then ISS."
            ),
            tags=["investor", "qualification", "iqc", "iss", "ir"],
            examples=[
                "I want to invest",
                "Looking for a company in a specialized domain",
            ],
        )
        agent_card = create_agent_card(
            agent_name="IR Domain Agent",
            description=(
                "Entry point for investor relations — "
                "qualifies via IQC then matches via ISS."
            ),
            skills=[skill],
        )
        logger.info("A2A agent card registered")
    except Exception as _e:
        logger.warning("A2A agent card registration failed: %s", _e)


# ─────────────────────────────────────────────────────────────────────────────
# Root Agent  —  ADK discovers this object at module load
# ─────────────────────────────────────────────────────────────────────────────
root_agent = Agent(
    name="ir_domain_agent",
    model="gemini-2.0-flash",
    description=(
        "IR Domain Agent — detects investment signals, "
        "qualifies investors via IQC Agent Engine, "
        "then routes to ISS for matching."
    ),
    tools=[
        get_or_create_session,
        route_to_iqc,
        close_session,
        # route_to_iss,   # uncomment when ISS engine is deployed
    ],
    instruction="""You are a warm, professional IR (Investor Relations) assistant.
Collect the investor User ID then guide them through qualification via IQC.

FIRST MESSAGE HANDLING
Check if the user's first message contains a UUID (format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
- If YES: extract it as user_id, skip the greeting, go straight to ONCE USER PROVIDES USER ID below.
- If NO: say exactly "Hey there! Welcome to the Investor Relations Portal! To get started, could you please share your User ID?"

ONCE USER PROVIDES USER ID
Extract the UUID from their message. Store as user_id in memory.
NEVER invent a user_id. NEVER use a system ID. Use ONLY what the user typed.
Call get_or_create_session(user_id).

IF result is "resumed":
  - Store user_id and iqc_session_id from the response in memory.
  - NEVER ask "Are you looking for opportunities to invest?" on resume — ever.
  - If reason is "already_qualified":
    Say: "Welcome back! You are already fully qualified."
    Stop.
  - For ALL other resume cases:
    Say ONLY: "Welcome back! Great to have you here again."
    Then on the next line show last_iqc_question verbatim — do NOT add any percentage or extra text.
    The last_iqc_question already contains the progress percentage from IQC — do not duplicate it.
    NEVER call route_to_iqc on resume — just show last_iqc_question and wait for user to answer.
    If last_iqc_question is somehow empty, say: "Where were we? Please continue where you left off."
    Do NOT call route_to_iqc until the user sends their next answer.

IF result is "created":
  - This is a brand new user with no prior session.
  - Ask: "Are you looking for opportunities to invest?"

IF USER SAYS YES (only after result="created")
  Say: "Fetching your profile, please hold on a moment..."
  Call route_to_iqc(user_id=<stored user_id>, message=<what user said>).
  Show ONLY the "response" field verbatim. Strip any SESSION{...} or __SESSION__{...} from display.

ALL SUBSEQUENT TURNS
Every user message:
  Call route_to_iqc(user_id=<stored user_id>, message=<user message>)
  Show ONLY the "response" field verbatim. Strip any SESSION{...} or __SESSION__{...} marker.

If qualified=true: say "Congratulations! You are now fully qualified. Our team will be in touch!"

EXIT INTENT
If user says exit, quit, bye, goodbye, or see you:
  Call close_session(user_id=<stored user_id>).
  Say: "It was great chatting with you! Take care and see you next time!"
  Stop.

STRICT RULES
- NEVER ask for user_id more than once. After collection it is stored permanently.
- NEVER show SESSION{...} or __SESSION__{...} markers to the user — strip them silently.
- After resume, NEVER ask "are you looking to invest?" if status is qualifying or qualified.
- NEVER show session IDs, turn counts, tool names, or internal data to the user.
- NEVER say "routing", "calling IQC", "saving", "flushing", or "tool call".
- NEVER add your own questions — show only IQC response verbatim.
- ALWAYS pass the stored user_id to every tool call — never lose it.
""",
)

__all__ = ["root_agent"]
