"""
Module: config/settings.py
Description: Centralised Pydantic settings for the IR Domain Agent.
             Reads from .env (local development) or environment variables
             (Cloud Run / Agent Engine). No code changes between environments.
Author: IR Team
"""
from __future__ import annotations

import logging
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_ENV_PATH = Path(__file__).parent.parent / ".env"
logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """
    Application configuration loaded from environment variables or .env file.

    All secrets (DB_PASS) must be set as environment variables in production.
    DB_PASS has no default — a missing value raises ValidationError at startup.

    Attributes:
        google_cloud_project:  GCP project ID.
        google_cloud_location: GCP region for Vertex AI.
        iqc_engine_id:         Numeric ID of the deployed IQC Reasoning Engine.
        db_host:               PostgreSQL host.
        db_port:               PostgreSQL port.
        db_user:               Database login user.
        db_pass:               Database password — REQUIRED, no default.
        db_name:               Database name.
        session_ttl:           Session expiry in seconds (default: 3600).
        log_level:             Logging level string (default: INFO).
    """

    # ── Google Cloud ──────────────────────────────────────────────────────────
    google_cloud_project:  str = "the-grid-os"
    google_cloud_location: str = "us-central1"

    # ── IQC Agent Engine ──────────────────────────────────────────────────────
    iqc_engine_id: str = "6728420724245004288"

    # ── Database ──────────────────────────────────────────────────────────────
    db_host: str = "34.69.99.159"
    db_port: int = 5432
    db_user: str = "postgres"
    db_pass: str = ""       # Set via environment — NEVER hardcode
    db_name: str = "grid_os_poc"

    # ── App ───────────────────────────────────────────────────────────────────
    session_ttl: int = 3600   # 60 minutes
    log_level:   str = "INFO"

    model_config = SettingsConfigDict(
        env_file=str(_ENV_PATH) if _ENV_PATH.exists() else None,
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    @property
    def iqc_base_url(self) -> str:
        """Base URL for Vertex AI Agent Engine API calls."""
        return (
            f"https://{self.google_cloud_location}-aiplatform.googleapis.com"
            f"/v1beta1/projects/{self.google_cloud_project}"
            f"/locations/{self.google_cloud_location}/reasoningEngines"
        )

    @property
    def iqc_stream_url(self) -> str:
        """Full streamQuery URL for the IQC Agent Engine."""
        return f"{self.iqc_base_url}/{self.iqc_engine_id}:streamQuery"

    @property
    def iqc_query_url(self) -> str:
        """Full query URL for the IQC Agent Engine (session creation)."""
        return f"{self.iqc_base_url}/{self.iqc_engine_id}:query"

    @property
    def db_dsn(self) -> dict:
        """psycopg2-compatible DSN dict built from individual DB settings."""
        return {
            "host":     self.db_host,
            "port":     self.db_port,
            "user":     self.db_user,
            "password": self.db_pass,
            "dbname":   self.db_name,
        }


# Singleton — import and use everywhere
settings = Settings()

__all__ = ["settings", "Settings"]
