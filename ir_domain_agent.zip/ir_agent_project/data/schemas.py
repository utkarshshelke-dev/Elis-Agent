"""
Module: data/schemas.py
Description: Pydantic models for IR Domain Agent session data.
             Pure data shapes — no business logic.
Author: IR Team
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ChatTurn(BaseModel):
    """
    A single conversation turn stored in chat_history.

    Attributes:
        turn:          Turn number (1-based).
        user_message:  Raw message sent by the investor.
        iqc_response:  Cleaned response received from IQC.
        timestamp:     ISO-8601 UTC timestamp of the turn.
    """
    turn:         int
    user_message: str
    iqc_response: str
    timestamp:    str


class IRSession(BaseModel):
    """
    Active IR session stored in ir_active_sessions.

    Attributes:
        user_id:        Investor UUID.
        session_id:     IR session UUID (unique per conversation).
        iqc_session_id: IQC Agent Engine session ID (captured after first call).
        status:         One of: 'open', 'qualifying', 'qualified', 'closed', 'expired'.
        started_at:     Unix timestamp of session creation.
        turn_number:    Number of completed turns.
        chat_history:   Ordered list of ChatTurn objects.
    """
    user_id:        str
    session_id:     str  = Field(default_factory=lambda: str(uuid.uuid4()))
    iqc_session_id: str  = ""
    status:         str  = "open"
    started_at:     float = Field(default_factory=time.time)
    turn_number:    int  = 0
    chat_history:   List[ChatTurn] = Field(default_factory=list)

    def is_expired(self, ttl_seconds: int = 3600) -> bool:
        """
        Return True if the session has exceeded its TTL.

        Args:
            ttl_seconds: Maximum session age in seconds.

        Returns:
            True if expired.
        """
        return (time.time() - self.started_at) > ttl_seconds

    def append_turn(
        self,
        user_message: str,
        iqc_response: str,
        timestamp:    str,
    ) -> None:
        """
        Append a new turn and increment the turn counter.

        Args:
            user_message: Raw investor message.
            iqc_response: Cleaned IQC response.
            timestamp:    ISO-8601 UTC timestamp.
        """
        self.turn_number += 1
        self.chat_history.append(
            ChatTurn(
                turn=self.turn_number,
                user_message=user_message,
                iqc_response=iqc_response,
                timestamp=timestamp,
            )
        )

    @property
    def last_iqc_question(self) -> str:
        """Return the last IQC response, or empty string if no turns yet."""
        if self.chat_history:
            return self.chat_history[-1].iqc_response
        return ""

    def to_db_dict(self) -> Dict[str, Any]:
        """
        Serialise session to a dict suitable for PostgreSQL INSERT/UPDATE.

        Returns:
            Dict with all fields, chat_history as a list of plain dicts.
        """
        return {
            "user_id":        self.user_id,
            "session_id":     self.session_id,
            "iqc_session_id": self.iqc_session_id,
            "status":         self.status,
            "started_at":     self.started_at,
            "turn_number":    self.turn_number,
            "chat_history":   [t.model_dump() for t in self.chat_history],
        }


class SessionResult(BaseModel):
    """
    JSON response returned by get_or_create_session to the ADK agent.

    Attributes:
        result:            'created', 'resumed', or 'error'.
        reason:            Sub-reason (e.g. 'new_user', 'already_qualified').
        session_id:        IR session UUID.
        iqc_session_id:    IQC session ID (may be empty on first call).
        status:            Session status string.
        age_minutes:       Minutes since session was created.
        turns:             Number of completed turns.
        user_id:           Investor UUID.
        last_iqc_question: Last question from IQC (for resume display).
        progress_pct:      Rough progress percentage (turns × 10).
    """
    result:            str = ""
    reason:            str = ""
    session_id:        str = ""
    iqc_session_id:    str = ""
    status:            str = ""
    age_minutes:       int = 0
    turns:             int = 0
    user_id:           str = ""
    last_iqc_question: str = ""
    progress_pct:      int = 0


class RouteResult(BaseModel):
    """
    JSON response returned by route_to_iqc to the ADK agent.

    Attributes:
        result:         'success' or 'error'.
        response:       Cleaned IQC response text to show the investor.
        qualified:      True if IQC marked the investor as qualified.
        iqc_session_id: IQC session ID (updated if newly captured).
    """
    result:         str  = "success"
    response:       str  = ""
    qualified:      bool = False
    iqc_session_id: str  = ""


__all__ = ["ChatTurn", "IRSession", "SessionResult", "RouteResult"]
