"""
Module: data/repository.py
Description: Repository class for all IR Domain Agent database access.
             ALL SQL lives here — services never write raw SQL.
             Follows the Repository Pattern from the ADK Developer Guide.
             Uses DELETE + INSERT (not ON CONFLICT) because ir_active_sessions
             has REPLICA IDENTITY FULL for logical replication safety.
Author: IR Team
"""
from __future__ import annotations

import json
import logging
import time
from typing import Optional

import psycopg2
import psycopg2.extras

from config.settings import settings
from data.schemas import ChatTurn, IRSession
from services.exceptions import DatabaseError

logger = logging.getLogger(__name__)


class IRSessionRepository:
    """
    Data access layer for the IR Domain Agent session tables.

    Encapsulates all SQL against ir_active_sessions and ir_session_history.
    Uses psycopg2 directly (not SQLAlchemy) to match the original architecture
    and avoid the overhead of an ORM for simple session CRUD.

    Methods are synchronous — called via asyncio.to_thread() from the ADK tools
    when async isolation is needed.
    """

    # ── Private helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _conn():
        """
        Open a new psycopg2 connection using settings.db_dsn.
        Caller is responsible for calling close().

        Returns:
            psycopg2 connection object.

        Raises:
            DatabaseError: If the connection cannot be established.
        """
        try:
            return psycopg2.connect(**settings.db_dsn)
        except Exception as exc:
            raise DatabaseError(f"Cannot connect to database: {exc}") from exc

    @staticmethod
    def _parse_chat_history(raw) -> list:
        """
        Safely parse chat_history from DB — handles JSONB, str, or list.

        Args:
            raw: Raw value from PostgreSQL (JSONB, str, list, or None).

        Returns:
            List of turn dicts (possibly empty).
        """
        if raw is None:
            return []
        if isinstance(raw, list):
            return raw
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
                return parsed if isinstance(parsed, list) else []
            except Exception:
                return []
        return []

    # ── READ: active session ──────────────────────────────────────────────────

    def load_active(self, user_id: str) -> Optional[IRSession]:
        """
        Load the active session row for a user from ir_active_sessions.

        Args:
            user_id: Investor UUID string.

        Returns:
            IRSession if found, None otherwise.
        """
        logger.info("load_active | START | user=%s", user_id)
        start = time.perf_counter()
        try:
            c   = self._conn()
            cur = c.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute(
                "SELECT * FROM ir_active_sessions WHERE user_id = %s LIMIT 1",
                (user_id,),
            )
            row = cur.fetchone()
            cur.close()
            c.close()

            elapsed_ms = (time.perf_counter() - start) * 1000
            if not row:
                logger.info("load_active | NOT_FOUND | user=%s | ms=%.1f", user_id, elapsed_ms)
                return None

            ch = self._parse_chat_history(row.get("chat_history"))
            session = IRSession(
                user_id=        str(row["user_id"]),
                session_id=     str(row["session_id"]),
                iqc_session_id= str(row.get("iqc_session_id") or ""),
                status=         str(row["status"]),
                started_at=     float(row["started_at"].timestamp()),
                turn_number=    int(row["turn_number"]),
                chat_history=   [ChatTurn(**t) if isinstance(t, dict) else t for t in ch],
            )
            logger.info(
                "load_active | FOUND | user=%s | status=%s | turns=%d | ms=%.1f",
                user_id, session.status, session.turn_number, elapsed_ms,
            )
            return session

        except DatabaseError:
            raise
        except Exception as exc:
            logger.error("load_active | FAILED | user=%s | %s", user_id, exc)
            return None

    # ── READ: session history ─────────────────────────────────────────────────

    def load_history(self, user_id: str) -> Optional[IRSession]:
        """
        Load the most recent closed session from ir_session_history.
        Used to restore context when a user returns after expiry or close.

        Args:
            user_id: Investor UUID string.

        Returns:
            IRSession reconstructed from history, or None if no history found.
        """
        logger.info("load_history | START | user=%s", user_id)
        start = time.perf_counter()
        try:
            c   = self._conn()
            cur = c.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT session_id, user_id, iqc_session_id,
                       started_at, turns, final_status
                FROM   ir_session_history
                WHERE  user_id = %s
                ORDER  BY inserted_at DESC
                LIMIT  1
            """, (str(user_id),))
            row = cur.fetchone()
            cur.close()
            c.close()

            elapsed_ms = (time.perf_counter() - start) * 1000
            if not row:
                logger.info("load_history | NOT_FOUND | user=%s | ms=%.1f", user_id, elapsed_ms)
                return None

            ch = self._parse_chat_history(row.get("turns"))
            session = IRSession(
                user_id=        str(row["user_id"]),
                session_id=     str(row["session_id"]),
                iqc_session_id= str(row.get("iqc_session_id") or ""),
                status=         "qualifying" if len(ch) > 0 else "open",
                started_at=     float(row["started_at"].timestamp()) if row.get("started_at") else time.time(),
                turn_number=    len(ch),
                chat_history=   [ChatTurn(**t) if isinstance(t, dict) else t for t in ch],
            )
            logger.info(
                "load_history | FOUND | user=%s | iqc_sid=%s | turns=%d | ms=%.1f",
                user_id, session.iqc_session_id[:8] if session.iqc_session_id else "",
                session.turn_number, elapsed_ms,
            )
            return session

        except DatabaseError:
            raise
        except Exception as exc:
            logger.error("load_history | FAILED | user=%s | %s", user_id, exc)
            return None

    # ── WRITE: upsert active session ──────────────────────────────────────────

    def upsert_active(self, session: IRSession) -> None:
        """
        Upsert (DELETE + INSERT) the active session into ir_active_sessions.

        Uses DELETE + INSERT rather than ON CONFLICT because the table has
        REPLICA IDENTITY FULL for logical replication safety — UPDATE on
        replicated tables can cause issues with CDC pipelines.

        Args:
            session: IRSession to persist.

        Raises:
            DatabaseError: If the DB operation fails.
        """
        logger.info(
            "upsert_active | START | user=%s | status=%s | turns=%d",
            session.user_id, session.status, session.turn_number,
        )
        start = time.perf_counter()
        db = session.to_db_dict()
        try:
            c   = self._conn()
            cur = c.cursor()
            # DELETE first — replication-safe
            cur.execute(
                "DELETE FROM ir_active_sessions WHERE user_id = %s",
                (db["user_id"],),
            )
            cur.execute("""
                INSERT INTO ir_active_sessions
                    (user_id, session_id, iqc_session_id, status,
                     started_at, turn_number, chat_history, updated_at)
                VALUES
                    (%s, %s, %s, %s, to_timestamp(%s), %s, %s::jsonb, NOW())
            """, (
                db["user_id"],
                db["session_id"],
                db["iqc_session_id"],
                db["status"],
                db["started_at"],
                db["turn_number"],
                json.dumps(db["chat_history"]),
            ))
            c.commit()
            cur.close()
            c.close()

            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "upsert_active | OK | user=%s | turns=%d | ms=%.1f",
                session.user_id, session.turn_number, elapsed_ms,
            )
        except Exception as exc:
            logger.error("upsert_active | FAILED | user=%s | %s", session.user_id, exc)
            raise DatabaseError(f"upsert_active failed: {exc}") from exc

    # ── WRITE: archive and delete ─────────────────────────────────────────────

    def archive_and_delete(self, session: IRSession, end_reason: str) -> None:
        """
        Write the full session to ir_session_history and delete it from
        ir_active_sessions — both in the same database transaction.

        Always INSERTs a new history row (no ON CONFLICT) because
        ORDER BY inserted_at DESC in load_history always picks the latest.

        Args:
            session:    IRSession to archive.
            end_reason: Reason string: 'exit', 'expired', 'qualified'.

        Raises:
            DatabaseError: If the DB operation fails.
        """
        logger.info(
            "archive_and_delete | START | user=%s | reason=%s | turns=%d",
            session.user_id, end_reason, session.turn_number,
        )
        start = time.perf_counter()
        db = session.to_db_dict()
        try:
            c   = self._conn()
            cur = c.cursor()
            # INSERT into history (always a fresh row)
            cur.execute("""
                INSERT INTO ir_session_history
                    (session_id, user_id, iqc_session_id, started_at,
                     ended_at, end_reason, turns, final_status, inserted_at)
                VALUES
                    (%s, %s, %s, to_timestamp(%s), NOW(), %s, %s::jsonb, %s, NOW())
            """, (
                db["session_id"],
                db["user_id"],
                db["iqc_session_id"],
                db["started_at"],
                end_reason,
                json.dumps(db["chat_history"]),
                db["status"],
            ))
            # DELETE from active
            cur.execute(
                "DELETE FROM ir_active_sessions WHERE user_id = %s",
                (db["user_id"],),
            )
            c.commit()
            cur.close()
            c.close()

            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "archive_and_delete | OK | user=%s | reason=%s | turns=%d | ms=%.1f",
                session.user_id, end_reason, session.turn_number, elapsed_ms,
            )
        except Exception as exc:
            logger.error(
                "archive_and_delete | FAILED | user=%s | %s", session.user_id, exc
            )
            raise DatabaseError(f"archive_and_delete failed: {exc}") from exc


__all__ = ["IRSessionRepository"]
