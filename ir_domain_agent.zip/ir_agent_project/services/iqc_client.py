"""
Module: services/iqc_client.py
Description: HTTP client for the IQC Vertex AI Agent Engine.
             Encapsulates all Google OAuth2 auth, session creation,
             and streamQuery calls. The ADK tool functions never
             touch raw HTTP — they call this client only.
             SRP: this module is responsible only for IQC transport.
             DIP: injected into tool functions via module-level singleton.
Author: IR Team
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Optional, Tuple

import google.auth
import google.auth.transport.requests
import requests as _requests

from config.settings import settings
from services.exceptions import AuthTokenError, IQCCallError, IQCSessionCreateError

logger = logging.getLogger(__name__)

# Matches __SESSION__{"session_id": "..."} markers emitted by IQC
_SESSION_MARKER_RE = re.compile(r"__SESSION__(\{.*?\})", re.DOTALL)
# HTTP timeout (seconds) for IQC streaming calls
_STREAM_TIMEOUT = 120
_SESSION_CREATE_TIMEOUT = 30


class IQCClient:
    """
    HTTP client for the IQC Vertex AI Reasoning Engine.

    Handles authentication (Google Application Default Credentials),
    IQC session creation (one per user conversation), and message
    routing via the streamQuery endpoint.

    Usage:
        client = IQCClient()
        session_id = client.create_session(user_id)
        response, new_sid = client.stream_query(message, user_id, session_id)
    """

    # ── Auth ──────────────────────────────────────────────────────────────────

    def get_token(self) -> str:
        """
        Obtain a Google OAuth2 Bearer token using Application Default Credentials.

        Returns:
            Bearer token string.

        Raises:
            AuthTokenError: If credentials cannot be obtained or refreshed.
        """
        try:
            creds, _ = google.auth.default(
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )
            creds.refresh(google.auth.transport.requests.Request())
            return creds.token
        except Exception as exc:
            raise AuthTokenError(f"Failed to obtain auth token: {exc}") from exc

    def _auth_headers(self) -> dict:
        """Return Authorization + Content-Type headers."""
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type":  "application/json",
        }

    # ── IQC Session ───────────────────────────────────────────────────────────

    def create_session(self, user_id: str) -> str:
        """
        Create a new ADK session in the IQC Agent Engine for a user.
        Called once per user on their very first message — the session ID
        is saved to PostgreSQL and reused for all subsequent turns.

        Args:
            user_id: Investor UUID string.

        Returns:
            IQC session ID string, or empty string if creation fails
            (caller falls back to context-string approach).
        """
        logger.info("create_session | START | user=%s", user_id)
        start = time.perf_counter()
        try:
            resp = _requests.post(
                settings.iqc_query_url,
                headers=self._auth_headers(),
                json={
                    "class_method": "create_session",
                    "input":        {"user_id": user_id},
                },
                timeout=_SESSION_CREATE_TIMEOUT,
            )
            resp.raise_for_status()
            session_id = str(
                (resp.json().get("output") or {}).get("id", "")
            )
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "create_session | OK | user=%s | sid=%s | ms=%.1f",
                user_id, session_id, elapsed_ms,
            )
            return session_id
        except Exception as exc:
            logger.error("create_session | FAILED | user=%s | %s", user_id, exc)
            return ""

    # ── streamQuery ───────────────────────────────────────────────────────────

    def stream_query(
        self,
        message:        str,
        user_id:        str,
        iqc_session_id: str = "",
        context:        str = "",
    ) -> Tuple[str, str]:
        """
        Send a message to the IQC streamQuery endpoint and collect the response.

        Builds the payload, streams the response line-by-line, extracts the
        final LLM text, and captures any __SESSION__{...} marker that IQC
        includes to signal a new session ID.

        Args:
            message:        User message to forward (plain text).
            user_id:        Investor UUID (included in payload for IQC check_user).
            iqc_session_id: Existing IQC session ID — empty string on first call.
            context:        Prior conversation context (fallback when session lost).

        Returns:
            Tuple of (response_text, iqc_session_id).
            response_text is empty string on total failure.
            iqc_session_id is updated if a __SESSION__ marker was found.

        Raises:
            IQCCallError: Only on hard HTTP failures after retries (currently no retry).
        """
        # On first call (no session) prepend context if available
        full_message = (
            f"{context}\n\nUser: {message}"
            if (context and not iqc_session_id)
            else message
        )

        payload: dict = {
            "input": {
                "message": full_message,
                "user_id": user_id,
            }
        }
        if iqc_session_id:
            payload["input"]["session_id"] = iqc_session_id
            logger.info(
                "stream_query | -> IQC | user=%s | iqc_sid=%s", user_id, iqc_session_id
            )
        else:
            logger.info("stream_query | -> IQC | user=%s | (new session)", user_id)

        start = time.perf_counter()
        try:
            resp = _requests.post(
                settings.iqc_stream_url,
                headers=self._auth_headers(),
                json=payload,
                stream=True,
                timeout=_STREAM_TIMEOUT,
            )
            logger.info(
                "stream_query | <- IQC | status=%s | user=%s",
                resp.status_code, user_id,
            )
            resp.raise_for_status()

            if not resp.text.strip():
                logger.warning("stream_query | EMPTY_RESPONSE | user=%s", user_id)
                return "", iqc_session_id

            final_text      = ""
            captured_sid    = iqc_session_id

            for raw_line in resp.text.strip().splitlines():
                line = (raw_line or "").strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                    for part in event.get("content", {}).get("parts", []):
                        # Extract IQC session_id from tool_response events
                        fn_resp = part.get("function_response", {})
                        if fn_resp:
                            resp_data = fn_resp.get("response", {})
                            if isinstance(resp_data, str):
                                try:
                                    resp_data = json.loads(resp_data)
                                except Exception:
                                    resp_data = {}
                            sid = resp_data.get("session_id", "")
                            if sid and not captured_sid:
                                captured_sid = sid
                                logger.info(
                                    "stream_query | session_id captured | sid=%s", sid
                                )
                        # Extract final LLM text
                        t = part.get("text", "").strip()
                        if t:
                            final_text = t

                    # Fallback text fields
                    if not final_text:
                        for key in ("text", "output", "message", "response", "answer"):
                            val = event.get(key)
                            if val and isinstance(val, str) and val.strip():
                                final_text = val.strip()
                                break
                except json.JSONDecodeError:
                    if line and not line.startswith("{"):
                        final_text = line

            # Extract __SESSION__ marker from response text if present
            if final_text:
                m = _SESSION_MARKER_RE.search(final_text)
                if m:
                    try:
                        sid = json.loads(m.group(1)).get("session_id", "")
                        if sid:
                            captured_sid = sid
                            logger.info(
                                "stream_query | __SESSION__ marker | sid=%s", sid
                            )
                    except Exception:
                        pass

            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "stream_query | DONE | user=%s | sid=%s | chars=%d | ms=%.1f",
                user_id, captured_sid or "none",
                len(final_text), elapsed_ms,
            )
            return final_text, captured_sid

        except Exception as exc:
            logger.error("stream_query | FAILED | user=%s | %s", user_id, exc)
            return "", iqc_session_id

    # ── Context builder ───────────────────────────────────────────────────────

    @staticmethod
    def build_context(chat_history: list) -> str:
        """
        Build a compact context string from prior turns for IQC's first message.
        Only used when IQC session creation fails (fallback path).

        Args:
            chat_history: List of ChatTurn-like dicts from the IR session.

        Returns:
            Formatted context string, or empty string if no history.
        """
        if not chat_history:
            return ""
        lines = [
            "Previous conversation summary "
            "(for context only — do not repeat these questions):"
        ]
        for turn in chat_history:
            if isinstance(turn, dict):
                u = turn.get("user_message", "").strip()
                r = turn.get("iqc_response",  "").strip()
            else:
                u = getattr(turn, "user_message", "").strip()
                r = getattr(turn, "iqc_response",  "").strip()
            if u:
                lines.append(f"  User: {u}")
            if r:
                lines.append(f"  Assistant: {r}")
        return "\n".join(lines)


# Module-level singleton — import and use in tools
iqc_client = IQCClient()

__all__ = ["IQCClient", "iqc_client"]
