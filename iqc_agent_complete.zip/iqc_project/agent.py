"""
Module: agent.py
Description: ADK entry point for the IQC (Investor Qualification Conversation) Agent.
             This is the ONLY file ADK needs when running:
               adk web          — interactive conversation UI
               adk api_server   — REST API server
             root_agent is discovered automatically by ADK at module load.
             If the database is unavailable at import time (DB_PASS not set),
             root_agent is a fallback agent that returns a helpful error message
             rather than crashing.
Author: IQC Team
"""
from __future__ import annotations

import logging

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event
from google.genai import types as genai_types

from config.settings import settings
from data.engine import get_engine
from data.repository import PostgresRepo
from services.logging_service import setup_logging
from services.pipeline_service import build_investor_qualification_agent

# ── Initialise logging before anything else ───────────────────────────────────
setup_logging(level=settings.log_level, log_dir=settings.log_dir)
logger = logging.getLogger(__name__)


# ── Fallback agent (when DB is unavailable) ───────────────────────────────────

class DatabaseUnavailableAgent(BaseAgent):
    """
    Fallback agent returned when the database engine is None.
    Returns a helpful configuration error message instead of crashing ADK.
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(name="db_unavailable", **kwargs)

    async def _run_async_impl(self, ctx: InvocationContext):
        if False:
            yield  # AsyncGenerator typing requirement
        msg = (
            "Database connection is not configured.\n\n"
            "Please set the following environment variables:\n"
            "  DB_HOST  — PostgreSQL host\n"
            "  DB_PORT  — PostgreSQL port (default: 5432)\n"
            "  DB_USER  — Database user\n"
            "  DB_PASS  — Database password (REQUIRED)\n"
            "  DB_NAME  — Database name\n\n"
            "For Agent Engine, set these via Cloud Run secrets or environment variables."
        )
        yield Event(
            invocation_id=ctx.invocation_id,
            author=self.name,
            content=genai_types.Content(
                role="model",
                parts=[genai_types.Part(text=msg)],
            ),
        )


# ── ADK root agent factory ────────────────────────────────────────────────────

def _build_root_agent() -> BaseAgent:
    """
    Build the root_agent for ADK playground and Agent Engine.

    Returns the full pipeline if DB is available.
    Returns DatabaseUnavailableAgent if DB_PASS is missing or DB is unreachable.

    Returns:
        BaseAgent: Always returns a valid agent — never None.
    """
    try:
        engine = get_engine()
        if engine is None:
            logger.warning(
                "_build_root_agent | db_engine is None — using DatabaseUnavailableAgent"
            )
            return DatabaseUnavailableAgent()

        repo  = PostgresRepo(engine)
        agent = build_investor_qualification_agent(repo)
        logger.info("_build_root_agent | SUCCESS | agent=%s", agent.name)
        return agent

    except Exception as exc:
        logger.warning("_build_root_agent | FAILED | %s | using fallback", exc)
        return DatabaseUnavailableAgent()


# ADK discovers this variable automatically at module load
root_agent = _build_root_agent()

__all__ = ["root_agent"]
