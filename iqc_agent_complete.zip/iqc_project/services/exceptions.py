"""
Module: services/exceptions.py
Description: Domain-specific exception hierarchy for the IQC agent.
             Import and raise these instead of bare Exception so callers
             can catch exactly what they expect.
Author: IQC Team
"""
from __future__ import annotations


class IQCBaseException(Exception):
    """Base exception for all IQC agent errors."""


class UserNotFoundError(IQCBaseException):
    """Raised when a user_id is not found in basic_profiles."""


class FounderRejectedError(IQCBaseException):
    """Raised when a founder account attempts to use the investor portal."""


class ProfileLoadError(IQCBaseException):
    """Raised when the investor profile cannot be loaded from the DB."""


class ProfileSaveError(IQCBaseException):
    """Raised when persisting qualification fields to the DB fails."""


class ScoringError(IQCBaseException):
    """Raised when the qualification score calculation fails."""


class ExtractionError(IQCBaseException):
    """Raised when Gemini-based field extraction from a user message fails."""


class DatabaseUnavailableError(IQCBaseException):
    """Raised when the database engine is None (DB_PASS not set)."""


__all__ = [
    "IQCBaseException",
    "UserNotFoundError",
    "FounderRejectedError",
    "ProfileLoadError",
    "ProfileSaveError",
    "ScoringError",
    "ExtractionError",
    "DatabaseUnavailableError",
]
