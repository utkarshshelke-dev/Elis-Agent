"""
Module: services/pipeline_service.py
Description: Google ADK Investor Qualification Pipeline.
             Implements a SequentialAgent pipeline with 7 sub-agents:
               1. FounderCheckAgent  — DB user-type check; block founders
               2. FetchContextAgent  — Load investor profile from DB
               3. ExtractFromPromptAgent — Gemini + rule-based field extraction
               4. AnalyseAgent       — Score profile (Gemini + fallback)
               5. QuestionAgent      — Select next field to ask
               6. SaveCollectedAgent — Write to DB when threshold met (ACID)
               7. FinalizeAgent      — Emit final response text

             SRP: each sub-agent has exactly one responsibility.
             DIP: PostgresRepo is injected at build time, never imported directly.
Author: IQC Team
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
from typing import Any, AsyncGenerator, Dict, List, Optional

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types as genai_types

from data.repository import PostgresRepo
from data.schemas import ESSENTIAL_FIELDS, QUALIFY_THRESHOLD
from services.logging_service import get_logger
from services.scoring_service import (
    FIELD_DISPLAY,
    _build_scoring_profile,
    score_profile_async,
)
from prompts.system_prompts import QUICK_PROMPTS, EXTRACTION_SYSTEM_PROMPT

logger = get_logger("iqc.pipeline")

# ── Timeouts ──────────────────────────────────────────────────────────────────
DB_OPERATION_TIMEOUT      = 5.0   # seconds
GEMINI_EXTRACTION_TIMEOUT = 10.0  # seconds

# Priority order to ask questions
FIELD_PRIORITY: List[str] = [
    "capacity", "geo", "stage", "sector", "authority",
    "timeline", "value_add", "portfolio", "deal_prefs", "seeking",
]


# ── State key namespace ───────────────────────────────────────────────────────

class S:
    """Namespace for ADK session state keys — avoids magic strings."""
    USER_ID          = "user_id"
    SESSION_ID       = "session_id"
    TRACE_ID         = "trace_id"
    PROMPT           = "prompt"
    ANSWERS          = "answers"
    EVAL_MODE        = "eval_mode"
    FROM_IR          = "from_ir"
    USER_TYPE        = "user_type"
    INVESTOR_PROFILE = "investor_profile"
    ASKED_FIELDS     = "asked_fields"
    SCORES           = "scores"
    SCORE            = "score"
    CONFIDENCE       = "confidence"
    QUALIFIED        = "qualified"
    THRESHOLD_MET    = "threshold_met"
    MISSING_FIELDS   = "missing_fields"
    NEXT_QUESTION    = "next_question"
    RESULT           = "result"
    ERROR            = "error"


# ── Shared helpers ────────────────────────────────────────────────────────────

def _deserialize_state(ctx: InvocationContext) -> None:
    """Parse JSON-encoded state values back to their native types."""
    state = ctx.session.state
    for key, default, parser in [
        (S.ANSWERS,          {}, json.loads),
        (S.ASKED_FIELDS,     [], json.loads),
        (S.INVESTOR_PROFILE, {}, json.loads),
    ]:
        val = state.get(key)
        if isinstance(val, str):
            try:
                state[key] = parser(val)
            except Exception:
                state[key] = default


def _state_event(ctx: InvocationContext, updates: Dict[str, Any]) -> Event:
    return Event(
        invocation_id=ctx.invocation_id,
        author=ctx.agent.name,
        actions=EventActions(state_delta=updates),
    )


def _text_event(ctx: InvocationContext, text: str) -> Event:
    return Event(
        invocation_id=ctx.invocation_id,
        author=ctx.agent.name,
        content=genai_types.Content(
            role="model",
            parts=[genai_types.Part(text=text)],
        ),
    )


def _is_founder(ctx: InvocationContext) -> bool:
    return "founder" in ctx.session.state.get(S.USER_TYPE, "").lower()


def _has_error(ctx: InvocationContext) -> bool:
    return bool(ctx.session.state.get(S.ERROR))


def _is_valid_uuid(val: str) -> bool:
    import uuid as _uuid
    try:
        _uuid.UUID(str(val))
        return True
    except Exception:
        return False


def _safe_dict(val: Any) -> Dict[str, Any]:
    if val is None:       return {}
    if isinstance(val, dict): return dict(val)
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _safe_list(val: Any) -> List[Any]:
    if val is None:       return []
    if isinstance(val, list): return list(val)
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []
    return []


def _log_step(agent_name: str, user_id: str, step: str, **kwargs) -> None:
    extras = " | ".join(f"{k}={v}" for k, v in kwargs.items())
    logger.info("[%s] user=%s step=%s | %s", agent_name, user_id, step, extras)


# ── Agent 1: FounderCheckAgent ────────────────────────────────────────────────

class FounderCheckAgent(BaseAgent):
    """
    SRP: Verify user type from DB. Block founders. Extract user_id from JSON payload.

    DIP: Receives PostgresRepo via constructor — never creates its own DB connection.
    """

    def __init__(self, repo: PostgresRepo, **kwargs) -> None:
        """
        Args:
            repo: Injected PostgresRepo — enables mocking in tests.
        """
        super().__init__(name="founder_check", **kwargs)
        self._repo = repo

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield  # Required for AsyncGenerator type annotation
        _deserialize_state(ctx)

        user_id: str = ctx.session.state.get(S.USER_ID, "")

        # Extract user_id from JSON payload on first turn
        raw_text = ""
        try:
            if ctx.user_content and ctx.user_content.parts:
                raw_text = (ctx.user_content.parts[0].text or "").strip()
        except Exception:
            pass

        if not _is_valid_uuid(user_id) and raw_text.startswith("{"):
            try:
                payload = json.loads(raw_text)
                if isinstance(payload, dict):
                    injected_uid = str(payload.get("user_id", ""))
                    if _is_valid_uuid(injected_uid):
                        user_id = injected_uid
                        answers_raw = payload.get("answers") or {}
                        state_seed: Dict[str, Any] = {
                            S.USER_ID:   user_id,
                            S.PROMPT:    str(payload.get("prompt", "")),
                            S.ANSWERS:   json.dumps(answers_raw) if isinstance(answers_raw, dict) else "{}",
                            S.EVAL_MODE: "true" if payload.get("eval_mode") else "false",
                            S.FROM_IR:   "true" if payload.get("from_ir")   else "false",
                        }
                        if payload.get("session_id"):
                            state_seed[S.SESSION_ID] = str(payload["session_id"])
                        ctx.session.state.update(state_seed)
                        yield _state_event(ctx, state_seed)
                        _log_step("founder_check", user_id, "user_id_from_json")
            except Exception:
                pass

        if not _is_valid_uuid(user_id):
            session_uid = getattr(ctx.session, "user_id", "") or ""
            if _is_valid_uuid(session_uid):
                user_id = session_uid
                ctx.session.state[S.USER_ID] = user_id
                yield _state_event(ctx, {S.USER_ID: user_id})

        _log_step("founder_check", user_id, "start")

        # If request came from IR agent, IR already filtered founders — skip DB
        from_ir = ctx.session.state.get(S.FROM_IR, "false")
        if str(from_ir).lower() == "true":
            _log_step("founder_check", user_id, "skip_db", reason="from_ir")
            ctx.session.state[S.USER_TYPE] = "investor"
            yield _state_event(ctx, {S.USER_TYPE: "investor"})
            return

        if not user_id or not _is_valid_uuid(user_id):
            _log_step("founder_check", user_id, "skip_db", reason="invalid_uuid")
            return

        # Skip DB if user_type already known in session (Turn 2+)
        if ctx.session.state.get(S.USER_TYPE, ""):
            _log_step("founder_check", user_id, "skip_db", reason="type_in_session")
            return

        user_type = ""
        try:
            user_type = await asyncio.wait_for(
                asyncio.to_thread(self._repo.get_user_type, user_id),
                timeout=DB_OPERATION_TIMEOUT,
            ) or ""
        except Exception as exc:
            logger.error("[founder_check] DB error | user=%s | %s", user_id, exc)
            return

        user_type = user_type.lower().strip()
        ctx.session.state[S.USER_TYPE] = user_type
        yield _state_event(ctx, {S.USER_TYPE: user_type})

        if "founder" in user_type:
            err = {S.ERROR: "founder_profile"}
            ctx.session.state.update(err)
            yield _state_event(ctx, err)
            yield _text_event(
                ctx,
                "This qualification service is for **investors only**. "
                "Please use the Founder Portal instead.",
            )
        else:
            _log_step("founder_check", user_id, "ok", user_type=user_type)


# ── Agent 2: FetchContextAgent ────────────────────────────────────────────────

class FetchContextAgent(BaseAgent):
    """
    SRP: Load the investor profile from the DB (Turn 1 only).
    Turn 2+ returns immediately — profile already in session state.

    DIP: Receives PostgresRepo via constructor.
    """

    def __init__(self, repo: PostgresRepo, **kwargs) -> None:
        """
        Args:
            repo: Injected PostgresRepo.
        """
        super().__init__(name="fetch_context", **kwargs)
        self._repo = repo

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield
        if _is_founder(ctx) or _has_error(ctx):
            return

        user_id = ctx.session.state.get(S.USER_ID, "")

        # Turn 2+: profile already in session state — skip DB call
        if _safe_dict(ctx.session.state.get(S.INVESTOR_PROFILE)):
            _log_step("fetch_context", user_id, "skip_db", reason="profile_in_session")
            return

        # If from IR and profile was sent in ANSWERS, use that directly
        if str(ctx.session.state.get(S.FROM_IR, "false")).lower() == "true":
            ir_profile = _safe_dict(ctx.session.state.get(S.ANSWERS))
            _log_step("fetch_context", user_id, "from_ir", fields=len(ir_profile))
            updates = {S.INVESTOR_PROFILE: json.dumps(ir_profile)}
            ctx.session.state.update(updates)
            yield _state_event(ctx, updates)
            return

        _log_step("fetch_context", user_id, "start")
        db_profile: Dict[str, Any] = {}
        if user_id and _is_valid_uuid(user_id):
            try:
                db_profile = await asyncio.wait_for(
                    asyncio.to_thread(self._repo.get_investor_profile, user_id),
                    timeout=DB_OPERATION_TIMEOUT,
                ) or {}
            except Exception as exc:
                logger.warning("[fetch_context] DB error | user=%s | %s", user_id, exc)

        payload_answers = _safe_dict(ctx.session.state.get(S.ANSWERS))
        merged = {**db_profile, **payload_answers}

        updates = {S.INVESTOR_PROFILE: json.dumps(merged)}
        ctx.session.state.update(updates)
        _log_step("fetch_context", user_id, "loaded", fields=len(merged))
        yield _state_event(ctx, updates)


# ── Agent 3: ExtractFromPromptAgent ───────────────────────────────────────────

_VERTEX_INIT_DONE     = False
_GEMINI_EXTRACT_MODEL = None
_GEMINI_INIT_LOCK     = asyncio.Lock()


async def _get_gemini_extract_model():
    """Lazily initialise Vertex AI and return the extraction model (once)."""
    global _VERTEX_INIT_DONE, _GEMINI_EXTRACT_MODEL
    if not _VERTEX_INIT_DONE:
        async with _GEMINI_INIT_LOCK:
            if not _VERTEX_INIT_DONE:
                import vertexai
                from vertexai.generative_models import GenerativeModel
                vertexai.init(
                    project=os.getenv("GOOGLE_CLOUD_PROJECT", "the-grid-os"),
                    location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
                )
                _GEMINI_EXTRACT_MODEL = GenerativeModel(
                    os.getenv("VERTEX_MODEL", "gemini-2.0-flash")
                )
                _VERTEX_INIT_DONE = True
    return _GEMINI_EXTRACT_MODEL


async def _call_gemini_extract(prompt_text: str) -> Dict[str, Any]:
    """
    Call Gemini to extract structured fields from free-form investor text.

    Args:
        prompt_text: Raw user message text.

    Returns:
        Dict of extracted field-name → value pairs (empty on failure).
    """
    try:
        from vertexai.generative_models import GenerationConfig
        model = await _get_gemini_extract_model()
        config = GenerationConfig(
            temperature=0.0,
            response_mime_type="application/json",
            max_output_tokens=512,
        )
        full_prompt = (
            f"{EXTRACTION_SYSTEM_PROMPT}\n\n"
            f'User message:\n"""\n{prompt_text}\n"""\n'
        )
        response = await model.generate_content_async(full_prompt, generation_config=config)
        raw = re.sub(
            r"```(?:json)?\s*([\s\S]*?)\s*```", r"\1",
            (getattr(response, "text", "") or "").strip(),
            flags=re.IGNORECASE,
        ).strip()
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else {}
    except Exception as exc:
        logger.warning("[extract] Gemini failed: %s", exc)
        return {}


def _context_aware_extract(prompt_text: str, last_asked_field: str) -> Dict[str, Any]:
    """
    Rule-based extraction using the last-asked field as context.

    When the agent just asked 'which stages do you focus on?', the investor's
    reply maps directly to stage_focus without keyword detection.

    Args:
        prompt_text:      Raw user reply text.
        last_asked_field: ESSENTIAL_FIELDS key asked on the previous turn.

    Returns:
        Dict of extracted field-name → value pairs.
    """
    if not last_asked_field or not prompt_text.strip():
        return {}

    text   = prompt_text.strip()
    tl     = text.lower()
    result: Dict[str, Any] = {}

    if last_asked_field == "geo":
        result["geo"] = text
    elif last_asked_field == "timeline":
        result["timeline"] = text
    elif last_asked_field == "value_add":
        result["value_add"] = text
    elif last_asked_field == "deal_prefs":
        result["deal_prefs"] = text
    elif last_asked_field == "seeking":
        result["seeking"] = text
    elif last_asked_field == "authority":
        if any(p in tl for p in ("sole", "lead", "i lead", "decision maker")):
            result["authority"] = "lead"
        elif any(p in tl for p in ("co-lead", "co lead")):
            result["authority"] = "co-lead"
        elif any(p in tl for p in ("follow", "co-invest")):
            result["authority"] = "follow"
        else:
            result["authority"] = text
    elif last_asked_field == "capacity":
        def _amt(s: str) -> Optional[int]:
            m = re.search(r"([\d.]+)\s*([kmb]?)", s.replace(",", ""), re.IGNORECASE)
            if not m:
                return None
            v, u = float(m.group(1)), m.group(2).lower()
            if u == "k":  v *= 1_000
            elif u == "m": v *= 1_000_000
            elif u == "b": v *= 1_000_000_000
            return int(v)
        fm = re.search(r"fund[^\d]*([\d.,]+)\s*([kmb]?)", tl, re.IGNORECASE)
        if fm:
            result["fund_size_usd"] = _amt(fm.group(1) + (fm.group(2) or ""))
        cm = re.search(r"check[^\d]*([\d.,]+)\s*([kmb]?)", tl, re.IGNORECASE)
        if cm:
            result["average_check_size_usd"] = _amt(cm.group(1) + (cm.group(2) or ""))

    return {k: v for k, v in result.items() if v not in (None, "", [], {})}


class ExtractFromPromptAgent(BaseAgent):
    """
    SRP: Extract investor profile fields from the user's message.
    Uses Gemini for semantic extraction + rule-based context-aware fallback.
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(name="extract_from_prompt", **kwargs)

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield
        if _is_founder(ctx) or _has_error(ctx):
            return

        user_id = ctx.session.state.get(S.USER_ID, "")
        logger.info("[extract] START | user=%s", user_id)

        # Extract raw text from user content
        prompt_text = ""
        try:
            if ctx.user_content and ctx.user_content.parts:
                raw = (ctx.user_content.parts[0].text or "").strip()
                if raw and not raw.startswith("{"):
                    prompt_text = raw           # Turn 2+: plain text
                elif raw.startswith("{"):
                    try:
                        prompt_text = str(json.loads(raw).get("prompt", ""))  # Turn 1 JSON
                    except Exception:
                        pass
        except Exception as exc:
            logger.exception("[extract] content parse error: %s", exc)

        prompt_text = (prompt_text or "").strip()
        if len(prompt_text) < 3:
            logger.warning("[extract] SKIP | text too short | user=%s", user_id)
            return

        asked_fields     = _safe_list(ctx.session.state.get(S.ASKED_FIELDS))
        last_asked_field = asked_fields[-1] if asked_fields else ""
        logger.info("[extract] last_asked=%s | user=%s", last_asked_field, user_id)

        # Context-aware rule extraction (fast, no API call)
        context_extracted = _context_aware_extract(prompt_text, last_asked_field)

        # Gemini extraction (semantic — may fail gracefully)
        gemini_extracted: Dict[str, Any] = {}
        try:
            gemini_extracted = await asyncio.wait_for(
                _call_gemini_extract(prompt_text),
                timeout=GEMINI_EXTRACTION_TIMEOUT,
            )
        except Exception as exc:
            logger.warning("[extract] Gemini timeout/error: %s", exc)

        # Merge — context_aware overrides Gemini for the last asked field
        extracted = {**gemini_extracted, **context_extracted}
        extracted = {k: v for k, v in extracted.items() if v not in (None, "", [], {})}

        if not extracted:
            logger.warning("[extract] NO fields extracted | user=%s", user_id)
            return

        logger.info("[extract] extracted=%s | user=%s", list(extracted.keys()), user_id)

        current_profile = _safe_dict(ctx.session.state.get(S.INVESTOR_PROFILE))
        current_profile.update(extracted)

        updates = {S.INVESTOR_PROFILE: json.dumps(current_profile)}
        ctx.session.state.update(updates)
        yield _state_event(ctx, updates)


# ── Agent 4: AnalyseAgent ─────────────────────────────────────────────────────

class AnalyseAgent(BaseAgent):
    """SRP: Score the current investor profile and update session state."""

    def __init__(self, **kwargs) -> None:
        super().__init__(name="analyse", **kwargs)

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield
        if _is_founder(ctx) or _has_error(ctx):
            return

        user_id = ctx.session.state.get(S.USER_ID, "")
        profile = _safe_dict(ctx.session.state.get(S.INVESTOR_PROFILE))
        logger.info("[analyse] START | user=%s | fields=%s", user_id, list(profile.keys()))

        scoring_profile = _build_scoring_profile(profile)

        try:
            scores, confidence, _, missing = await score_profile_async(scoring_profile)
        except Exception as exc:
            logger.error("[analyse] scoring failed | user=%s | %s", user_id, exc)
            scores     = {f: 0.0 for f in ESSENTIAL_FIELDS}
            confidence = 0.0
            missing    = list(ESSENTIAL_FIELDS)

        threshold_met = confidence >= QUALIFY_THRESHOLD
        score_pct     = f"{int(confidence * 100)}%"

        updates = {
            S.SCORES:        json.dumps(scores),
            S.SCORE:         score_pct,
            S.CONFIDENCE:    str(round(confidence, 3)),
            S.QUALIFIED:     "true" if threshold_met else "false",
            S.THRESHOLD_MET: "true" if threshold_met else "false",
            S.MISSING_FIELDS: json.dumps(missing),
        }
        ctx.session.state.update(updates)
        logger.info(
            "[analyse] END | user=%s | score=%s | qualified=%s | missing=%s",
            user_id, score_pct, threshold_met, missing,
        )
        yield _state_event(ctx, updates)


# ── Agent 5: QuestionAgent ────────────────────────────────────────────────────

class QuestionAgent(BaseAgent):
    """SRP: Select the next unanswered question to ask the investor."""

    def __init__(self, **kwargs) -> None:
        super().__init__(name="question", **kwargs)

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield
        if _is_founder(ctx) or _has_error(ctx):
            return

        user_id   = ctx.session.state.get(S.USER_ID, "")
        threshold = ctx.session.state.get(S.THRESHOLD_MET, "false")

        if str(threshold).lower() == "true":
            logger.info("[question] threshold met — no question | user=%s", user_id)
            ctx.session.state[S.NEXT_QUESTION] = ""
            yield _state_event(ctx, {S.NEXT_QUESTION: ""})
            return

        missing    = _safe_list(ctx.session.state.get(S.MISSING_FIELDS))
        asked      = _safe_list(ctx.session.state.get(S.ASKED_FIELDS))
        confidence = float(ctx.session.state.get(S.CONFIDENCE, 0.0))
        askable    = [f for f in missing if f not in asked]

        # Pick next field in priority order
        next_field = next(
            (f for f in FIELD_PRIORITY if f in askable), askable[0] if askable else None
        )

        if next_field is None:
            if confidence >= 0.80:
                logger.info("[question] force qualify at %.3f | user=%s", confidence, user_id)
                updates = {S.NEXT_QUESTION: "", S.THRESHOLD_MET: "true", S.QUALIFIED: "true"}
                ctx.session.state.update(updates)
                yield _state_event(ctx, updates)
            return

        question_text = QUICK_PROMPTS.get(
            next_field,
            f"Could you share more about your **{FIELD_DISPLAY.get(next_field, next_field)}**?",
        )

        updated_asked = list(asked)
        if next_field not in updated_asked:
            updated_asked.append(next_field)

        logger.info("[question] asking=%s | user=%s", next_field, user_id)
        updates = {
            S.NEXT_QUESTION: question_text,
            S.ASKED_FIELDS:  json.dumps(updated_asked),
        }
        ctx.session.state.update(updates)
        yield _state_event(ctx, updates)


# ── Agent 6: SaveCollectedAgent ───────────────────────────────────────────────

class SaveCollectedAgent(BaseAgent):
    """
    SRP: Write investor profile to DB when qualification threshold is met.
    Only executes on qualified=True and eval_mode=False.
    Uses PostgresRepo.patch_investor_profile for ACID-compliant writes.

    DIP: Receives PostgresRepo via constructor.
    """

    def __init__(self, repo: PostgresRepo, **kwargs) -> None:
        """
        Args:
            repo: Injected PostgresRepo.
        """
        super().__init__(name="save_collected", **kwargs)
        self._repo = repo

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield
        if _is_founder(ctx) or _has_error(ctx):
            return

        user_id       = ctx.session.state.get(S.USER_ID, "")
        threshold_met = str(ctx.session.state.get(S.THRESHOLD_MET, "false")).lower() == "true"
        eval_mode     = str(ctx.session.state.get(S.EVAL_MODE,     "false")).lower() == "true"
        profile       = _safe_dict(ctx.session.state.get(S.INVESTOR_PROFILE))

        if not threshold_met or eval_mode or not profile or not _is_valid_uuid(user_id):
            logger.info(
                "[save] SKIP | user=%s | threshold=%s | eval=%s | profile_empty=%s",
                user_id, threshold_met, eval_mode, not profile,
            )
            return

        logger.info("[save] START | user=%s | fields=%d", user_id, len(profile))
        try:
            await asyncio.wait_for(
                asyncio.to_thread(
                    self._repo.patch_investor_profile,
                    user_id=user_id,
                    patch=profile,
                    qualified=True,
                ),
                timeout=DB_OPERATION_TIMEOUT,
            )
            logger.info("[save] SUCCESS | user=%s", user_id)
        except Exception as exc:
            logger.error("[save] FAILED | user=%s | %s", user_id, exc)


# ── Agent 7: FinalizeAgent ────────────────────────────────────────────────────

class FinalizeAgent(BaseAgent):
    """SRP: Emit the final human-readable response text event."""

    def __init__(self, **kwargs) -> None:
        super().__init__(name="finalize", **kwargs)

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield

        user_id = ctx.session.state.get(S.USER_ID, "")

        if _has_error(ctx):
            yield _text_event(ctx, "This qualification service is for investors only.")
            return

        threshold_met = str(ctx.session.state.get(S.THRESHOLD_MET, "false")).lower() == "true"
        score_pct     = ctx.session.state.get(S.SCORE, "0%")
        next_q        = ctx.session.state.get(S.NEXT_QUESTION, "")

        logger.info(
            "[finalize] user=%s | qualified=%s | score=%s", user_id, threshold_met, score_pct
        )

        if threshold_met:
            msg = (
                f"✅ **Investor qualification complete!**\n\n"
                f"Your profile has reached the qualification threshold with a score of "
                f"**{score_pct}**.\n\nYour profile data has been saved."
            )
        elif next_q:
            msg = (
                f"📊 Your current profile completeness score is **{score_pct}** "
                f"(target: {int(QUALIFY_THRESHOLD * 100)}%).\n\n{next_q}"
            )
        else:
            msg = (
                f"📊 Your current profile completeness score is **{score_pct}**.\n\n"
                "Could you tell me more about your investment focus?"
            )

        yield _text_event(ctx, msg)


# ── Pipeline wrapper ──────────────────────────────────────────────────────────

class InvestorQualificationAgent(BaseAgent):
    """
    Orchestrates the 7 sub-agents in sequence.
    SRP: This class only manages execution order — it contains no business logic.
    """

    _CRITICAL_KEYS = (
        S.USER_ID, S.USER_TYPE, S.PROMPT, S.EVAL_MODE,
        S.INVESTOR_PROFILE, S.ASKED_FIELDS,
        S.CONFIDENCE, S.SCORE, S.THRESHOLD_MET, S.MISSING_FIELDS,
        S.NEXT_QUESTION,
    )

    def __init__(self, repo: PostgresRepo, **kwargs) -> None:
        """
        Args:
            repo: Injected PostgresRepo — passed to all DB-dependent sub-agents.
        """
        super().__init__(name="investor_qualification_agent", **kwargs)
        self._sub_agents = [
            FounderCheckAgent(repo=repo),
            FetchContextAgent(repo=repo),
            ExtractFromPromptAgent(),
            AnalyseAgent(),
            QuestionAgent(),
            SaveCollectedAgent(repo=repo),
            FinalizeAgent(),
        ]

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        if False:
            yield

        text_event: Optional[Event] = None

        for agent in self._sub_agents:
            logger.info("[pipeline] >> %s", agent.name)
            try:
                async for event in agent._run_async_impl(ctx):
                    if event.content is not None:
                        text_event = event
            except Exception as exc:
                logger.exception("[pipeline] %s CRASH: %s", agent.name, exc)
                text_event = _text_event(ctx, "❌ Internal error occurred.")
                break

        # Propagate full session state delta on final event
        delta: Dict[str, Any] = {}
        state = ctx.session.state
        for k in self._CRITICAL_KEYS:
            v = state.get(k)
            if v not in (None, "", {}, []):
                delta[k] = str(v)
        for k, v in state.items():
            if k not in delta and v not in (None, "", {}, []):
                delta[k] = str(v)

        if text_event is None:
            logger.warning("[pipeline] no text event — using fallback")
            text_event = _text_event(ctx, "Please continue.")

        if delta:
            text_event.actions = EventActions(state_delta=delta)

        yield text_event


# ── Factory ───────────────────────────────────────────────────────────────────

def build_investor_qualification_agent(repo: PostgresRepo) -> InvestorQualificationAgent:
    """
    Build and return the root pipeline agent.

    Args:
        repo: Injected PostgresRepo (DIP — never created inside this function).

    Returns:
        InvestorQualificationAgent ready for ADK registration.
    """
    logger.info(
        "build_investor_qualification_agent | threshold=%.0f%%",
        QUALIFY_THRESHOLD * 100,
    )
    return InvestorQualificationAgent(repo=repo)


__all__ = [
    "S",
    "build_investor_qualification_agent",
    "InvestorQualificationAgent",
]
