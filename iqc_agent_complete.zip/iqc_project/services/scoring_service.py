"""
Module: services/scoring_service.py
Description: Investor profile scoring logic.
             Provides a Gemini-based scorer (when Vertex AI is available)
             and a deterministic fallback scorer. The best of both scores
             is used per field — the pipeline always completes without API access.
Author: IQC Team
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from data.schemas import ESSENTIAL_FIELDS, QUALIFY_THRESHOLD
from services.exceptions import ScoringError

logger = logging.getLogger(__name__)

try:
    import vertexai
    from vertexai.generative_models import GenerationConfig, GenerativeModel
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

# ── Module-level model cache (initialised once) ───────────────────────────────
_VERTEX_INIT_DONE  = False
_model: Optional["GenerativeModel"]       = None
_json_config: Optional["GenerationConfig"] = None
_GEMINI_INIT_LOCK  = asyncio.Lock()
_JSON_FENCE_RE     = re.compile(r"```(?:json)?\s*([\s\S]*?)\s*```", re.IGNORECASE)

FIELD_DISPLAY: Dict[str, str] = {
    "capacity":   "investment capacity (fund size + check size)",
    "stage":      "target investment stages",
    "sector":     "focus sectors/industries",
    "geo":        "geographic focus",
    "authority":  "decision authority and investor type",
    "timeline":   "fund life and holding period",
    "value_add":  "value-add beyond capital",
    "portfolio":  "portfolio depth (size/exits/unicorns)",
    "deal_prefs": "deal preferences (ownership/board/pro-rata)",
    "seeking":    "what you are actively seeking",
}


# ── Private helpers ───────────────────────────────────────────────────────────

def _strip_fences(s: str) -> str:
    if not s:
        return ""
    m = _JSON_FENCE_RE.search(s)
    return (m.group(1) if m else s).strip()


def _safe_json_loads(raw: str) -> Dict[str, Any]:
    """Robustly parse a JSON object from model output, repairing common issues."""
    raw = raw or ""
    cleaned = _strip_fences(raw)
    for candidate in (cleaned, raw):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
    # Extract first {...} block and try minimal repair
    start = cleaned.find("{")
    if start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(cleaned)):
            ch = cleaned[i]
            if in_str:
                esc = not esc and ch == "\\"
                if not esc and ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    block = cleaned[start:i + 1]
                    block = re.sub(r",\s*([}\]])", r"\1", block)
                    try:
                        obj = json.loads(block)
                        if isinstance(obj, dict):
                            return obj
                    except Exception:
                        pass
    raise json.JSONDecodeError("No valid JSON object found", cleaned, 0)


async def _ensure_model_initialised() -> None:
    """Initialise Vertex AI and model once, thread-safe."""
    global _VERTEX_INIT_DONE, _model, _json_config
    if _VERTEX_INIT_DONE or not GEMINI_AVAILABLE:
        return
    async with _GEMINI_INIT_LOCK:
        if _VERTEX_INIT_DONE:
            return
        vertexai.init(
            project=os.getenv("GOOGLE_CLOUD_PROJECT", "the-grid-os"),
            location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        )
        _model = GenerativeModel(os.getenv("VERTEX_MODEL", "gemini-2.0-flash"))
        _json_config = GenerationConfig(
            temperature=0.0,
            response_mime_type="application/json",
            max_output_tokens=800,
        )
        _VERTEX_INIT_DONE = True
        logger.info("scoring_service | Vertex AI initialised")


def _has_value(v: Any) -> bool:
    """Return True if a field value is meaningfully populated."""
    if v is None:
        return False
    if isinstance(v, bool):
        return True
    if isinstance(v, (int, float)):
        return v > 0
    if isinstance(v, str):
        return len(v.strip()) > 3
    if isinstance(v, list):
        return len(v) > 0
    if isinstance(v, dict):
        return any(_has_value(x) for x in v.values())
    return False


# ── Deterministic fallback scorer ────────────────────────────────────────────

def _smart_fallback(scoring_profile: Dict[str, Any]) -> Dict[str, float]:
    """
    Rule-based scoring — no external API calls.

    Args:
        scoring_profile: Structured profile dict keyed by ESSENTIAL_FIELDS.

    Returns:
        Dict mapping each essential field to a score in [0.0, 1.0].
    """
    scores: Dict[str, float] = {}

    cap = scoring_profile.get("capacity") or {}
    fs  = cap.get("fund_size_usd")          if isinstance(cap, dict) else None
    cs  = cap.get("average_check_size_usd") if isinstance(cap, dict) else None
    scores["capacity"] = 0.95 if (fs and cs) else (0.75 if (fs or cs) else 0.0)

    stage = scoring_profile.get("stage")
    scores["stage"] = (
        0.90 if (isinstance(stage, list) and len(stage) >= 2) else
        0.75 if (isinstance(stage, list) and len(stage) == 1) else
        0.65 if (isinstance(stage, str)  and _has_value(stage)) else 0.0
    )

    sector = scoring_profile.get("sector")
    scores["sector"] = (
        0.95 if (isinstance(sector, list) and len(sector) >= 2) else
        0.75 if (isinstance(sector, list) and len(sector) == 1) else
        0.65 if (isinstance(sector, str)  and _has_value(sector)) else 0.0
    )

    geo = scoring_profile.get("geo")
    scores["geo"] = (
        0.85 if (isinstance(geo, list) and len(geo) >= 1) else
        0.75 if (isinstance(geo, str)  and _has_value(geo)) else 0.0
    )

    auth  = scoring_profile.get("authority") or {}
    itype = auth.get("investor_type") if isinstance(auth, dict) else None
    arole = auth.get("authority")     if isinstance(auth, dict) else None
    scores["authority"] = (
        0.90 if (_has_value(itype) and _has_value(arole)) else
        0.70 if (_has_value(itype) or  _has_value(arole)) else 0.0
    )

    scores["timeline"]   = 0.85 if _has_value(scoring_profile.get("timeline")) else 0.0

    va = scoring_profile.get("value_add")
    scores["value_add"]  = (
        0.85 if (isinstance(va, str)  and len(va.strip()) > 20) else
        0.65 if (isinstance(va, str)  and _has_value(va)) else
        0.75 if (isinstance(va, list) and len(va) > 0) else 0.0
    )

    port = scoring_profile.get("portfolio") or {}
    ps   = port.get("portfolio_size")             if isinstance(port, dict) else None
    inv  = port.get("investments_last_12_months") if isinstance(port, dict) else None
    uni  = port.get("has_unicorns_or_ipos")       if isinstance(port, dict) else None
    count = sum(1 for x in [ps, inv] if _has_value(x))
    scores["portfolio"] = (
        0.90 if (count >= 2 or (isinstance(uni, bool) and uni)) else
        0.70 if count == 1 else 0.0
    )

    dp = scoring_profile.get("deal_prefs")
    scores["deal_prefs"] = (
        0.85 if (isinstance(dp, str) and len(dp.strip()) > 10) else
        0.55 if (isinstance(dp, str) and _has_value(dp)) else 0.0
    )

    sk = scoring_profile.get("seeking")
    scores["seeking"] = (
        0.80 if (isinstance(sk, str)  and len(sk.strip()) > 15) else
        0.60 if (isinstance(sk, str)  and _has_value(sk)) else
        0.75 if (isinstance(sk, list) and len(sk) > 0) else 0.0
    )

    return scores


# ── Gemini async scorer ───────────────────────────────────────────────────────

async def _score_with_gemini_async(
    scoring_profile: Dict[str, Any],
) -> Dict[str, float]:
    """
    Call Gemini to score all 10 dimensions in a single async request.

    Args:
        scoring_profile: Structured profile dict.

    Returns:
        Per-field score dict (values clamped to [0.0, 1.0]).

    Raises:
        ScoringError: If the Gemini call or response parsing fails.
    """
    await _ensure_model_initialised()
    prompt = (
        "Score each investor dimension from 0.0 to 1.0.\n\n"
        f"Profile:\n{json.dumps(scoring_profile, indent=2, ensure_ascii=False)}\n\n"
        "Return ONLY JSON:\n"
        '{"capacity":0.0,"stage":0.0,"sector":0.0,"geo":0.0,"authority":0.0,'
        '"timeline":0.0,"value_add":0.0,"portfolio":0.0,"deal_prefs":0.0,"seeking":0.0}'
    )
    try:
        response = await _model.generate_content_async(prompt, generation_config=_json_config)
        raw = getattr(response, "text", "") or ""
        scores_obj = _safe_json_loads(raw)
        return {
            f: max(0.0, min(1.0, float(scores_obj.get(f, 0.0) or 0.0)))
            for f in ESSENTIAL_FIELDS
        }
    except Exception as exc:
        raise ScoringError(f"Gemini scoring failed: {exc}") from exc


# ── Public API ────────────────────────────────────────────────────────────────

def _build_scoring_profile(profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map a flat investor_profile dict into the nested structure expected by scorers.

    Args:
        profile: Flat profile dict from the repository.

    Returns:
        Nested scoring profile dict keyed by ESSENTIAL_FIELDS.
    """
    return {
        "capacity":  {
            "fund_size_usd":          profile.get("fund_size_usd"),
            "average_check_size_usd": profile.get("average_check_size_usd"),
        },
        "stage":      profile.get("stage_focus"),
        "sector":     profile.get("sector_focus"),
        "geo":        profile.get("geo"),
        "authority":  {
            "investor_type": profile.get("investor_type"),
            "authority":     profile.get("authority"),
        },
        "timeline":   profile.get("timeline"),
        "value_add":  profile.get("value_add"),
        "portfolio":  {
            "portfolio_size":             profile.get("portfolio_size"),
            "has_unicorns_or_ipos":       profile.get("has_unicorns_or_ipos"),
            "investments_last_12_months": profile.get("investments_last_12_months"),
        },
        "deal_prefs": profile.get("deal_prefs"),
        "seeking":    profile.get("seeking"),
    }


async def score_profile_async(
    scoring_profile: Dict[str, Any],
) -> Tuple[Dict[str, float], float, bool, List[str]]:
    """
    Score an investor profile using Gemini + deterministic fallback.

    Uses the best (max) score per field from both methods.
    Always returns a result — Gemini failure falls back to deterministic scorer.

    Args:
        scoring_profile: Nested profile dict from _build_scoring_profile().

    Returns:
        Tuple of (scores_dict, confidence, qualified, missing_fields).

    Raises:
        ScoringError: Only if both Gemini and fallback fail (should not occur).
    """
    logger.info("score_profile_async | START | fields=%s", list(scoring_profile.keys()))
    start = time.perf_counter()

    scores: Dict[str, float] = {}

    if GEMINI_AVAILABLE:
        try:
            scores = await _score_with_gemini_async(scoring_profile)
            logger.info("score_profile_async | Gemini scoring OK")
        except Exception as exc:
            logger.warning("score_profile_async | Gemini failed, using fallback | %s", exc)

    # Deterministic fallback — take max per field
    fallback = _smart_fallback(scoring_profile)
    for f in ESSENTIAL_FIELDS:
        scores[f] = max(scores.get(f, 0.0), fallback.get(f, 0.0))

    missing    = [f for f in ESSENTIAL_FIELDS if scores.get(f, 0.0) < 0.75]
    confidence = sum(scores.values()) / len(ESSENTIAL_FIELDS)
    qualified  = confidence >= QUALIFY_THRESHOLD

    elapsed_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "score_profile_async | END | confidence=%.3f | qualified=%s | missing=%s | ms=%.1f",
        confidence, qualified, missing, elapsed_ms,
    )

    return scores, float(confidence), bool(qualified), missing


def score_profile(
    scoring_profile: Dict[str, Any],
) -> Tuple[Dict[str, float], float, bool, List[str]]:
    """
    Synchronous wrapper around score_profile_async.

    Args:
        scoring_profile: Nested profile dict from _build_scoring_profile().

    Returns:
        Tuple of (scores_dict, confidence, qualified, missing_fields).
    """
    return asyncio.get_event_loop().run_until_complete(
        score_profile_async(scoring_profile)
    )


__all__ = [
    "FIELD_DISPLAY",
    "_build_scoring_profile",
    "score_profile",
    "score_profile_async",
]
