"""
Module: services/a2a_handshake.py
Description: A2A Handshake Protocol handler for the IQC Agent Engine.
             Handles initial connection validation and capabilities exchange
             between IQC and the IR Domain Agent.
Author: IQC Team
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict

from services.logging_service import get_logger

logger = get_logger("iqc.a2a_handshake")

MIN_IR_VERSION = (1, 0)


class A2AHandshakeHandler:
    """
    Handles the IQC side of the A2A handshake protocol.

    On startup, the IR Domain Agent sends a handshake request to confirm
    version compatibility and capabilities before routing investor messages.

    Attributes:
        CAPABILITIES: Static dict describing this agent's capabilities.
    """

    CAPABILITIES: Dict[str, Any] = {
        "agent_name":          "iqc_agent",
        "api_version":         "1.0",
        "supported_operations": [
            "qualify_investor",
            "extract_profile",
            "ask_question",
            "score_profile",
            "health_check",
        ],
        "required_fields":     ["user_id", "session_id", "trace_id", "message"],
        "profile_schema_version": "2.0",
        "min_ir_api_version":  "1.0",
    }

    def __init__(self) -> None:
        self._sessions: Dict[str, Any] = {}
        logger.info("A2AHandshakeHandler | initialised")

    async def handle_handshake_request(
        self,
        request:    Dict[str, Any],
        agent_name: str = "iqc_agent",
    ) -> Dict[str, Any]:
        """
        Handle a handshake request from the IR Domain Agent.

        Args:
            request: Dict with handshake_id, ir_agent_id, ir_version,
                     capabilities (optional), timestamp (optional).
            agent_name: Name to use in the iqc_agent_id field.

        Returns:
            Dict with status, handshake_id, iqc_agent_id, iqc_capabilities,
            timestamp, and correlation_id (or error on failure).
        """
        handshake_id = request.get("handshake_id", str(uuid.uuid4()))
        ir_agent_id  = request.get("ir_agent_id", "unknown")
        ir_version   = request.get("ir_version",  "unknown")

        logger.info(
            "handle_handshake_request | START | ir=%s | version=%s | id=%s",
            ir_agent_id[:16], ir_version, handshake_id[:16],
        )

        try:
            # Validate required fields
            required = ["handshake_id", "ir_agent_id", "ir_version"]
            missing  = [k for k in required if k not in request]
            if missing:
                msg = f"Missing required fields: {missing}"
                logger.error("handle_handshake_request | VALIDATION_FAILED | %s", msg)
                return self._error_response(handshake_id, msg)

            # Validate version compatibility
            if not self._is_version_compatible(ir_version):
                msg = (
                    f"Incompatible IR version: {ir_version}. "
                    f"Minimum required: {self.CAPABILITIES['min_ir_api_version']}"
                )
                logger.error("handle_handshake_request | VERSION_MISMATCH | %s", msg)
                return self._error_response(handshake_id, msg)

            # Store handshake session
            correlation_id = str(uuid.uuid4())
            self._sessions[handshake_id] = {
                "ir_agent_id":  ir_agent_id,
                "ir_version":   ir_version,
                "timestamp":    datetime.utcnow().isoformat(),
                "correlation_id": correlation_id,
            }

            logger.info(
                "handle_handshake_request | SUCCESS | id=%s | corr=%s",
                handshake_id[:16], correlation_id[:8],
            )
            return {
                "status":          "success",
                "handshake_id":    handshake_id,
                "iqc_agent_id":    f"{agent_name}_{str(uuid.uuid4())[:8]}",
                "iqc_capabilities": self.CAPABILITIES,
                "timestamp":       datetime.utcnow().isoformat(),
                "correlation_id":  correlation_id,
            }

        except Exception as exc:
            logger.exception("handle_handshake_request | UNEXPECTED_ERROR | %s", exc)
            return self._error_response(handshake_id, str(exc))

    def _is_version_compatible(self, ir_version: str) -> bool:
        """
        Check whether the IR agent's version meets the minimum requirement.

        Args:
            ir_version: Version string from the IR agent (e.g. '1.0').

        Returns:
            True if compatible, False otherwise.
        """
        try:
            parts  = tuple(int(x) for x in ir_version.split(".")[:2])
            return parts >= MIN_IR_VERSION
        except Exception:
            return False

    def _error_response(self, handshake_id: str, error: str) -> Dict[str, Any]:
        return {
            "status":       "error",
            "handshake_id": handshake_id,
            "error":        error,
            "timestamp":    datetime.utcnow().isoformat(),
        }

    async def validate_session(self, handshake_id: str) -> bool:
        """
        Confirm that a handshake session was successfully established.

        Args:
            handshake_id: ID returned during the initial handshake.

        Returns:
            True if the handshake is on record, False otherwise.
        """
        return handshake_id in self._sessions


__all__ = ["A2AHandshakeHandler"]
