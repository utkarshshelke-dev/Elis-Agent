"""
Module: services/llm_service.py
Description: LLM client implementations for investor qualification question
             generation and profile analysis.
             Provides a StaticLLMClient (no external API) and an LLMClient
             Protocol for future integrations.
             Follows the ISP principle — clients implement only what they use.
Author: IQC Team
"""
from __future__ import annotations

from typing import Any, Dict, List, Protocol

from data.schemas import MissingFieldsExplanation, PromptDBCheck
from prompts.system_prompts import (
    FIELD_EXAMPLES,
    build_explanation_text,
    build_question_text,
)


# ── Protocol (ISP — Interface Segregation) ────────────────────────────────────

class LLMClient(Protocol):
    """
    Protocol defining the interface for all LLM client implementations.

    Any class that implements these three methods can be used interchangeably
    in the IQC pipeline (DIP — Dependency Inversion Principle).
    """

    def check_prompt_vs_db(
        self, *, prompt: str, db_profile: Dict[str, Any]
    ) -> PromptDBCheck:
        """Cross-check a user prompt against the stored investor DB profile."""
        ...

    def generate_questions(
        self, *, missing_fields: List[str], known_profile: Dict[str, Any]
    ) -> List[str]:
        """Generate one or more questions for the given missing fields."""
        ...

    def explain_missing_fields(
        self,
        *,
        missing_fields:     List[str],
        current_confidence: float,
        threshold:          float,
        field_scores:       Dict[str, float],
    ) -> MissingFieldsExplanation:
        """Explain why the profile does not yet meet the qualification threshold."""
        ...


# ── Static (no-API) implementation ───────────────────────────────────────────

class StaticLLMClient:
    """
    Deterministic LLM client that requires no external API calls.

    Uses rule-based templates from the prompts layer to generate questions
    and explanations. Suitable as a fallback when Gemini/Vertex is unavailable,
    or for unit testing without network access.

    Attributes:
        _check:     Pre-configured result for check_prompt_vs_db.
        _questions: Pre-configured questions list for generate_questions.
    """

    def __init__(
        self,
        check:     PromptDBCheck | None = None,
        questions: List[str] | None     = None,
    ) -> None:
        """
        Initialise the static client.

        Args:
            check:     Response to return from check_prompt_vs_db.
                       Defaults to an empty PromptDBCheck.
            questions: Pre-configured questions for the low-missing-field case.
                       Defaults to an empty list.
        """
        self._check     = check or PromptDBCheck()
        self._questions = questions or []

    def check_prompt_vs_db(
        self, *, prompt: str, db_profile: Dict[str, Any]
    ) -> PromptDBCheck:
        """
        Return the pre-configured PromptDBCheck result.

        Args:
            prompt:     User prompt text (unused in static implementation).
            db_profile: Stored profile dict (unused in static implementation).

        Returns:
            PromptDBCheck: The pre-configured check result.
        """
        _ = prompt, db_profile
        return self._check

    def generate_questions(
        self, *, missing_fields: List[str], known_profile: Dict[str, Any]
    ) -> List[str]:
        """
        Generate a question string for the provided missing fields.

        Delegates to the prompts layer's build_question_text.

        Args:
            missing_fields: Field names that need to be collected.
            known_profile:  Current profile dict (unused in static implementation).

        Returns:
            List containing one question string, or empty list if none needed.
        """
        _ = known_profile
        text = build_question_text(missing_fields)
        return [text] if text else []

    def explain_missing_fields(
        self,
        *,
        missing_fields:     List[str],
        current_confidence: float,
        threshold:          float,
        field_scores:       Dict[str, float],
    ) -> MissingFieldsExplanation:
        """
        Generate a concise explanation of why the profile does not qualify.

        Args:
            missing_fields:     Fields with scores below the threshold.
            current_confidence: Current aggregate confidence (0.0–1.0).
            threshold:          Required confidence to qualify.
            field_scores:       Per-field score dict (unused in static).

        Returns:
            MissingFieldsExplanation with explanation and example.
        """
        _ = field_scores
        explanation = build_explanation_text(
            missing_fields, current_confidence, threshold
        )
        example_field = missing_fields[0] if missing_fields else "capacity"
        return MissingFieldsExplanation(
            explanation=explanation,
            example_field=example_field,
            example_value=FIELD_EXAMPLES.get(example_field, "Provide detailed information"),
        )


__all__ = ["LLMClient", "StaticLLMClient"]
