"""
Module: services/logging_service.py
Description: Central logging configuration for the IQC agent.
             Configures a rotating file handler and a console handler on
             the root logger. Safe to call multiple times (idempotent).
Author: IQC Team
"""
from __future__ import annotations

import logging
import logging.handlers
import sys
from pathlib import Path

_LOG_FORMAT  = (
    "%(asctime)s | %(levelname)-8s | %(name)-30s | "
    "%(funcName)-28s | %(message)s"
)
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured = False


def setup_logging(level: str = "INFO", log_dir: str = "logs") -> None:
    """
    Configure the root logger once with rotating file and console handlers.

    Safe to call multiple times — subsequent calls after the first are no-ops.

    Args:
        level:   Logging level string (e.g. 'INFO', 'DEBUG'). Case-insensitive.
        log_dir: Directory for the rotating log file.
    """
    global _configured
    if _configured:
        return
    _configured = True

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    log_file = log_path / "iqc.log"

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    root          = logging.getLogger()
    root.setLevel(numeric_level)

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    # Rotating file handler — rolls at midnight, 30-day retention
    file_handler = logging.handlers.TimedRotatingFileHandler(
        filename=str(log_file),
        when="midnight",
        backupCount=30,
        encoding="utf-8",
        utc=False,
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(numeric_level)
    root.addHandler(file_handler)

    # Console handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(numeric_level)
    root.addHandler(console_handler)

    # Suppress noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

    root.info(
        "Logging initialised | level=%s | file=%s",
        level.upper(), log_file.resolve(),
    )


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger. Call setup_logging() once at application startup.

    Args:
        name: Logger name — typically __name__ of the calling module.

    Returns:
        Configured logging.Logger instance.
    """
    return logging.getLogger(name)


__all__ = ["setup_logging", "get_logger"]
