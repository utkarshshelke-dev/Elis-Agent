-- =============================================================================
-- IQC Agent Database Schema
-- PostgreSQL DDL for all tables required by the IQC + IR Domain agents
-- Run once against your target database to set up the schema.
-- =============================================================================

-- ── basic_profiles ─────────────────────────────────────────────────────────
-- Core user table — shared with other services.
-- primary_category: 'investor' | 'founder'

CREATE TABLE IF NOT EXISTS public.basic_profiles (
    id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    primary_category VARCHAR(50) NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_basic_profiles_category
    ON public.basic_profiles (primary_category);


-- ── impact_profiles_v2 ──────────────────────────────────────────────────────
-- Primary investor profile store. investor_profile is a free-form JSONB column
-- that holds all qualified fields merged by the IQC pipeline.

CREATE TABLE IF NOT EXISTS public.impact_profiles_v2 (
    id               UUID        PRIMARY KEY REFERENCES public.basic_profiles(id),
    investor_profile JSONB       NOT NULL DEFAULT '{}'::jsonb,
    embedding_model  JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── intelligence_data ───────────────────────────────────────────────────────
-- Secondary investor data table — used as fallback/enrichment source.
-- Merged into investor_profile on read (lower priority than impact_profiles_v2).

CREATE TABLE IF NOT EXISTS public.intelligence_data (
    profile_id      UUID        PRIMARY KEY REFERENCES public.basic_profiles(id),
    investor_data   JSONB       NOT NULL DEFAULT '{}'::jsonb,
    embedding_model JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- ── ir_active_sessions ──────────────────────────────────────────────────────
-- Live IR Domain Agent sessions. One row per active user conversation.
-- Deleted (or moved to history) when the session is closed or expires.

CREATE TABLE IF NOT EXISTS public.ir_active_sessions (
    user_id         UUID        NOT NULL,
    session_id      UUID        NOT NULL DEFAULT gen_random_uuid(),
    iqc_session_id  TEXT        NOT NULL DEFAULT '',
    status          VARCHAR(20) NOT NULL DEFAULT 'open',
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    turn_number     INTEGER     NOT NULL DEFAULT 0,
    chat_history    JSONB       NOT NULL DEFAULT '[]'::jsonb,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id)
);

-- Enable logical replication (required for Pub/Sub change data capture)
ALTER TABLE public.ir_active_sessions REPLICA IDENTITY FULL;


-- ── ir_session_history ──────────────────────────────────────────────────────
-- Closed IR sessions archived here after close_session() or expiry.
-- Used to restore context if a user returns after a session expired.

CREATE TABLE IF NOT EXISTS public.ir_session_history (
    id              BIGSERIAL   PRIMARY KEY,
    user_id         UUID        NOT NULL,
    session_id      UUID        NOT NULL UNIQUE,
    iqc_session_id  TEXT        NOT NULL DEFAULT '',
    turn_count      INTEGER     NOT NULL DEFAULT 0,
    chat_history    JSONB       NOT NULL DEFAULT '[]'::jsonb,
    started_at      TIMESTAMPTZ NOT NULL,
    ended_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_reason      VARCHAR(20) NOT NULL DEFAULT 'exit'
);

CREATE INDEX IF NOT EXISTS idx_ir_session_history_user_ended
    ON public.ir_session_history (user_id, ended_at DESC);
