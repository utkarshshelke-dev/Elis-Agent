Feature: Investor Qualification Pipeline
  As an investor on the Grid OS platform
  I want to be qualified through a conversational AI agent
  So that I can be matched with relevant startup investment opportunities

  Background:
    Given a clean IQC pipeline environment

  Scenario: Investor provides a complete profile in one message
    Given the user is identified as an investor with id "550e8400-e29b-41d4-a716-446655440000"
    And the investor profile is empty in the database
    When the investor sends "I run a $50M VC fund investing $1M-$3M per deal in Series A/B Enterprise SaaS across North America. I lead deals with board seats, 10-year fund life, provide GTM and network value, 15 portfolio companies, prefer 20% ownership, seeking AI-native B2B with $2M+ ARR"
    Then the pipeline should extract profile fields including "fund_size_usd"
    And the confidence score should be greater than 0.75
    And the response should contain a score percentage

  Scenario: Founder is rejected by the pipeline
    Given the user is identified as a founder with id "550e8400-e29b-41d4-a716-446655440001"
    When the founder sends any message
    Then the pipeline should set error state to "founder_profile"
    And the response should indicate investors-only access

  Scenario: Investor qualifies after multiple turns
    Given the user is identified as an investor with id "550e8400-e29b-41d4-a716-446655440002"
    And the investor has a partial profile with "stage_focus" and "sector_focus" already set
    When the investor answers the capacity question with "$50M fund, $1M per deal"
    And the investor answers the geo question with "North America and Europe"
    Then the pipeline should not ask about stage or sector again
    And the asked fields should include "capacity" and "geo"
