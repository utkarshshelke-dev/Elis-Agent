"""
Module: tests/bdd/test_investor_qualification_steps.py
Description: pytest-bdd step definitions for the investor qualification feature.
Author: IQC Team
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from pytest_bdd import given, when, then, parsers, scenarios

from services.pipeline_service import (
    S,
    FounderCheckAgent,
    ExtractFromPromptAgent,
    AnalyseAgent,
    QuestionAgent,
    FinalizeAgent,
    _safe_dict,
    _safe_list,
)

scenarios("features/investor_qualification.feature")


# ── Shared context ────────────────────────────────────────────────────────────

def _make_ctx(state: dict):
    ctx              = MagicMock()
    ctx.invocation_id = "bdd-invocation"
    ctx.agent        = MagicMock()
    ctx.agent.name   = "bdd_agent"
    ctx.session      = MagicMock()
    ctx.session.state = dict(state)
    ctx.user_content = None
    return ctx


def _make_text_content(text: str):
    part      = MagicMock()
    part.text = text
    content   = MagicMock()
    content.parts = [part]
    return content


async def _drain(gen):
    events = []
    async for e in gen:
        events.append(e)
    return events


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def pipeline_context():
    return {}


@pytest.fixture
def mock_repo():
    repo = MagicMock()
    repo.get_user_type       = MagicMock(return_value="investor")
    repo.get_investor_profile = MagicMock(return_value={})
    repo.patch_investor_profile = MagicMock(return_value={})
    return repo


# ── Given ─────────────────────────────────────────────────────────────────────

@given("a clean IQC pipeline environment")
def clean_environment(pipeline_context):
    pipeline_context.clear()


@given(parsers.parse('the user is identified as an investor with id "{user_id}"'))
def investor_user(pipeline_context, mock_repo, user_id):
    mock_repo.get_user_type = MagicMock(return_value="investor")
    pipeline_context["user_id"]   = user_id
    pipeline_context["repo"]      = mock_repo
    pipeline_context["state"] = {
        S.USER_ID:          user_id,
        S.USER_TYPE:        "investor",
        S.INVESTOR_PROFILE: "{}",
        S.ASKED_FIELDS:     "[]",
        S.MISSING_FIELDS:   "[]",
        S.CONFIDENCE:       "0.0",
        S.THRESHOLD_MET:    "false",
        S.NEXT_QUESTION:    "",
        S.ERROR:            "",
    }


@given(parsers.parse('the user is identified as a founder with id "{user_id}"'))
def founder_user(pipeline_context, mock_repo, user_id):
    mock_repo.get_user_type = MagicMock(return_value="founder")
    pipeline_context["user_id"] = user_id
    pipeline_context["repo"]    = mock_repo
    pipeline_context["state"] = {
        S.USER_ID:   user_id,
        S.USER_TYPE: "",
    }


@given("the investor profile is empty in the database")
def empty_db_profile(pipeline_context):
    pipeline_context["repo"].get_investor_profile = MagicMock(return_value={})


@given(parsers.parse('the investor has a partial profile with "{f1}" and "{f2}" already set'))
def partial_profile(pipeline_context, f1, f2):
    profile = {f1: ["Series A", "Series B"], f2: ["SaaS", "AI"]}
    pipeline_context["state"][S.INVESTOR_PROFILE] = json.dumps(profile)
    pipeline_context["state"][S.ASKED_FIELDS]     = json.dumps([f1, f2])


# ── When ──────────────────────────────────────────────────────────────────────

@when(parsers.parse('the investor sends "{message}"'))
def investor_sends_message(pipeline_context, message):
    ctx              = _make_ctx(pipeline_context["state"])
    ctx.user_content = _make_text_content(message)
    pipeline_context["ctx"] = ctx


@when("the founder sends any message")
def founder_sends_message(pipeline_context, mock_repo):
    ctx              = _make_ctx(pipeline_context["state"])
    ctx.user_content = _make_text_content("Hello, I want to invest")
    pipeline_context["ctx"] = ctx


@when(parsers.parse('the investor answers the capacity question with "{answer}"'))
def answers_capacity(pipeline_context, answer):
    state = pipeline_context.setdefault("state", {})
    state[S.ASKED_FIELDS] = json.dumps(
        _safe_list(state.get(S.ASKED_FIELDS)) + ["capacity"]
    )
    ctx              = _make_ctx(state)
    ctx.user_content = _make_text_content(answer)
    pipeline_context["ctx"] = ctx


@when(parsers.parse('the investor answers the geo question with "{answer}"'))
def answers_geo(pipeline_context, answer):
    state = pipeline_context["state"]
    asked = _safe_list(state.get(S.ASKED_FIELDS))
    if "capacity" not in asked:
        asked.append("capacity")
    asked.append("geo")
    state[S.ASKED_FIELDS] = json.dumps(asked)
    ctx              = _make_ctx(state)
    ctx.user_content = _make_text_content(answer)
    pipeline_context["ctx"] = ctx


# ── Then ──────────────────────────────────────────────────────────────────────

@then(parsers.parse('the pipeline should extract profile fields including "{field}"'))
@pytest.mark.asyncio
async def check_extracted_field(pipeline_context, field):
    ctx   = pipeline_context["ctx"]
    agent = ExtractFromPromptAgent()
    await _drain(agent._run_async_impl(ctx))
    profile = _safe_dict(ctx.session.state.get(S.INVESTOR_PROFILE))
    assert field in profile, (
        f"Expected '{field}' in profile, got fields: {list(profile.keys())}"
    )


@then("the confidence score should be greater than 0.75")
@pytest.mark.asyncio
async def check_confidence(pipeline_context):
    ctx   = pipeline_context["ctx"]
    agent = AnalyseAgent()
    await _drain(agent._run_async_impl(ctx))
    confidence = float(ctx.session.state.get(S.CONFIDENCE, 0.0))
    assert confidence > 0.75, f"Expected > 0.75, got {confidence}"


@then("the response should contain a score percentage")
@pytest.mark.asyncio
async def check_response_has_score(pipeline_context):
    ctx   = pipeline_context["ctx"]
    agent = FinalizeAgent()
    events = await _drain(agent._run_async_impl(ctx))
    text = events[0].content.parts[0].text if events else ""
    assert "%" in text, f"Expected '%' in response, got: {text[:100]}"


@then('the pipeline should set error state to "founder_profile"')
@pytest.mark.asyncio
async def check_founder_error(pipeline_context, mock_repo):
    mock_repo.get_user_type = MagicMock(return_value="founder")
    ctx   = pipeline_context["ctx"]
    agent = FounderCheckAgent(repo=mock_repo)
    await _drain(agent._run_async_impl(ctx))
    assert ctx.session.state.get(S.ERROR) == "founder_profile"


@then("the response should indicate investors-only access")
@pytest.mark.asyncio
async def check_investors_only_message(pipeline_context, mock_repo):
    ctx   = pipeline_context["ctx"]
    agent = FounderCheckAgent(repo=mock_repo)
    events = await _drain(agent._run_async_impl(ctx))
    text_events = [e for e in events if e.content is not None]
    assert len(text_events) > 0
    text = text_events[-1].content.parts[0].text.lower()
    assert "investor" in text


@then("the pipeline should not ask about stage or sector again")
@pytest.mark.asyncio
async def check_no_repeat_questions(pipeline_context):
    ctx   = pipeline_context["ctx"]
    agent = QuestionAgent()
    await _drain(agent._run_async_impl(ctx))
    next_q = ctx.session.state.get(S.NEXT_QUESTION, "")
    assert "stage" not in next_q.lower()
    assert "sector" not in next_q.lower()


@then(parsers.parse('the asked fields should include "{f1}" and "{f2}"'))
def check_asked_fields(pipeline_context, f1, f2):
    asked = _safe_list(pipeline_context["ctx"].session.state.get(S.ASKED_FIELDS))
    assert f1 in asked, f"Expected '{f1}' in asked: {asked}"
    assert f2 in asked, f"Expected '{f2}' in asked: {asked}"
