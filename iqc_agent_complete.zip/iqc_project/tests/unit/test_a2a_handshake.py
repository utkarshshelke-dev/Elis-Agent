"""
Module: tests/unit/test_a2a_handshake.py
Description: Unit tests for the IQC A2A handshake handler.
Author: IQC Team
"""
from __future__ import annotations

import pytest
from datetime import datetime

from services.a2a_handshake import A2AHandshakeHandler


@pytest.fixture
def handler():
    return A2AHandshakeHandler()


class TestA2AHandshakeHandler:
    @pytest.mark.asyncio
    async def test_successful_handshake(self, handler):
        """A valid request returns status=success with IQC capabilities."""
        request = {
            "handshake_id": "test-hs-001",
            "ir_agent_id":  "ir_domain_agent_abc123",
            "ir_version":   "1.0",
            "capabilities": {"features": ["intent_detection"]},
            "timestamp":    datetime.utcnow().isoformat(),
        }
        response = await handler.handle_handshake_request(request)
        assert response["status"]       == "success"
        assert response["handshake_id"] == "test-hs-001"
        assert response["iqc_capabilities"]["agent_name"] == "iqc_agent"
        assert "correlation_id" in response

    @pytest.mark.asyncio
    async def test_missing_required_fields(self, handler):
        """A request missing ir_version returns status=error."""
        request = {
            "handshake_id": "test-hs-002",
            "ir_agent_id":  "ir_agent_abc",
            # ir_version missing
        }
        response = await handler.handle_handshake_request(request)
        assert response["status"] == "error"
        assert "Missing required fields" in response["error"]

    @pytest.mark.asyncio
    async def test_version_too_old(self, handler):
        """A request with IR version < 1.0 returns status=error."""
        request = {
            "handshake_id": "test-hs-003",
            "ir_agent_id":  "ir_agent_old",
            "ir_version":   "0.5",
            "capabilities": {},
            "timestamp":    datetime.utcnow().isoformat(),
        }
        response = await handler.handle_handshake_request(request)
        assert response["status"] == "error"
        assert "version" in response["error"].lower()

    @pytest.mark.asyncio
    async def test_version_11_compatible(self, handler):
        """A request with IR version 1.1 is compatible (>= 1.0)."""
        request = {
            "handshake_id": "test-hs-004",
            "ir_agent_id":  "ir_agent_new",
            "ir_version":   "1.1",
            "timestamp":    datetime.utcnow().isoformat(),
        }
        response = await handler.handle_handshake_request(request)
        assert response["status"] == "success"

    @pytest.mark.asyncio
    async def test_session_recorded(self, handler):
        """A successful handshake is recorded and validate_session returns True."""
        request = {
            "handshake_id": "test-hs-005",
            "ir_agent_id":  "ir_agent_x",
            "ir_version":   "1.0",
        }
        await handler.handle_handshake_request(request)
        assert await handler.validate_session("test-hs-005") is True

    @pytest.mark.asyncio
    async def test_unknown_session_false(self, handler):
        """validate_session returns False for an unknown handshake_id."""
        assert await handler.validate_session("nonexistent-id") is False
