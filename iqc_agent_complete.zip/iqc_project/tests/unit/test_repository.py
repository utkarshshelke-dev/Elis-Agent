"""
Module: tests/unit/test_repository.py
Description: Unit tests for the PostgresRepo data access layer.
             All DB calls are mocked with MagicMock — no real DB needed.
Author: IQC Team
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from data.repository import PostgresRepo


@pytest.fixture
def mock_engine():
    """Return a MagicMock that mimics a SQLAlchemy engine."""
    engine = MagicMock()
    conn   = MagicMock()
    engine.connect.return_value.__enter__ = MagicMock(return_value=conn)
    engine.connect.return_value.__exit__  = MagicMock(return_value=False)
    engine.begin.return_value.__enter__   = MagicMock(return_value=conn)
    engine.begin.return_value.__exit__    = MagicMock(return_value=False)
    return engine, conn


@pytest.fixture
def repo(mock_engine):
    """Return a PostgresRepo backed by a mock engine."""
    engine, _ = mock_engine
    return PostgresRepo(engine)


class TestGetUserType:
    def test_returns_investor_type(self, mock_engine, repo):
        """get_user_type returns 'investor' when row found."""
        _, conn = mock_engine
        row_mock = MagicMock()
        row_mock.__getitem__ = lambda self, k: "investor" if k == "primary_category" else None
        conn.execute.return_value.mappings.return_value.first.return_value = row_mock

        result = repo.get_user_type("test-uuid-1234")
        assert result == "investor"

    def test_returns_none_when_not_found(self, mock_engine, repo):
        """get_user_type returns None when no row found."""
        _, conn = mock_engine
        conn.execute.return_value.mappings.return_value.first.return_value = None

        result = repo.get_user_type("unknown-uuid")
        assert result is None

    def test_returns_none_on_db_error(self, mock_engine, repo):
        """get_user_type returns None gracefully on DB error."""
        engine, _ = mock_engine
        engine.connect.side_effect = Exception("DB connection failed")

        result = repo.get_user_type("any-uuid")
        assert result is None


class TestIsInvestor:
    def test_true_for_investor(self, mock_engine, repo):
        _, conn = mock_engine
        row_mock = MagicMock()
        row_mock.__getitem__ = lambda self, k: "investor"
        conn.execute.return_value.mappings.return_value.first.return_value = row_mock
        assert repo.is_investor("some-uuid") is True

    def test_false_for_founder(self, mock_engine, repo):
        _, conn = mock_engine
        row_mock = MagicMock()
        row_mock.__getitem__ = lambda self, k: "founder"
        conn.execute.return_value.mappings.return_value.first.return_value = row_mock
        assert repo.is_investor("some-uuid") is False

    def test_false_when_not_found(self, mock_engine, repo):
        _, conn = mock_engine
        conn.execute.return_value.mappings.return_value.first.return_value = None
        assert repo.is_investor("unknown") is False


class TestGetInvestorProfile:
    def test_returns_merged_profile(self, mock_engine, repo):
        """get_investor_profile merges impact_profiles_v2 with intelligence_data."""
        _, conn = mock_engine
        profile_data = {"fund_size_usd": 5_000_000, "geo": "North America"}

        # First call: impact_profiles_v2
        row1 = MagicMock()
        row1.__getitem__ = lambda self, k: json.dumps(profile_data) if k == "investor_profile" else None
        # Second call: intelligence_data table exists check
        # Third call: intelligence_data query
        conn.execute.return_value.mappings.return_value.first.side_effect = [row1, None]
        conn.execute.return_value.scalar.return_value = False  # intelligence_data doesn't exist

        repo._intelligence_data_exists = False
        result = repo.get_investor_profile("investor-uuid")
        assert result.get("fund_size_usd") == 5_000_000

    def test_returns_empty_on_db_error(self, mock_engine, repo):
        """get_investor_profile returns {} gracefully on DB error."""
        engine, _ = mock_engine
        engine.connect.side_effect = Exception("timeout")

        result = repo.get_investor_profile("any-uuid")
        assert result == {}


class TestPatchInvestorProfile:
    def test_skips_when_not_qualified(self, repo):
        """patch_investor_profile skips the write when qualified=False."""
        with patch.object(repo, "get_investor_profile", return_value={}):
            result = repo.patch_investor_profile(
                "investor-uuid", {"geo": "UK"}, qualified=False
            )
        # Should return existing profile (empty dict in this mock)
        assert result == {}

    def test_skips_when_empty_patch(self, repo):
        """patch_investor_profile skips the write when patch is empty."""
        with patch.object(repo, "get_investor_profile", return_value={}):
            result = repo.patch_investor_profile("investor-uuid", {}, qualified=True)
        assert result == {}

    def test_skips_when_not_investor(self, mock_engine, repo):
        """patch_investor_profile skips the write when user is a founder."""
        with patch.object(repo, "is_investor", return_value=False), \
             patch.object(repo, "get_investor_profile", return_value={}):
            result = repo.patch_investor_profile(
                "founder-uuid", {"geo": "UK"}, qualified=True
            )
        assert result == {}
