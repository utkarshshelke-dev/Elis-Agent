"""
Module: tests/unit/test_pipeline.py
Description: Unit tests for the IQC pipeline sub-agents.
             All external dependencies (DB, Gemini) are mocked.
Author: IQC Team
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from services.pipeline_service import (
    S,
    FounderCheckAgent,
    FetchContextAgent,
    ExtractFromPromptAgent,
    AnalyseAgent,
    QuestionAgent,
    FinalizeAgent,
    _context_aware_extract,
    _is_valid_uuid,
    _safe_dict,
    _safe_list,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_ctx(state: dict | None = None):
    """Build a minimal mock InvocationContext."""
    ctx              = MagicMock()
    ctx.invocation_id = "test-invocation"
    ctx.agent        = MagicMock()
    ctx.agent.name   = "test_agent"
    ctx.session      = MagicMock()
    ctx.session.state = dict(state or {})
    ctx.user_content = None
    return ctx


def _make_text_content(text: str):
    """Build a mock user_content with a text Part."""
    part      = MagicMock()
    part.text = text
    content   = MagicMock()
    content.parts = [part]
    return content


async def _collect_events(generator):
    """Drain an AsyncGenerator into a list of events."""
    events = []
    async for event in generator:
        events.append(event)
    return events


# ── _is_valid_uuid ────────────────────────────────────────────────────────────

class TestIsValidUUID:
    def test_valid_uuid(self):
        assert _is_valid_uuid("550e8400-e29b-41d4-a716-446655440000") is True

    def test_invalid_string(self):
        assert _is_valid_uuid("not-a-uuid") is False

    def test_empty_string(self):
        assert _is_valid_uuid("") is False


# ── _safe_dict / _safe_list ───────────────────────────────────────────────────

class TestSafeHelpers:
    def test_safe_dict_from_string(self):
        assert _safe_dict('{"a": 1}') == {"a": 1}

    def test_safe_dict_from_dict(self):
        assert _safe_dict({"a": 1}) == {"a": 1}

    def test_safe_dict_none(self):
        assert _safe_dict(None) == {}

    def test_safe_list_from_string(self):
        assert _safe_list('["a", "b"]') == ["a", "b"]

    def test_safe_list_none(self):
        assert _safe_list(None) == []


# ── _context_aware_extract ────────────────────────────────────────────────────

class TestContextAwareExtract:
    def test_geo_extraction(self):
        result = _context_aware_extract("North America and Europe", "geo")
        assert result.get("geo") == "North America and Europe"

    def test_timeline_extraction(self):
        result = _context_aware_extract("10-year fund, 5-year hold", "timeline")
        assert "timeline" in result

    def test_authority_lead(self):
        result = _context_aware_extract("I lead the deal", "authority")
        assert result.get("authority") == "lead"

    def test_authority_follow(self):
        result = _context_aware_extract("We follow in rounds", "authority")
        assert result.get("authority") == "follow"

    def test_empty_text_returns_empty(self):
        result = _context_aware_extract("", "geo")
        assert result == {}

    def test_empty_field_returns_empty(self):
        result = _context_aware_extract("North America", "")
        assert result == {}


# ── FounderCheckAgent ─────────────────────────────────────────────────────────

class TestFounderCheckAgent:
    @pytest.fixture
    def mock_repo(self):
        repo = MagicMock()
        repo.get_user_type = MagicMock(return_value="investor")
        return repo

    @pytest.mark.asyncio
    async def test_sets_investor_type_in_state(self, mock_repo):
        """FounderCheckAgent sets USER_TYPE in session state for investors."""
        agent = FounderCheckAgent(repo=mock_repo)
        ctx   = _make_ctx(state={S.USER_ID: "550e8400-e29b-41d4-a716-446655440000"})
        events = await _collect_events(agent._run_async_impl(ctx))
        assert ctx.session.state.get(S.USER_TYPE) == "investor"

    @pytest.mark.asyncio
    async def test_blocks_founder(self, mock_repo):
        """FounderCheckAgent sets ERROR for founder accounts."""
        mock_repo.get_user_type = MagicMock(return_value="founder")
        agent  = FounderCheckAgent(repo=mock_repo)
        ctx    = _make_ctx(state={S.USER_ID: "550e8400-e29b-41d4-a716-446655440000"})
        events = await _collect_events(agent._run_async_impl(ctx))
        assert ctx.session.state.get(S.ERROR) == "founder_profile"
        # Should yield a text event with error message
        text_events = [e for e in events if e.content is not None]
        assert len(text_events) == 1

    @pytest.mark.asyncio
    async def test_skips_db_when_from_ir(self, mock_repo):
        """FounderCheckAgent skips DB check when request is from IR agent."""
        agent = FounderCheckAgent(repo=mock_repo)
        ctx   = _make_ctx(state={
            S.USER_ID: "550e8400-e29b-41d4-a716-446655440000",
            S.FROM_IR: "true",
        })
        await _collect_events(agent._run_async_impl(ctx))
        mock_repo.get_user_type.assert_not_called()
        assert ctx.session.state.get(S.USER_TYPE) == "investor"


# ── QuestionAgent ─────────────────────────────────────────────────────────────

class TestQuestionAgent:
    @pytest.mark.asyncio
    async def test_asks_first_missing_field(self):
        """QuestionAgent picks the first unasked field in priority order."""
        agent  = QuestionAgent()
        ctx    = _make_ctx(state={
            S.THRESHOLD_MET:  "false",
            S.MISSING_FIELDS: json.dumps(["capacity", "geo", "stage"]),
            S.ASKED_FIELDS:   json.dumps([]),
            S.CONFIDENCE:     "0.3",
        })
        await _collect_events(agent._run_async_impl(ctx))
        next_q = ctx.session.state.get(S.NEXT_QUESTION, "")
        asked  = _safe_list(ctx.session.state.get(S.ASKED_FIELDS))
        assert "capacity" in asked
        assert len(next_q) > 0

    @pytest.mark.asyncio
    async def test_no_question_when_threshold_met(self):
        """QuestionAgent emits empty NEXT_QUESTION when threshold is already met."""
        agent  = QuestionAgent()
        ctx    = _make_ctx(state={S.THRESHOLD_MET: "true"})
        await _collect_events(agent._run_async_impl(ctx))
        assert ctx.session.state.get(S.NEXT_QUESTION) == ""


# ── FinalizeAgent ─────────────────────────────────────────────────────────────

class TestFinalizeAgent:
    @pytest.mark.asyncio
    async def test_qualified_message(self):
        """FinalizeAgent emits qualification success message when threshold met."""
        agent  = FinalizeAgent()
        ctx    = _make_ctx(state={
            S.THRESHOLD_MET: "true",
            S.SCORE:         "85%",
            S.ERROR:         "",
        })
        events = await _collect_events(agent._run_async_impl(ctx))
        text   = events[0].content.parts[0].text
        assert "85%" in text
        assert "complete" in text.lower()

    @pytest.mark.asyncio
    async def test_question_message_when_not_qualified(self):
        """FinalizeAgent includes the next question when not yet qualified."""
        agent  = FinalizeAgent()
        ctx    = _make_ctx(state={
            S.THRESHOLD_MET:  "false",
            S.SCORE:          "40%",
            S.NEXT_QUESTION:  "What sectors do you invest in?",
            S.ERROR:          "",
        })
        events = await _collect_events(agent._run_async_impl(ctx))
        text   = events[0].content.parts[0].text
        assert "What sectors" in text
