"""
Module: tests/unit/test_scoring_service.py
Description: Unit tests for the investor profile scoring service.
             Tests both the deterministic fallback scorer and the
             score_profile_async interface.
Author: IQC Team
"""
from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, patch

from services.scoring_service import _smart_fallback, score_profile_async, _build_scoring_profile
from data.schemas import ESSENTIAL_FIELDS, QUALIFY_THRESHOLD


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def full_profile():
    """A complete investor profile that should score above the qualify threshold."""
    return {
        "fund_size_usd":          50_000_000,
        "average_check_size_usd": 1_000_000,
        "stage_focus":            ["Series A", "Series B"],
        "sector_focus":           ["Enterprise SaaS", "AI/ML"],
        "geo":                    "North America",
        "investor_type":          "vc_fund",
        "authority":              "lead",
        "portfolio_size":         20,
        "investments_last_12_months": 4,
        "timeline":               "10-year fund, 5-year hold",
        "value_add":              "GTM strategy, enterprise network, hiring support",
        "deal_prefs":             "Lead, 15–20% ownership, pro-rata rights",
        "seeking":                "AI-native B2B SaaS with $2M+ ARR",
    }


@pytest.fixture
def empty_profile():
    """An investor profile with no fields populated."""
    return {}


# ── Smart fallback tests ──────────────────────────────────────────────────────

class TestSmartFallback:
    def test_full_profile_scores_high(self, full_profile):
        """A complete profile should score at or above the qualify threshold."""
        scoring = _build_scoring_profile(full_profile)
        scores  = _smart_fallback(scoring)
        total   = sum(scores.values()) / len(ESSENTIAL_FIELDS)
        assert total >= QUALIFY_THRESHOLD, f"Expected ≥ {QUALIFY_THRESHOLD}, got {total:.3f}"

    def test_empty_profile_scores_zero(self, empty_profile):
        """An empty profile should score 0 on all dimensions."""
        scoring = _build_scoring_profile(empty_profile)
        scores  = _smart_fallback(scoring)
        assert all(v == 0.0 for v in scores.values())

    def test_all_essential_fields_present(self, full_profile):
        """All 10 essential fields should appear in the scores dict."""
        scoring = _build_scoring_profile(full_profile)
        scores  = _smart_fallback(scoring)
        for field in ESSENTIAL_FIELDS:
            assert field in scores, f"Missing field: {field}"

    def test_capacity_partial(self):
        """A profile with only fund_size (no check size) should score below full."""
        profile = {"fund_size_usd": 50_000_000}
        scoring = _build_scoring_profile(profile)
        scores  = _smart_fallback(scoring)
        assert 0.0 < scores["capacity"] < 0.95

    def test_scores_clamped(self, full_profile):
        """All scores must be in [0.0, 1.0]."""
        scoring = _build_scoring_profile(full_profile)
        scores  = _smart_fallback(scoring)
        for k, v in scores.items():
            assert 0.0 <= v <= 1.0, f"{k} out of range: {v}"


# ── score_profile_async tests ─────────────────────────────────────────────────

class TestScoreProfileAsync:
    @pytest.mark.asyncio
    async def test_returns_four_tuple(self, full_profile):
        """score_profile_async always returns (scores, confidence, qualified, missing)."""
        scoring                           = _build_scoring_profile(full_profile)
        scores, confidence, qualified, missing = await score_profile_async(scoring)
        assert isinstance(scores,     dict)
        assert isinstance(confidence, float)
        assert isinstance(qualified,  bool)
        assert isinstance(missing,    list)

    @pytest.mark.asyncio
    async def test_full_profile_qualifies(self, full_profile):
        """A complete profile should result in qualified=True."""
        scoring = _build_scoring_profile(full_profile)
        _, confidence, qualified, _ = await score_profile_async(scoring)
        assert qualified is True
        assert confidence >= QUALIFY_THRESHOLD

    @pytest.mark.asyncio
    async def test_empty_profile_does_not_qualify(self, empty_profile):
        """An empty profile should result in qualified=False."""
        scoring = _build_scoring_profile(empty_profile)
        _, confidence, qualified, missing = await score_profile_async(scoring)
        assert qualified is False
        assert len(missing) == len(ESSENTIAL_FIELDS)

    @pytest.mark.asyncio
    async def test_falls_back_on_gemini_error(self, full_profile):
        """score_profile_async returns valid result even when Gemini raises."""
        scoring = _build_scoring_profile(full_profile)
        with patch(
            "services.scoring_service._score_with_gemini_async",
            new=AsyncMock(side_effect=Exception("API error")),
        ):
            scores, confidence, qualified, missing = await score_profile_async(scoring)
        assert isinstance(scores, dict)
        assert isinstance(confidence, float)
