"""
Module: config/settings.py
Description: Centralised Pydantic settings for the IQC agent.
             Reads from .env (local development) or environment variables
             (Cloud Run / Agent Engine). No code changes needed between
             local and cloud — dual-mode by design.
Author: IQC Team
"""
from __future__ import annotations

import logging
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_ENV_PATH = Path(__file__).parent.parent / ".env"
logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """
    Application configuration loaded from environment variables or .env file.

    All secrets (DB_PASS, etc.) must be set as environment variables in
    production — never hardcoded. DB_PASS has no default and will raise
    a ValidationError at startup if missing.

    Attributes:
        db_host:               PostgreSQL host IP or hostname.
        db_port:               PostgreSQL port.
        db_user:               Database login user.
        db_pass:               Database password — REQUIRED, no default.
        db_name:               Database name.
        google_cloud_project:  GCP project ID for Vertex AI.
        vertex_location:       GCP region for Vertex AI.
        vertex_model:          Gemini model name for scoring and extraction.
        log_level:             Logging level string (default: INFO).
        log_dir:               Log file directory.
        port:                  HTTP server port (default: 8080).
    """

    # ── Database ─────────────────────────────────────────────────────────────
    db_host: str = "localhost"
    db_port: str = "5432"
    db_user: str = "postgres"
    db_pass: str = ""          # Set via environment — never hardcode
    db_name: str = "grid_os_poc"

    # ── Google Cloud ─────────────────────────────────────────────────────────
    google_cloud_project: str = "the-grid-os"
    vertex_location:      str = "us-central1"
    vertex_model:         str = "gemini-2.0-flash"

    # ── App ──────────────────────────────────────────────────────────────────
    log_level: str = "INFO"
    log_dir:   str = "logs"
    port:      int = 8080

    model_config = SettingsConfigDict(
        env_file=str(_ENV_PATH) if _ENV_PATH.exists() else None,
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    @property
    def database_url(self) -> str:
        """Composite SQLAlchemy connection URL built from individual DB vars."""
        return (
            f"postgresql://{self.db_user}:{self.db_pass}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )


# Singleton — import and use everywhere
settings = Settings()

__all__ = ["settings", "Settings"]
