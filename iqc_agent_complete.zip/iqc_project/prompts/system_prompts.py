"""
Module: prompts/system_prompts.py
Description: Prompt constants and builder functions for the IQC pipeline.
             All field descriptions, quick-question templates, and example
             values live here so LLM prompts are assembled from a single place.
Author: IQC Team
"""
from __future__ import annotations

from typing import Dict, List

# ── Field metadata ────────────────────────────────────────────────────────────

FIELD_DESCRIPTIONS: Dict[str, str] = {
    "capacity":   "investment capacity (check size + fund size)",
    "stage":      "target investment stages (seed, Series A/B, growth)",
    "sector":     "focus sectors and industries",
    "geo":        "geographic regions",
    "authority":  "role in investment decisions (lead/co-lead/follow)",
    "timeline":   "investment timeline and holding period",
    "value_add":  "value beyond capital (network, GTM, ops)",
    "portfolio":  "current portfolio details (size, exits, unicorns)",
    "deal_prefs": "deal preferences (ownership %, board seat, pro-rata)",
    "seeking":    "what you are actively looking for right now",
}

QUICK_PROMPTS: Dict[str, str] = {
    "capacity":   (
        "To assess your investment capacity, could you share your **fund size** "
        "(total AUM) and your **typical check size** per investment? "
        "(e.g. '$50M fund, $500K–$2M per deal')"
    ),
    "stage":      (
        "Which **investment stages** do you focus on? "
        "(e.g. Pre-Seed, Seed, Series A, Series B+)"
    ),
    "sector":     (
        "Which **sectors or industries** do you invest in? "
        "(e.g. Fintech, Enterprise SaaS, HealthTech, AI/ML)"
    ),
    "geo":        (
        "What **geographic regions** do you primarily invest in? "
        "(e.g. North America, Southeast Asia, Europe)"
    ),
    "authority":  (
        "How do you typically participate in deals — as a **lead investor**, "
        "co-investor, or follow-on? And are you a VC fund, angel, family office, "
        "or corporate VC?"
    ),
    "timeline":   (
        "What is your **investment timeline**? "
        "(e.g. 10-year fund life, 5-year holding period)"
    ),
    "value_add":  (
        "Beyond capital, what **value do you bring** to portfolio companies? "
        "(e.g. GTM strategy, hiring network, partnerships, market access)"
    ),
    "portfolio":  (
        "Could you share details about your **current portfolio**? "
        "(e.g. number of companies, new investments in the last 12 months, "
        "notable exits or unicorns)"
    ),
    "deal_prefs": (
        "Do you have **deal preferences**? "
        "(e.g. minimum ownership %, pro-rata rights, board seat requirements)"
    ),
    "seeking":    (
        "What types of opportunities are you **actively seeking** right now? "
        "(e.g. specific stage, revenue thresholds, sector, company profile)"
    ),
}

FIELD_EXAMPLES: Dict[str, str] = {
    "capacity":   "$1M–$5M per deal, $50M fund",
    "stage":      "Series A to B, growth stage",
    "sector":     "Enterprise SaaS, B2B AI/ML",
    "geo":        "North America, UK, Germany",
    "authority":  "Lead investor, board seat, VC fund",
    "timeline":   "10-year fund, 5-year hold",
    "value_add":  "GTM strategy, sales network, enterprise intros",
    "portfolio":  "20 B2B SaaS companies, 3 exits, 2 unicorns",
    "deal_prefs": "Lead/co-lead, 15–20% minimum ownership, pro-rata",
    "seeking":    "AI-native B2B SaaS with $2M+ ARR and strong unit economics",
}

# System prompt for Gemini-based field extraction
EXTRACTION_SYSTEM_PROMPT = """\
You are an assistant that extracts structured investor-profile fields from free-form text.
Return ONLY a valid JSON object with any of these keys you can confidently extract:
{
  "fund_size_usd": <number>,
  "average_check_size_usd": <number>,
  "stage_focus": <list of strings>,
  "sector_focus": <list of strings>,
  "geo": <string>,
  "investor_type": <"angel_investor"|"vc_fund"|"family_office"|"corporate_vc"|"accelerator">,
  "authority": <"lead"|"co-lead"|"follow">,
  "portfolio_size": <integer>,
  "investments_last_12_months": <integer>,
  "timeline": <string>,
  "value_add": <string>,
  "deal_prefs": <string>,
  "seeking": <string>
}
Rules:
- Only include keys you are CONFIDENT about.
- "$50M" → 50000000 (integer, no currency symbol).
- Return {} if nothing relevant is found.
- Never invent data.
"""


# ── Builder functions ─────────────────────────────────────────────────────────

def build_question_text(missing_fields: List[str]) -> str:
    """
    Build a question string to ask the investor about missing profile fields.

    Selects question style based on how many fields are missing:
    - 7+ fields: one comprehensive multi-field prompt
    - 4–6 fields: concise list question
    - 1–3 fields: single targeted question for the first missing field

    Args:
        missing_fields: Field names still needing to be collected.

    Returns:
        A single question string ready to show to the investor.
    """
    if not missing_fields:
        return ""

    if len(missing_fields) >= 7:
        parts = [
            f"{f} ({FIELD_DESCRIPTIONS.get(f, f)}, 10%)"
            for f in missing_fields
        ]
        return (
            f"Your profile is missing {len(missing_fields)} of 10 fields "
            f"(each worth 10%): {'; '.join(parts)}. "
            "Please provide all in one response. "
            "Example: 'I invest $500K–$2M per deal ($25M fund), Series A–B in "
            "Enterprise SaaS and AI/ML across North America and UK. Lead investor "
            "with board seats, 5-year hold. Provide GTM strategy and sales network. "
            "Portfolio: 15 B2B SaaS, 3 exits. Prefer leading, 20%+ ownership, "
            "pro-rata. Seeking AI-native B2B with $2M+ ARR.'"
        )

    if len(missing_fields) <= 3:
        field = missing_fields[0]
        return QUICK_PROMPTS.get(
            field,
            f"Could you tell me about your **{field.replace('_', ' ')}**?",
        )

    # 4–6 fields
    parts = [
        f"{f} ({FIELD_DESCRIPTIONS.get(f, f)}, 10%)"
        for f in missing_fields
    ]
    return (
        f"Missing {len(missing_fields)} fields: {'; '.join(parts)}. "
        "Example: '$1M–$5M per deal, Series A–B, Enterprise SaaS, North America, "
        "lead investor, 5-year hold, GTM strategy, 15 SaaS portfolio, "
        "prefer lead/20%+ ownership, seeking AI-native B2B with $2M+ ARR'"
    )


def build_explanation_text(
    missing_fields:     List[str],
    current_confidence: float,
    threshold:          float,
) -> str:
    """
    Build a short explanation of why the investor profile does not yet qualify.

    Args:
        missing_fields:     Fields with scores below the threshold.
        current_confidence: Current aggregate confidence (0.0–1.0).
        threshold:          Required confidence to qualify.

    Returns:
        A one-sentence explanation suitable for display in the conversation.
    """
    num           = len(missing_fields)
    field_summary = ", ".join(missing_fields[:3])
    if num > 3:
        field_summary += "..."
    return (
        f"Your profile has {num} missing/weak "
        f"field{'s' if num != 1 else ''} ({field_summary}). "
        f"Each of the 10 fields contributes 10% to qualification. "
        f"Current score: {current_confidence:.0%}, need: {threshold:.0%}."
    )


__all__ = [
    "FIELD_DESCRIPTIONS",
    "QUICK_PROMPTS",
    "FIELD_EXAMPLES",
    "EXTRACTION_SYSTEM_PROMPT",
    "build_question_text",
    "build_explanation_text",
]
