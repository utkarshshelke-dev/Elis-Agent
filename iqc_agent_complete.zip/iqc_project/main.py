"""
Module: main.py
Description: FastAPI server for the IQC Agent.
             Provides /invoke, /health, /metrics/agent, and /evaluate_enterprise
             endpoints. Wraps the ADK pipeline with session memory, LLM judge
             scoring, and structured error handling.
Author: IQC Team
"""
from __future__ import annotations

import json
import logging
import re as _re
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Dict, Optional

import vertexai
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from vertexai.preview.generative_models import GenerativeModel

from config.settings import settings
from data.engine import get_engine
from data.repository import PostgresRepo
from services.logging_service import setup_logging, get_logger
from services.pipeline_service import build_investor_qualification_agent

setup_logging(level=settings.log_level, log_dir=settings.log_dir)
logger = get_logger("iqc.api")

# ── In-memory session store ───────────────────────────────────────────────────

SESSION_TTL = 3600  # 60 minutes

_session_store: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
    "fields":       {},
    "asked_fields": [],
    "last_seen":    0.0,
})


def _get_session(user_id: str) -> Dict[str, Any]:
    entry = _session_store[user_id]
    if time.time() - entry["last_seen"] > SESSION_TTL:
        _session_store[user_id] = {"fields": {}, "asked_fields": [], "last_seen": time.time()}
        return _session_store[user_id]
    return entry


def _update_session(user_id: str, result: Dict[str, Any]) -> None:
    entry = _get_session(user_id)
    entry["fields"].update(result.get("investor_profile") or {})
    for f in result.get("asked_fields") or []:
        if f not in entry["asked_fields"]:
            entry["asked_fields"].append(f)
    entry["last_seen"] = time.time()


# ── Request / Response models ─────────────────────────────────────────────────

class InvokeRequest(BaseModel):
    user_id:    str
    prompt:     str
    session_id: str
    trace_id:   str
    answers:    Optional[Dict[str, Any]] = None


class InvokeResponse(BaseModel):
    result: Dict[str, Any]


# ── App lifecycle ─────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("IQC Agent (FastAPI) starting...")

    vertexai.init(
        project=settings.google_cloud_project,
        location=settings.vertex_location,
    )
    app.state.judge_model = GenerativeModel("gemini-2.0-flash")

    engine = get_engine()
    if engine is None:
        raise RuntimeError(
            "DB_PASS not set — cannot start IQC Agent. "
            "Set DB_PASS, DB_HOST, DB_USER, DB_NAME environment variables."
        )
    app.state.repo  = PostgresRepo(engine)
    app.state.agent = build_investor_qualification_agent(app.state.repo)

    logger.info("IQC Agent ready")
    yield
    logger.info("IQC Agent shutting down")


# ── FastAPI app ───────────────────────────────────────────────────────────────

app = FastAPI(
    lifespan=lifespan,
    title="IQC Agent API",
    version="3.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── LLM Judge ─────────────────────────────────────────────────────────────────

def _llm_judge(judge_model: GenerativeModel, prompt: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Evaluate agent decision quality with an LLM judge.

    Args:
        judge_model: Gemini model for evaluation.
        prompt:      The original user prompt.
        result:      The agent's result dict.

    Returns:
        Dict with 'score' (0–10) and 'reason' string.
    """
    compact = {
        "qualified":      result.get("qualified"),
        "confidence":     result.get("confidence"),
        "missing_fields": result.get("missing_fields"),
        "score":          result.get("score"),
    }
    judge_prompt = (
        "You are evaluating the quality of an investor qualification decision.\n\n"
        f"User Prompt:\n{prompt}\n\n"
        f"Agent Decision:\n{json.dumps(compact, indent=2)}\n\n"
        "Score reasoning quality from 0–10.\n"
        'Return ONLY valid JSON: {"score": 0-10, "reason": "short explanation"}'
    )
    try:
        response = judge_model.generate_content(judge_prompt)
        raw      = response.text.strip()
        match    = _re.search(r"\{.*\}", raw, _re.DOTALL)
        if not match:
            return {"score": 0, "reason": "Invalid judge format"}
        parsed = json.loads(match.group(0))
        return {"score": int(parsed.get("score", 0)), "reason": str(parsed.get("reason", ""))}
    except Exception as exc:
        logger.warning("LLM Judge error: %s", exc)
        return {"score": 0, "reason": f"Judge error: {exc}"}


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    """API root with endpoint map."""
    return {
        "name":    "IQC Agent API",
        "version": "3.0",
        "status":  "running",
        "endpoints": {
            "health":               "/health",
            "invoke":               "/invoke (POST)",
            "evaluate_enterprise":  "/evaluate_enterprise (POST)",
        },
        "docs": "/docs",
    }


@app.get("/health")
async def health_check():
    """Liveness probe endpoint."""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}


@app.post("/invoke", response_model=InvokeResponse)
async def invoke(req: InvokeRequest):
    """
    Main investor qualification endpoint.

    Runs the IQC pipeline for one conversation turn.
    Returns the agent result with score, qualified flag, and next question.

    Args:
        req: InvokeRequest with user_id, prompt, session_id, trace_id, answers.

    Returns:
        InvokeResponse wrapping the pipeline result dict.

    Raises:
        HTTPException 500: On unhandled pipeline failure.
    """
    t_start = time.perf_counter()
    logger.info(
        "invoke | START | user=%s | session=%s | prompt_len=%d",
        req.user_id, req.session_id, len(req.prompt),
    )
    try:
        session = _get_session(req.user_id)
        payload = {
            "user_id":    req.user_id,
            "session_id": req.session_id,
            "trace_id":   req.trace_id,
            "prompt":     req.prompt,
            "answers":    {**(req.answers or {}), **session["fields"]},
        }
        out    = await app.state.agent.ainvoke(payload)
        result = out.get("result", out)

        judge = _llm_judge(app.state.judge_model, req.prompt, result)
        logger.info(
            "invoke | judge=%.1f | reason=%s | user=%s",
            judge["score"], judge.get("reason", ""), req.user_id,
        )

        _update_session(req.user_id, result)

        latency_ms = (time.perf_counter() - t_start) * 1000
        logger.info(
            "invoke | END | user=%s | qualified=%s | score=%s | ms=%.0f",
            req.user_id,
            result.get("qualified"),
            result.get("score"),
            latency_ms,
        )
        return {"result": result}

    except Exception as exc:
        logger.exception("invoke | FAILED | user=%s | %s", req.user_id, exc)
        raise HTTPException(status_code=500, detail="Internal server error")


@app.post("/evaluate_enterprise")
async def evaluate_enterprise():
    """
    Batch evaluation endpoint — runs the pipeline against all investor users.
    Sets eval_mode=True so SaveCollectedAgent skips DB writes.
    """
    logger.info("evaluate_enterprise | START")
    user_ids = await __import__("asyncio").to_thread(
        app.state.repo.get_all_eval_users, 5
    )
    results = []
    for uid in user_ids:
        try:
            out = await app.state.agent.ainvoke({
                "user_id":    uid,
                "session_id": f"eval-{uid}",
                "trace_id":   f"eval-{uid}",
                "prompt":     "enterprise evaluation",
                "answers":    {},
                "eval_mode":  True,
            })
            results.append({"user_id": uid, "result": out.get("result", {})})
        except Exception as exc:
            logger.error("evaluate_enterprise | user=%s | %s", uid, exc)
            results.append({"user_id": uid, "error": str(exc)})

    logger.info("evaluate_enterprise | DONE | count=%d", len(results))
    return {"enterprise_results": results, "count": len(results)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=settings.port)
