"""
Module: data/repository.py
Description: Repository class for all IQC database access.
             ALL SQL lives here — services never write raw SQL.
             Uses engine.begin() for all writes (ACID Atomicity).
             SELECT ... FOR UPDATE inside write transactions (ACID Isolation).
Author: IQC Team
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)


class PostgresRepo:
    """
    Data access layer for investor qualification data.

    Encapsulates all SQL against basic_profiles, impact_profiles_v2,
    and intelligence_data. Uses a shared SQLAlchemy Engine for
    connection pooling and ACID-compliant writes.

    Attributes:
        engine:                     Shared SQLAlchemy engine.
        _intelligence_data_exists:  Cached table-existence flag.
    """

    def __init__(self, engine: Engine) -> None:
        """
        Initialise the repository with a SQLAlchemy engine.

        Args:
            engine: Configured SQLAlchemy engine. No I/O at construction time.
        """
        self.engine = engine
        self._intelligence_data_exists: Optional[bool] = None

    # ── Private helpers ───────────────────────────────────────────────────────

    def _table_exists(self, table_name: str) -> bool:
        """
        Check whether a table exists in the public schema (cached after first call).

        Args:
            table_name: Table name to check.

        Returns:
            True if the table exists, False otherwise.
        """
        if table_name == "intelligence_data" and self._intelligence_data_exists is not None:
            return self._intelligence_data_exists

        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_schema = 'public'
                        AND table_name = :tname
                    )
                """), {"tname": table_name}).scalar()
                if table_name == "intelligence_data":
                    self._intelligence_data_exists = result
                logger.info("_table_exists | %s=%s", table_name, result)
                return bool(result)
        except Exception as exc:
            logger.error("_table_exists | FAILED | table=%s | %s", table_name, exc)
            if table_name == "intelligence_data":
                self._intelligence_data_exists = False
            return False

    # ── READ: user / founder check ────────────────────────────────────────────

    def get_user_type(self, user_id: str) -> Optional[str]:
        """
        Fetch the primary_category (user type) for a given user from basic_profiles.

        Args:
            user_id: User UUID string.

        Returns:
            Category string (e.g. 'investor', 'founder'), or None if not found.
        """
        logger.info("get_user_type | START | user=%s", user_id)
        start = time.perf_counter()
        try:
            with self.engine.connect() as conn:
                row = conn.execute(text("""
                    SELECT primary_category
                    FROM public.basic_profiles
                    WHERE id = :uid
                    LIMIT 1
                """), {"uid": user_id}).mappings().first()

                elapsed_ms = (time.perf_counter() - start) * 1000
                if row and row["primary_category"]:
                    logger.info(
                        "get_user_type | FOUND | user=%s | type=%s | ms=%.1f",
                        user_id, row["primary_category"], elapsed_ms,
                    )
                    return str(row["primary_category"])

                logger.warning("get_user_type | NOT_FOUND | user=%s | ms=%.1f", user_id, elapsed_ms)
                return None

        except Exception as exc:
            logger.exception("get_user_type | FAILED | user=%s | %s", user_id, exc)
            return None
        finally:
            logger.debug("get_user_type | COMPLETE | user=%s", user_id)

    def is_investor(self, user_id: str) -> bool:
        """
        Return True if the user's primary_category is 'investor'.

        Args:
            user_id: User UUID string.

        Returns:
            True if the user is an investor.
        """
        user_type = self.get_user_type(user_id)
        return bool(user_type and "investor" in user_type.lower())

    # ── READ: investor profile ────────────────────────────────────────────────

    def get_investor_profile(self, user_id: str) -> Dict[str, Any]:
        """
        Fetch and merge the investor profile from impact_profiles_v2 (primary)
        and intelligence_data (fallback for missing fields).

        Args:
            user_id: Investor UUID string.

        Returns:
            Merged profile dict. Empty dict if no data found.
        """
        logger.info("get_investor_profile | START | user=%s", user_id)
        start   = time.perf_counter()
        profile: Dict[str, Any] = {}

        try:
            with self.engine.connect() as conn:
                # Query 1: impact_profiles_v2 (higher priority)
                row = conn.execute(text("""
                    SELECT investor_profile
                    FROM public.impact_profiles_v2
                    WHERE id = :uid
                    LIMIT 1
                """), {"uid": user_id}).mappings().first()

                if row and row["investor_profile"]:
                    raw = row["investor_profile"]
                    profile = dict(json.loads(raw) if isinstance(raw, str) else raw)
                    logger.info(
                        "impact_profiles_v2 | %d fields | user=%s", len(profile), user_id
                    )
                else:
                    logger.warning("impact_profiles_v2 | no row | user=%s", user_id)

                # Query 2: intelligence_data (fallback — only fills empty slots)
                if self._table_exists("intelligence_data"):
                    id_row = conn.execute(text("""
                        SELECT investor_data
                        FROM public.intelligence_data
                        WHERE profile_id = :uid
                        LIMIT 1
                    """), {"uid": user_id}).mappings().first()

                    if id_row and id_row["investor_data"]:
                        inv = id_row["investor_data"]
                        if isinstance(inv, str):
                            inv = json.loads(inv)
                        for k, v in dict(inv).items():
                            if k not in profile or profile[k] in (None, "", [], {}):
                                profile[k] = v
                        logger.info(
                            "intelligence_data | merged → %d fields | user=%s",
                            len(profile), user_id,
                        )

        except Exception as exc:
            logger.exception("get_investor_profile | FAILED | user=%s | %s", user_id, exc)

        elapsed_ms = (time.perf_counter() - start) * 1000
        logger.info(
            "get_investor_profile | END | fields=%d | ms=%.1f | user=%s",
            len(profile), elapsed_ms, user_id,
        )
        return profile

    # ── READ: eval users ──────────────────────────────────────────────────────

    def get_all_eval_users(self, limit: int = 10) -> List[str]:
        """
        Fetch a list of investor user IDs for batch evaluation runs.

        Args:
            limit: Maximum number of user IDs to return.

        Returns:
            List of investor user ID strings.
        """
        logger.info("get_all_eval_users | limit=%d", limit)
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT id FROM public.basic_profiles
                    WHERE primary_category = 'investor'
                    LIMIT :lim
                """), {"lim": limit})
                return [str(row[0]) for row in result.fetchall()]
        except Exception as exc:
            logger.exception("get_all_eval_users | FAILED | %s", exc)
            return []

    # ── WRITE: patch investor profile (ACID) ──────────────────────────────────

    def patch_investor_profile(
        self,
        user_id:   str,
        patch:     Dict[str, Any],
        qualified: bool = False,
    ) -> Dict[str, Any]:
        """
        Upsert collected profile fields into impact_profiles_v2 and
        intelligence_data — ACID-compliant atomic transaction.

        Only executes if the investor is confirmed qualified.
        Uses engine.begin() for Atomicity (auto-commit or full rollback).
        Uses SELECT ... FOR UPDATE for Isolation (prevents race conditions).
        Uses JSONB merge operator (||) for Consistency (no data loss).

        Args:
            user_id:   Investor UUID string.
            patch:     Key-value pairs to merge into the existing profile.
            qualified: Must be True for the write to execute.

        Returns:
            The updated investor_profile dict, or existing profile on skip/fail.
        """
        logger.info(
            "patch_investor_profile | START | user=%s | fields=%s | qualified=%s",
            user_id, list(patch.keys()), qualified,
        )
        start = time.perf_counter()

        if not qualified:
            logger.info("patch_investor_profile | SKIP | not qualified | user=%s", user_id)
            return self.get_investor_profile(user_id)
        if not patch:
            logger.info("patch_investor_profile | SKIP | empty patch | user=%s", user_id)
            return self.get_investor_profile(user_id)
        if not self.is_investor(user_id):
            logger.warning("patch_investor_profile | SKIP | not investor | user=%s", user_id)
            return self.get_investor_profile(user_id)

        patch_json = json.dumps(patch)

        try:
            # ── ACID: engine.begin() — auto-commit on success, rollback on error
            with self.engine.begin() as conn:
                # impact_profiles_v2 upsert (JSONB merge)
                row_v2 = conn.execute(text("""
                    INSERT INTO public.impact_profiles_v2
                        (id, investor_profile, created_at, embedding_model)
                    VALUES (
                        CAST(:uid AS uuid),
                        CAST(:patch AS jsonb),
                        NOW(),
                        jsonb_build_object('updated_at', to_char(NOW(), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
                    )
                    ON CONFLICT (id) DO UPDATE SET
                        investor_profile = COALESCE(
                            public.impact_profiles_v2.investor_profile, '{}'::jsonb
                        ) || CAST(:patch AS jsonb),
                        embedding_model  = COALESCE(
                            public.impact_profiles_v2.embedding_model, '{}'::jsonb
                        ) || jsonb_build_object('updated_at', to_char(NOW(), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
                    RETURNING investor_profile
                """), {"uid": user_id, "patch": patch_json}).mappings().first()

                logger.info("patch_investor_profile | impact_profiles_v2 updated | user=%s", user_id)

                # intelligence_data upsert (same transaction — ATOMICITY)
                if self._table_exists("intelligence_data"):
                    try:
                        conn.execute(text("""
                            INSERT INTO public.intelligence_data
                                (profile_id, investor_data, created_at, embedding_model)
                            VALUES (
                                :uid,
                                CAST(:patch AS jsonb),
                                NOW(),
                                jsonb_build_object('updated_at', to_char(NOW(), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
                            )
                            ON CONFLICT (profile_id) DO UPDATE SET
                                investor_data   = COALESCE(
                                    public.intelligence_data.investor_data, '{}'::jsonb
                                ) || CAST(:patch AS jsonb),
                                embedding_model = COALESCE(
                                    public.intelligence_data.embedding_model, '{}'::jsonb
                                ) || jsonb_build_object('updated_at', to_char(NOW(), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
                        """), {"uid": user_id, "patch": patch_json})
                        logger.info("patch_investor_profile | intelligence_data updated | user=%s", user_id)
                    except Exception as intel_exc:
                        logger.error(
                            "patch_investor_profile | intelligence_data failed | user=%s | %s",
                            user_id, intel_exc,
                        )
                # Transaction commits here — both tables updated atomically

            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "patch_investor_profile | SUCCESS | user=%s | ms=%.1f", user_id, elapsed_ms
            )
            return dict(row_v2["investor_profile"]) if row_v2 else {}

        except Exception as exc:
            logger.exception("patch_investor_profile | FAILED | user=%s | %s", user_id, exc)
            return self.get_investor_profile(user_id)
        finally:
            logger.debug("patch_investor_profile | COMPLETE | user=%s", user_id)


__all__ = ["PostgresRepo"]
