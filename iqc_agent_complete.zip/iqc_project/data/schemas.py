"""
Module: data/schemas.py
Description: Pydantic v2 I/O models used across the IQC pipeline.
             Pure data shapes — no business logic lives here.
Author: IQC Team
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Domain constants ──────────────────────────────────────────────────────────

ESSENTIAL_FIELDS: List[str] = [
    "capacity", "stage", "sector", "geo", "authority",
    "timeline", "value_add", "portfolio", "deal_prefs", "seeking",
]

QUALIFY_THRESHOLD: float = 0.80   # 80% aggregate confidence


# ── Pipeline I/O Models ───────────────────────────────────────────────────────

class PromptDBCheck(BaseModel):
    """
    Result of cross-checking a user prompt against the stored investor profile.

    Attributes:
        inferred_fields: Fields extracted from the prompt text.
        missing_in_db:   Field names present in prompt but absent from DB.
        conflicts:       List of conflict objects (field, prompt_val, db_val).
        confidence:      Overall confidence score between 0.0 and 1.0.
        notes:           Optional free-text notes.
    """
    inferred_fields: Dict[str, Any] = Field(default_factory=dict)
    missing_in_db:   List[str]      = Field(default_factory=list)
    conflicts:       List[Dict[str, Any]] = Field(default_factory=list)
    confidence:      float = Field(ge=0.0, le=1.0, default=0.0)
    notes:           str   = ""


class QuestionPack(BaseModel):
    """
    A set of one or more questions to ask the investor.

    Attributes:
        questions: Ordered list of question strings.
    """
    questions: List[str] = Field(default_factory=list)


class MissingFieldsExplanation(BaseModel):
    """
    Explains why a profile does not yet meet the qualification threshold.

    Attributes:
        explanation:   One-sentence summary of missing fields and score gap.
        example_field: The most critical missing field name.
        example_value: A brief example of good data for that field.
    """
    explanation:   str = Field(description="Why the profile doesn't qualify yet")
    example_field: str = Field(description="Most critical missing field name")
    example_value: str = Field(description="Brief example of good data for that field")


class InvocationResult(BaseModel):
    """
    Final structured result returned by the pipeline after each invocation.

    Attributes:
        user_id:          Investor UUID.
        user_type:        'investor' or 'founder'.
        investor_profile: Merged investor profile dict.
        score:            Score percentage string (e.g. '75%').
        confidence:       Raw confidence float (0.0–1.0).
        qualified:        True if confidence >= QUALIFY_THRESHOLD.
        missing_fields:   Fields still below the scoring threshold.
        next_question:    Next question to ask the investor, or ''.
        message:          Human-readable response text.
        error:            Error type key if an error occurred, else ''.
    """
    user_id:          str = ""
    user_type:        str = ""
    investor_profile: Dict[str, Any] = Field(default_factory=dict)
    score:            str   = "0%"
    confidence:       float = 0.0
    qualified:        bool  = False
    missing_fields:   List[str] = Field(default_factory=list)
    next_question:    str   = ""
    message:          str   = ""
    error:            str   = ""


__all__ = [
    "ESSENTIAL_FIELDS",
    "QUALIFY_THRESHOLD",
    "PromptDBCheck",
    "QuestionPack",
    "MissingFieldsExplanation",
    "InvocationResult",
]
