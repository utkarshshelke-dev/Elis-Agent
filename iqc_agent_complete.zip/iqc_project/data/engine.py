"""
Module: data/engine.py
Description: SQLAlchemy engine factory for the IQC agent.
             Uses lru_cache to return a single shared engine instance.
             Reads all connection config from Pydantic settings — no
             credentials are ever hardcoded here.
Author: IQC Team
"""
from __future__ import annotations

import logging
import signal
from functools import lru_cache
from typing import Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config.settings import settings

logger = logging.getLogger(__name__)

# Pool tuned for Cloud Run / Agent Engine startup constraints
_POOL_SIZE       = 5
_MAX_OVERFLOW    = 2
_POOL_TIMEOUT    = 5      # Seconds to wait for a connection — kept short for startup
_POOL_RECYCLE    = 1800   # Recycle connections after 30 minutes
_CONNECT_TIMEOUT = 5      # TCP-level connection timeout (seconds)
_STARTUP_PING_TIMEOUT = 3 # Startup connection test timeout (seconds)


@lru_cache(maxsize=1)
def get_engine() -> Optional[Engine]:
    """
    Create and return a singleton SQLAlchemy engine.

    Uses lru_cache to ensure a single engine instance is shared across
    all repository calls within the same process, avoiding repeated
    connection pool creation overhead.

    If DB_PASS is not set or the database is unreachable at startup,
    returns None so the agent can start with a helpful error rather
    than crashing at import time.

    Returns:
        Engine: Configured SQLAlchemy engine with connection pool.
        None:   If DB_PASS is missing or the initial connection test fails.
    """
    if not settings.db_pass or settings.db_pass.strip() == "":
        logger.warning(
            "get_engine | DB_PASS not set — skipping DB connection at startup"
        )
        return None

    logger.info(
        "get_engine | Connecting to %s:%s/%s",
        settings.db_host, settings.db_port, settings.db_name,
    )

    try:
        engine = create_engine(
            settings.database_url,
            pool_size=_POOL_SIZE,
            max_overflow=_MAX_OVERFLOW,
            pool_timeout=_POOL_TIMEOUT,
            pool_recycle=_POOL_RECYCLE,
            pool_use_lifo=True,       # Reuse warm connections first
            pool_pre_ping=True,       # Validate connection health on checkout
            connect_args={"connect_timeout": _CONNECT_TIMEOUT},
        )

        # Startup ping — non-blocking with signal alarm (Unix only)
        _ping_engine(engine)

        return engine

    except Exception as exc:
        logger.warning("get_engine | Could not initialise at startup: %s", exc)
        return None


def _ping_engine(engine: Engine) -> None:
    """
    Perform a lightweight startup connectivity test with a hard timeout.

    Logs the result but does NOT raise — the engine is still returned
    even on failure (the pool will retry on first actual use).

    Args:
        engine: SQLAlchemy engine to test.
    """
    def _timeout_handler(signum, frame):
        raise TimeoutError("DB startup ping exceeded timeout")

    old_handler = None
    try:
        old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
        signal.alarm(_STARTUP_PING_TIMEOUT)
        with engine.connect() as conn:
            db_name = conn.execute(text("SELECT current_database()")).scalar()
            logger.info("get_engine | Connected: db=%s", db_name)
    except Exception as exc:
        logger.warning(
            "get_engine | Startup ping failed (will retry on first use): %s", exc
        )
    finally:
        signal.alarm(0)
        if old_handler is not None:
            signal.signal(signal.SIGALRM, old_handler)


__all__ = ["get_engine"]
