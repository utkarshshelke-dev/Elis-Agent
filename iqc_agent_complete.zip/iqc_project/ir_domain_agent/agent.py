"""
Module: ir_domain_agent/agent.py
Description: IR Domain Agent — Google ADK (Vertex AI Agent Engine).
             Detects investor intent, manages PostgreSQL sessions, and routes
             investor messages to the IQC Agent Engine via streaming HTTPS.
             State stored in PostgreSQL keyed by user_id (not ADK sessions).

Flow:
  1. User provides user_id
  2. get_or_create_session  → upsert ir_active_sessions
  3. route_to_iqc           → call IQC engine, append turn to chat_history
  4. close_session          → flush to ir_session_history, delete active row
  Expiry (>60 min)          → detected on next message, flush + reset

Author: IQC Team
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Optional, Tuple

import google.auth
import google.auth.transport.requests
import psycopg2
import psycopg2.extras
import requests
from google.adk.agents import Agent
from google.adk.tools import ToolContext

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [IR] %(levelname)s %(message)s",
)
logger = logging.getLogger("ir_domain_agent")

# ── Config ────────────────────────────────────────────────────────────────────
PROJECT    = os.getenv("GOOGLE_CLOUD_PROJECT",  "the-grid-os")
REGION     = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
_BASE      = (
    f"https://{REGION}-aiplatform.googleapis.com"
    f"/v1beta1/projects/{PROJECT}/locations/{REGION}/reasoningEngines"
)
IQC_ENGINE_ID = os.getenv("IQC_ENGINE_ID", "6728420724245004288")
IQC_URL       = f"{_BASE}/{IQC_ENGINE_ID}:streamQuery"
SESSION_TTL   = 3600  # 60 minutes

# Database — read from environment; never hardcode credentials
DB_CONFIG = {
    "host":     os.getenv("DB_HOST",     "localhost"),
    "port":     int(os.getenv("DB_PORT", "5432")),
    "user":     os.getenv("DB_USER",     "postgres"),
    "password": os.getenv("DB_PASS",     ""),          # REQUIRED — no default
    "dbname":   os.getenv("DB_NAME",     "grid_os_poc"),
}

_SESSION_MARKER_RE = re.compile(r"__SESSION__(\{.*?\})", re.DOTALL)


# ── DB helpers ────────────────────────────────────────────────────────────────

def _conn():
    """Open a new psycopg2 connection. Caller is responsible for close()."""
    return psycopg2.connect(**DB_CONFIG)


def _pg_load(user_id: str) -> Optional[dict]:
    """
    Load session row from ir_active_sessions.

    Args:
        user_id: Investor UUID.

    Returns:
        Session dict if found, None otherwise.
    """
    try:
        c   = _conn()
        cur = c.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(
            "SELECT * FROM ir_active_sessions WHERE user_id = %s LIMIT 1",
            (user_id,),
        )
        row = cur.fetchone()
        cur.close()
        c.close()
        if not row:
            return None
        ch = row.get("chat_history") or []
        if isinstance(ch, str):
            try:
                ch = json.loads(ch)
            except Exception:
                ch = []
        return {
            "user_id":        str(row["user_id"]),
            "session_id":     str(row["session_id"]),
            "iqc_session_id": str(row.get("iqc_session_id") or ""),
            "status":         row["status"],
            "started_at":     row["started_at"].timestamp(),
            "turn_number":    row["turn_number"],
            "chat_history":   ch,
        }
    except Exception as exc:
        logger.error("_pg_load | FAILED | user=%s | %s", user_id, exc)
        return None


def _pg_upsert(session: dict) -> None:
    """
    Upsert session into ir_active_sessions (DELETE + INSERT for replication safety).

    Args:
        session: Session dict with all required fields.
    """
    try:
        c   = _conn()
        cur = c.cursor()
        cur.execute("DELETE FROM ir_active_sessions WHERE user_id = %s", (session["user_id"],))
        cur.execute("""
            INSERT INTO ir_active_sessions
                (user_id, session_id, iqc_session_id, status,
                 started_at, turn_number, chat_history, updated_at)
            VALUES (%s, %s, %s, %s, to_timestamp(%s), %s, %s::jsonb, NOW())
        """, (
            session["user_id"],
            session["session_id"],
            session.get("iqc_session_id", ""),
            session["status"],
            session["started_at"],
            session["turn_number"],
            json.dumps(session["chat_history"]),
        ))
        c.commit()
        cur.close()
        c.close()
        logger.debug(
            "_pg_upsert | OK | user=%s | turn=%d",
            session["user_id"], session.get("turn_number", 0),
        )
    except Exception as exc:
        logger.error("_pg_upsert | FAILED | %s", exc)


def _pg_delete(user_id: str) -> None:
    """Delete the active session row for a user."""
    try:
        c   = _conn()
        cur = c.cursor()
        cur.execute("DELETE FROM ir_active_sessions WHERE user_id = %s", (user_id,))
        c.commit()
        cur.close()
        c.close()
    except Exception as exc:
        logger.error("_pg_delete | FAILED | user=%s | %s", user_id, exc)


def _pg_load_history(user_id: str) -> Optional[dict]:
    """
    Restore last closed session from ir_session_history.

    Args:
        user_id: Investor UUID.

    Returns:
        Session-like dict if found, None otherwise.
    """
    try:
        c   = _conn()
        cur = c.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute("""
            SELECT session_id, iqc_session_id, turn_count, chat_history, started_at
            FROM ir_session_history
            WHERE user_id = %s
            ORDER BY ended_at DESC
            LIMIT 1
        """, (user_id,))
        row = cur.fetchone()
        cur.close()
        c.close()
        if not row:
            return None
        ch = row.get("chat_history") or []
        if isinstance(ch, str):
            try:
                ch = json.loads(ch)
            except Exception:
                ch = []
        return {
            "user_id":        user_id,
            "session_id":     str(row["session_id"]),
            "iqc_session_id": str(row.get("iqc_session_id") or ""),
            "status":         "qualifying",
            "started_at":     row["started_at"].timestamp(),
            "turn_number":    row.get("turn_count", 0),
            "chat_history":   ch,
        }
    except Exception as exc:
        logger.error("_pg_load_history | FAILED | user=%s | %s", user_id, exc)
        return None


def _flush_to_pg_archive(session: dict, end_reason: str = "exit") -> None:
    """
    Flush active session to ir_session_history and delete active row.

    Args:
        session:    Session dict.
        end_reason: Reason for session close ('exit', 'expired', 'qualified').
    """
    try:
        c   = _conn()
        cur = c.cursor()
        cur.execute("""
            INSERT INTO ir_session_history
                (user_id, session_id, iqc_session_id, turn_count,
                 chat_history, started_at, ended_at, end_reason)
            VALUES (%s, %s, %s, %s, %s::jsonb, to_timestamp(%s), NOW(), %s)
            ON CONFLICT (session_id) DO UPDATE SET
                turn_count   = EXCLUDED.turn_count,
                chat_history = EXCLUDED.chat_history,
                ended_at     = EXCLUDED.ended_at,
                end_reason   = EXCLUDED.end_reason
        """, (
            session["user_id"],
            session["session_id"],
            session.get("iqc_session_id", ""),
            session.get("turn_number", 0),
            json.dumps(session.get("chat_history", [])),
            session["started_at"],
            end_reason,
        ))
        cur.execute("DELETE FROM ir_active_sessions WHERE user_id = %s", (session["user_id"],))
        c.commit()
        cur.close()
        c.close()
        logger.info(
            "_flush_to_pg_archive | OK | user=%s | turns=%d | reason=%s",
            session["user_id"], session.get("turn_number", 0), end_reason,
        )
    except Exception as exc:
        logger.error("_flush_to_pg_archive | FAILED | %s", exc)


def _new_session(user_id: str) -> dict:
    """Create a new in-memory session dict (not yet persisted)."""
    return {
        "user_id":        user_id,
        "session_id":     str(uuid.uuid4()),
        "iqc_session_id": "",
        "status":         "open",
        "started_at":     time.time(),
        "turn_number":    0,
        "chat_history":   [],
    }


# ── IQC Engine callers ────────────────────────────────────────────────────────

def _get_token() -> str:
    """
    Obtain a Google OAuth2 Bearer token for Agent Engine API calls.

    Returns:
        Bearer token string.

    Raises:
        Exception: If credentials cannot be obtained or refreshed.
    """
    creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    creds.refresh(google.auth.transport.requests.Request())
    return creds.token


def _create_iqc_session(user_id: str) -> Optional[str]:
    """
    Create a new IQC Agent Engine session for a user.

    Args:
        user_id: Investor UUID.

    Returns:
        IQC session ID string, or None on failure.
    """
    try:
        engine_base = _BASE + f"/{IQC_ENGINE_ID}"
        token       = _get_token()
        resp = requests.post(
            f"{engine_base}/sessions",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json={"user_id": user_id},
            timeout=30,
        )
        resp.raise_for_status()
        name = resp.json().get("name", "")
        session_id = name.split("/")[-1] if "/" in name else name
        logger.info("_create_iqc_session | OK | iqc_sid=%s | user=%s", session_id, user_id)
        return session_id
    except Exception as exc:
        logger.error("_create_iqc_session | FAILED | user=%s | %s", user_id, exc)
        return None


def _build_context(chat_history: list) -> str:
    """
    Build a minimal context string from prior turns for IQC's first message.

    Args:
        chat_history: List of turn dicts from session.

    Returns:
        Formatted context string.
    """
    if not chat_history:
        return ""
    lines = []
    for turn in chat_history[-3:]:  # Last 3 turns only
        lines.append(f"User: {turn.get('user_message', '')}")
        lines.append(f"IQC:  {turn.get('iqc_response', '')}")
    return "\n".join(lines)


def _call_engine(
    url:            str,
    message:        str,
    user_id:        str,
    iqc_session_id: str = "",
    context:        str = "",
) -> Tuple[str, str]:
    """
    Stream a message to the IQC Agent Engine and return the full response.
    Also extracts __SESSION__{...} marker from response to capture IQC session ID.

    Args:
        url:            IQC streamQuery endpoint URL.
        message:        User message to forward.
        user_id:        Investor UUID (for logging).
        iqc_session_id: Existing IQC session ID (empty for first call).
        context:        Prior conversation context (fallback when session lost).

    Returns:
        Tuple of (response_text, captured_iqc_session_id).
    """
    full_message = f"{context}\n{message}".strip() if context else message
    payload: dict = {"input": {"messages": [{"role": "user", "content": full_message}]}}
    if iqc_session_id:
        payload["session_id"] = iqc_session_id

    try:
        token = _get_token()
        resp  = requests.post(
            url,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=payload,
            stream=True,
            timeout=120,
        )
        resp.raise_for_status()

        lines:       list = []
        captured_sid: str = iqc_session_id

        for raw_line in resp.iter_lines(decode_unicode=True):
            line = (raw_line or "").strip()
            if not line or not line.startswith("{"):
                continue
            try:
                obj = json.loads(line)
                text = (
                    obj.get("output", {}).get("content", "")
                    or obj.get("text", "")
                    or obj.get("message", "")
                )
                if text:
                    # Extract __SESSION__ marker if present
                    m = _SESSION_MARKER_RE.search(text)
                    if m:
                        try:
                            sid = json.loads(m.group(1)).get("session_id", "")
                            if sid:
                                captured_sid = sid
                        except Exception:
                            pass
                    lines.append(text)
            except Exception:
                pass

        full_response = "\n".join(lines).strip()
        logger.info(
            "_call_engine | OK | user=%s | iqc_sid=%s | chars=%d",
            user_id, captured_sid, len(full_response),
        )
        return full_response, captured_sid

    except Exception as exc:
        logger.error("_call_engine | FAILED | user=%s | %s", user_id, exc)
        return "", iqc_session_id


# ── ADK Tool Functions ────────────────────────────────────────────────────────

def get_or_create_session(user_id: str, tool_context: ToolContext) -> str:
    """
    Check PostgreSQL for an active session. Create new, resume, or reopen from history.

    Handles four cases:
    - Expired session (>60 min): flush to history, create fresh session.
    - Active session (open/qualifying): resume and return last IQC question.
    - Already qualified: return qualified status.
    - New user (no record): create new session.

    Args:
        user_id:      Investor UUID.
        tool_context: ADK tool context (injected by ADK framework).

    Returns:
        JSON string with result, session_id, status, and optional last_iqc_question.
    """
    logger.info("get_or_create_session | START | user=%s", user_id)
    session = _pg_load(user_id)

    # Expired session → flush, reset
    if session and (time.time() - session["started_at"]) > SESSION_TTL:
        logger.info(
            "get_or_create_session | EXPIRED | user=%s | age_min=%d",
            user_id, int((time.time() - session["started_at"]) / 60),
        )
        _flush_to_pg_archive(session, end_reason="expired")
        session = None

    # No active session → try history
    if not session:
        history = _pg_load_history(user_id)
        if history:
            history["status"] = "qualifying"
            _pg_upsert(history)
            session = history
            logger.info(
                "get_or_create_session | RESTORED | user=%s | turns=%d",
                user_id, history["turn_number"],
            )

    # Active session → resume
    if session and session["status"] in ("open", "qualifying"):
        age_mins = int((time.time() - session["started_at"]) / 60)
        ch = session.get("chat_history", [])
        last_iqc_q = ch[-1].get("iqc_response", "") if ch else ""
        logger.info(
            "get_or_create_session | RESUMED | user=%s | age=%dmin | turns=%d",
            user_id, age_mins, session["turn_number"],
        )
        return json.dumps({
            "result":            "resumed",
            "session_id":        session["session_id"],
            "iqc_session_id":    session.get("iqc_session_id", ""),
            "status":            session["status"],
            "age_minutes":       age_mins,
            "turns":             session["turn_number"],
            "user_id":           user_id,
            "last_iqc_question": last_iqc_q,
            "progress_pct":      session["turn_number"] * 10,
        })

    # Already qualified
    if session and session["status"] == "qualified":
        logger.info("get_or_create_session | ALREADY_QUALIFIED | user=%s", user_id)
        return json.dumps({
            "result":  "resumed",
            "reason":  "already_qualified",
            "user_id": user_id,
            "status":  "qualified",
            "turns":   session["turn_number"],
        })

    # New user
    new_s = _new_session(user_id)
    _pg_upsert(new_s)
    logger.info("get_or_create_session | CREATED | user=%s", user_id)
    return json.dumps({
        "result":     "created",
        "reason":     "new_user",
        "session_id": new_s["session_id"],
        "status":     "open",
    })


def route_to_iqc(user_id: str, message: str, tool_context: ToolContext) -> str:
    """
    Forward an investor message to the IQC Agent Engine.
    Appends turn to chat_history in PostgreSQL.
    On turn 0 (fresh IQC session), prepends user_id so IQC can run check_user().

    Args:
        user_id:      Investor UUID.
        message:      The investor message to forward.
        tool_context: ADK tool context (injected by ADK framework).

    Returns:
        JSON string with result, response text, and qualified flag.
    """
    logger.info("route_to_iqc | START | user=%s | len=%d", user_id, len(message))
    session        = _pg_load(user_id) or _new_session(user_id)
    iqc_session_id = session.get("iqc_session_id", "")

    # Create IQC session on first call
    if not iqc_session_id:
        iqc_session_id = _create_iqc_session(user_id) or ""
        if iqc_session_id:
            session["iqc_session_id"] = iqc_session_id
            logger.info("route_to_iqc | IQC session created | sid=%s", iqc_session_id)

    turn_number  = session.get("turn_number", 0)
    chat_history = session.get("chat_history", [])

    # First IQC turn — prepend user_id so IQC check_user() has the UUID
    iqc_message = f"user_id: {user_id}\n{message}" if turn_number == 0 else message

    # Context fallback — only if IQC session creation failed
    context = _build_context(chat_history) if (chat_history and not iqc_session_id) else ""

    response_text, captured_sid = _call_engine(
        IQC_URL, iqc_message, user_id,
        iqc_session_id=iqc_session_id,
        context=context,
    )

    # Update session IQC sid if changed
    if captured_sid and captured_sid != session.get("iqc_session_id"):
        session["iqc_session_id"] = captured_sid
        logger.info("route_to_iqc | IQC session_id captured: %s", captured_sid)

    # Strip __SESSION__ marker before storing
    clean = (
        response_text.split("__SESSION__")[0].strip()
        if "__SESSION__" in response_text else response_text
    )

    session["status"]      = "qualifying"
    session["turn_number"] = turn_number + 1
    session.setdefault("chat_history", []).append({
        "turn":          session["turn_number"],
        "user_message":  message,
        "iqc_response":  clean,
        "timestamp":     datetime.now(timezone.utc).isoformat(),
    })
    _pg_upsert(session)

    if not response_text:
        return json.dumps({
            "result":    "error",
            "response":  "I am having trouble reaching the qualification service. Please try again.",
            "qualified": False,
        })

    logger.info(
        "route_to_iqc | OK | user=%s | turn=%d | iqc_sid=%s",
        user_id, session["turn_number"], session.get("iqc_session_id", ""),
    )
    return json.dumps({
        "result":         "success",
        "response":       clean,
        "qualified":      False,
        "iqc_session_id": session.get("iqc_session_id", ""),
    })


def close_session(user_id: str, tool_context: ToolContext) -> str:
    """
    Close the investor's session and flush all chat history to ir_session_history.
    Call when user says exit, bye, quit, or goodbye.

    Args:
        user_id:      Investor UUID.
        tool_context: ADK tool context (injected by ADK framework).

    Returns:
        JSON string with result and turns_saved count.
    """
    logger.info("close_session | START | user=%s", user_id)
    session = _pg_load(user_id)
    if not session:
        return json.dumps({"result": "no_session"})

    session["status"] = "closed"
    turns             = len(session.get("chat_history", []))
    _flush_to_pg_archive(session, end_reason="exit")

    logger.info("close_session | OK | user=%s | turns=%d", user_id, turns)
    return json.dumps({"result": "closed", "turns_saved": turns})


# ── Root Agent ────────────────────────────────────────────────────────────────

root_agent = Agent(
    name="ir_domain_agent",
    model="gemini-2.0-flash",
    description=(
        "IR Domain Agent — detects investment signals, qualifies investors "
        "via IQC Agent Engine, then routes to ISS for matching."
    ),
    tools=[
        get_or_create_session,
        route_to_iqc,
        close_session,
    ],
    instruction="""
You are a warm, professional IR (Investor Relations) assistant.
Collect the investor User ID then guide them through qualification via IQC.

FIRST MESSAGE HANDLING
Check if the user's first message contains a UUID (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
- If YES: extract it as user_id, skip the greeting, go to ONCE USER PROVIDES USER ID.
- If NO: say exactly "Hey there! Welcome to the Investor Relations Portal! To get started, could you please share your User ID?"

ONCE USER PROVIDES USER ID
Extract the UUID from their message. Store as user_id in memory.
NEVER invent a user_id. NEVER use a system ID. Use ONLY what the user typed.
Call get_or_create_session(user_id).

IF result is "resumed":
  - Store user_id and iqc_session_id from the response in memory.
  - If reason is "already_qualified": say "Welcome back! You are already fully qualified." Stop.
  - For ALL other resume cases:
    Say ONLY: "Welcome back! Great to have you here again."
    Then show last_iqc_question verbatim on the next line.
    NEVER call route_to_iqc on resume — just show last_iqc_question and wait for user's answer.
    If last_iqc_question is empty: say "Where were we? Please continue where you left off."

IF result is "created":
  - Ask: "Are you looking for opportunities to invest?"

IF USER SAYS YES (only after result="created"):
  Say: "Fetching your profile, please hold on a moment..."
  Call route_to_iqc(user_id=<stored user_id>, message=<what user said>).
  Show ONLY the "response" field verbatim.

ALL SUBSEQUENT TURNS
Every user message:
  Call route_to_iqc(user_id=<stored user_id>, message=<user message>)
  Show ONLY the "response" field verbatim.
  Strip any __SESSION__{...} or SESSION{...} markers silently.

If qualified=true: say "Congratulations! You are now fully qualified. Our team will be in touch!"

EXIT INTENT
If user says exit, quit, bye, goodbye, or see you:
  Call close_session(user_id=<stored user_id>).
  Say: "It was great chatting with you! Take care and see you next time!"
  Stop.

STRICT RULES
- NEVER ask for user_id more than once.
- NEVER show __SESSION__{...} markers to the user — strip silently.
- NEVER ask "are you looking to invest?" if status is qualifying or qualified.
- NEVER show session IDs, turn counts, tool names, or internal data.
- NEVER add your own questions — show only IQC response verbatim.
- ALWAYS pass the stored user_id to every tool call.
""",
)
